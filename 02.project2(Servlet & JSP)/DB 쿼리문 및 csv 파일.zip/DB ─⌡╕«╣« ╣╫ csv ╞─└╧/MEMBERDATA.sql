--------------------------------------------------------
--  ������ ������ - ������-8��-09-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table MEMBERDATA
--------------------------------------------------------

  CREATE TABLE "SCOTT"."MEMBERDATA" 
   (	"ID" VARCHAR2(26 BYTE), 
	"PW" VARCHAR2(26 BYTE), 
	"NAME" VARCHAR2(26 BYTE), 
	"EMAIL" VARCHAR2(26 BYTE), 
	"TEL" NUMBER(38,0), 
	"SEX" VARCHAR2(26 BYTE), 
  "ISADMIN" NUMBER(1,0),
	"BIRTHDAY" DATE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into SCOTT.LOGINDATA
SET DEFINE OFF;
Insert into SCOTT.LOGINDATA (ID,PW,NAME,EMAIL,TEL,SEX,BIRTHDAY) values ('testid','testtest','������','e@email.com',1077771234,'female',to_date('96/12/11','RR/MM/DD'),0);
Insert into SCOTT.LOGINDATA (ID,PW,NAME,EMAIL,TEL,SEX,BIRTHDAY) values ('testadmin','123123123','������','balhae@goguryeo.com',1012341234,'male',to_date('88/07/07','RR/MM/DD'),1);
