package com.MyZoy.Command;

//import com.google.gson.Gson;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyZoy.Model.MemberDAO;

public class FindIdContent implements MemberCommand{
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		
		int ri=0;
		String name = (String) request.getParameter("name"); 
		String email = (String) request.getParameter("email"); 
		MemberDAO dao = new MemberDAO();
		String id = dao.findId(name, email); // 해당 Id를 가진 튜플을 dto에 담아서
		if (id!=null) {
			request.setAttribute("id", id);
			ri=1;
		} 
		return ri;
	}
} 