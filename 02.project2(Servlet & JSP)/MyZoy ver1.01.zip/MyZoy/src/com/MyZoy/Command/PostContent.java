package com.MyZoy.Command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyZoy.Model.BoardDAO;

public class PostContent implements BoardCommand{
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		BoardDAO dao = new BoardDAO();

		String writer = (String) request.getParameter("writer");
		if(writer=="") {writer="사용자";}
		String content = (String) request.getParameter("content");
		content = content.replace("\\", "\\\\");
		String title = (String) request.getParameter("title"); 
		title = title.replace("\\", "\\\\");
		String origin_isReply = (String) request.getParameter("isReply");
		int isReply = Integer.parseInt(origin_isReply);
		int ri = 0;
		if(isReply==1) { // 답글일 경우
			String origin_bId = (String) request.getParameter("bId");
			int bId = Integer.parseInt(origin_bId);
			dao.repost(bId);
			ri = dao.post(writer, title, content, isReply, bId);
		} else {ri = dao.post(writer, title, content, isReply);}
		
		return ri;
	}
}