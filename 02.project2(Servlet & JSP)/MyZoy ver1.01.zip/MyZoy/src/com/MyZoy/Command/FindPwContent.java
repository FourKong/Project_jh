package com.MyZoy.Command;

//import com.google.gson.Gson;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyZoy.Model.MemberDAO;

public class FindPwContent implements MemberCommand{
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		
		String id = (String) request.getParameter("id"); 
		String email = (String) request.getParameter("email"); 
		MemberDAO dao = new MemberDAO();
		
		String uid = dao.findPw(id, email);
		int ri=0;
		if(uid!=null) {
			request.setAttribute("id", uid);
			ri=1;
		}
		return ri;
	}
} 