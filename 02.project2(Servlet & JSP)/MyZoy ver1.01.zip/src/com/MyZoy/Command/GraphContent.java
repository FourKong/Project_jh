package com.MyZoy.Command;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.MyZoy.Model.GraphDAO;
import com.MyZoy.Model.GraphDTO;

public class GraphContent implements GraphCommand{
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		GraphDAO dao = new GraphDAO();
		String category = (String) request.getParameter("category");
		String id = (String) session.getAttribute("id");
		
		if(category == null) { category = "sex";} // 초기값 성별.
		
		int userData = dao.categoryCheck(category, id);
		ArrayList<GraphDTO> dtos = dao.graphData(category, userData);
		String dtoJson = new com.google.gson.Gson().toJson(dtos);
		request.setAttribute("graph_data", dtoJson);
		request.setAttribute("userData", userData);
		request.setAttribute("category", category);
	}
}