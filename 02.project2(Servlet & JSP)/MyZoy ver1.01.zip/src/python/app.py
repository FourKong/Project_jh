# pip install Flask
# pip install pandas
# pip install flask_cors
# pip install mord
# pip install scikit-learn

from flask import Flask, request, jsonify
import joblib
from flask_cors import CORS, cross_origin
import pandas as pd

app = Flask(__name__)
CORS(app, origins="*", supports_credentials=True)

all_model = joblib.load("all_model.pkl")
living_model = joblib.load('living_model.pkl')
health_model = joblib.load('health_model.pkl')
human_model = joblib.load('human_model.pkl')

@app.route('/', methods=['GET'])
def hello():
    return "Server Running!!"

@app.route('/predict', methods=['POST'])
@cross_origin()
def predict():
    
    data = request.get_json()  # JSP에서 보낸 데이터를 JSON 형태로 받음
    # 각 모델에 필요한 입력 데이터를 추출
    all_data = [
        data['sex'],
        data['age'],
        data['about_marriage'],
        data['marriage'],
        data['car'],
        data['house'],
        data['parents'],
        data['live_alone'],
        data['house_form'],
        data['house_rental'],
        data['health'],
        data['body'],
        data['exercise'],
        data['work_life'],
        data['real_dream'],
        data['result_procedure'],
        data['individual_group'],
        data['me_other'],
        data['for_happiness'],
        data['edu'],
        data['int_family'],
        data['int_friend'],
        data['int_other'],
        data['sat_living'],
        data['sat_health'],
        data['sat_human']
    ]

    print(all_data)

    all_data = [int(value) for value in all_data]
    all_data = pd.Series(all_data)

    print(all_data)

    other_data = [
        data['sex'],
        data['age'],
        data['about_marriage'],
        data['marriage'],
        data['car'],
        data['house'],
        data['parents'],
        data['live_alone'],
        data['house_form'],
        data['house_rental'],
        data['health'],
        data['body'],
        data['exercise'],
        data['work_life'],
        data['real_dream'],
        data['result_procedure'],
        data['individual_group'],
        data['me_other'],
        data['for_happiness'],
        data['edu'],
        data['int_family'],
        data['int_friend'],
        data['int_other']
    ]

    other_data = [int(value) for value in other_data]
    other_data = pd.Series(other_data)

    # # 각 모델에 입력 데이터를 적용하고 예측 결과를 계산
    pred_all = all_model.predict(all_data)
    pred_living = living_model.predict(other_data) 
    pred_health = health_model.predict(other_data)
    pred_human = human_model.predict(other_data)

    # 예측 결과를 JSON 형태로 반환
    result = {
        "pred_all": int(pred_all[0]),
        "pred_living": int(pred_living[0]),
        "pred_health": int(pred_health[0]),
        "pred_human": int(pred_human[0])
    }
    return jsonify(result)
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')  # 서버 실행. 모든 서버에서 접근 가능하게 하려면 0.0.0.0