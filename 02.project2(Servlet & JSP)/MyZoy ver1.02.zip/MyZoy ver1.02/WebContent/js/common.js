window.addEventListener('load', function() {
    adjustLayout();
});

window.addEventListener('resize', function() {
    adjustLayout();
});

var fixAgain;

function adjustLayout() {
    var viewportHeight = window.innerHeight;
    var wrapDiv = document.querySelector("#wrap");
    var wrapHeight = wrapDiv.clientHeight;
    
    if (viewportHeight > wrapHeight) {
        $("#footer").css("margin-top", viewportHeight - wrapHeight);
        fixAgain = setTimeout(function() {
            if (viewportHeight > wrapHeight) {
                $("#footer").css("margin-top", viewportHeight - wrapHeight);
            }
        }, 10);
        clearTimeout(fixAgain);
    }
}