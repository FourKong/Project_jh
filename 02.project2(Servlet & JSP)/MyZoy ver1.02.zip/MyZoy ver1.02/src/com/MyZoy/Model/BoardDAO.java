package com.MyZoy.Model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class BoardDAO {
DataSource dataSource;
	
	public BoardDAO() {
		
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g"); // DB와 연결.
		} catch (Exception e) {
			System.out.println("DB 연결 오류!");
			e.printStackTrace();
		}
	}
	
	public ArrayList<BoardDTO> boardList(int page) {
		ArrayList<BoardDTO> dtos = new ArrayList<BoardDTO>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			connection = dataSource.getConnection();
			String query = "SELECT * FROM "
					+ "(SELECT ROWNUM AS RN, BD.* FROM "
					+ "(SELECT * FROM BOARDDATA ORDER BY BID DESC) BD) "
					+ "WHERE RN>? AND RN <=?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, (page-1)*15);
			preparedStatement.setInt(2, page*15);
			rs = preparedStatement.executeQuery();
			while(rs.next()) {
				int bId = rs.getInt("bId");
				String writer = rs.getString("writer");
				String title = rs.getString("title");
				Date date = rs.getDate("bDate");
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
				String bDate = simpleDateFormat.format(date);
				int hit = rs.getInt("hit");
				int isReply = rs.getInt("isReply");
			    dtos.add(new BoardDTO(bId, writer, title, bDate, hit, isReply));
				}
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
				if(rs != null) rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
//		System.out.println(userData);
		return dtos;
	}
	
	public int pagenate() {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		int rn=0;
		try {
			connection = dataSource.getConnection();
			String query = "SELECT COUNT(*) FROM BOARDDATA";
			preparedStatement = connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
			if(rs.next()) {
				rn = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return rn;
	}
	
	public BoardDTO getPost(int bNo) {
		BoardDTO dto = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			connection = dataSource.getConnection();
			String query = "SELECT * FROM BOARDDATA WHERE bId=?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, bNo);
			rs = preparedStatement.executeQuery();
			if(rs.next()) { 
				int bId = rs.getInt("bId");
				String writer = rs.getString("writer");
				String title = rs.getString("title");
				String content = rs.getString("content");
//				content = content.replace(System.getProperty("line.separator"), "\\n");
				Date date = rs.getDate("bDate");
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
				String bDate = simpleDateFormat.format(date);
				int hit = rs.getInt("hit");
				int isReply = rs.getInt("isReply");
			    dto = new BoardDTO(bId, writer, title, content, bDate, hit, isReply);
				}
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
				if(rs != null) rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
//		System.out.println(userData);
		return dto;
	}

	public int post(String writer, String title, String content, int isReply) { // 일반 게시글
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int rn=0;
		try {
			connection = dataSource.getConnection();
			String query = "INSERT INTO BOARDDATA (bId, writer, title, content, hit, ISREPLY) values (BOARDDATA_seq.nextval,?,?,?,0,?)";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, writer);
			preparedStatement.setString(2, title);
			preparedStatement.setString(3, content);
			preparedStatement.setInt(4, isReply);
			rn = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return rn;
	}
	
	public int post(String writer, String title, String content, int isReply, int bId) { // 답변 게시글
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int rn=0;
		try {
			connection = dataSource.getConnection();
			String query = "INSERT INTO BOARDDATA (bId, writer, title, content, hit, ISREPLY) values (BOARDDATA_seq.nextval*0+?,?,?,?,0,?)";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, bId);
			preparedStatement.setString(2, writer);
			preparedStatement.setString(3, title);
			preparedStatement.setString(4, content);
			preparedStatement.setInt(5, isReply);
			rn = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return rn;
	}
	
	public int repost(int bId) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int rn=0;
		try {
			connection = dataSource.getConnection();
			String query = "UPDATE BOARDDATA SET BID=BID+1 WHERE BID>=?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, bId);
			rn = preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return rn;
	}
	
	public void deletePost(int bId) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = dataSource.getConnection();
			String query = "DELETE FROM BOARDDATA WHERE bId=?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, bId);
			preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public BoardDTO getNext(int bNo) {
		BoardDTO dto = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			connection = dataSource.getConnection();
			String query = "SELECT * FROM " + 
					"(SELECT * FROM BOARDDATA WHERE BID > ? ORDER BY BID) " + 
					"WHERE ROWNUM = 1";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, bNo);
			rs = preparedStatement.executeQuery();
			if(rs.next()) { 
				int bId = rs.getInt("bId");
				String writer = rs.getString("writer");
				String title = rs.getString("title");
				String content = rs.getString("content");
				Date date = rs.getDate("bDate");
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
				String bDate = simpleDateFormat.format(date);
				int hit = rs.getInt("hit");
				int isReply = rs.getInt("isReply");
			    dto = new BoardDTO(bId, writer, title, content, bDate, hit, isReply);
				}
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
				if(rs != null) rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return dto;
	}
	
	public BoardDTO getPrev(int bNo) {
		BoardDTO dto = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			connection = dataSource.getConnection();
			String query = "SELECT * FROM " + 
					"(SELECT * FROM BOARDDATA WHERE BID < ? ORDER BY BID DESC) " + 
					"WHERE ROWNUM = 1";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, bNo);
			rs = preparedStatement.executeQuery();
			if(rs.next()) { 
				int bId = rs.getInt("bId");
				String writer = rs.getString("writer");
				String title = rs.getString("title");
				String content = rs.getString("content");
				Date date = rs.getDate("bDate");
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
				String bDate = simpleDateFormat.format(date);
				int hit = rs.getInt("hit");
				int isReply = rs.getInt("isReply");
			    dto = new BoardDTO(bId, writer, title, content, bDate, hit, isReply);
				}
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
				if(rs != null) rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return dto;
	}
	
	public void hitUp(int bId) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = dataSource.getConnection();
			String query = "UPDATE BOARDDATA SET HIT=HIT+1 WHERE BID=?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, bId);
			preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}

}
