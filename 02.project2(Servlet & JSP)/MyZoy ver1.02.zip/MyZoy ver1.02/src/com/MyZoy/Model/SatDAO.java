package com.MyZoy.Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class SatDAO {
DataSource dataSource;
	
	public SatDAO() {
		
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g"); // DB와 연결.
		} catch (Exception e) {
			System.out.println("DB 연결 오류!");
			e.printStackTrace();
		}
	}

	public SatDTO predict_sat(String id) {
		SatDTO dto = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {  
			connection = dataSource.getConnection();
			String query = "SELECT * FROM SURVEYDATA WHERE ID=?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, id);
			rs = preparedStatement.executeQuery();
			if(rs.next()) {
				String ids = rs.getString("id");
				int sex= rs.getInt("sex");
				int age= rs.getInt("age");
				int about_marriage= rs.getInt("about_marriage");
				int marriage= rs.getInt("marriage");
				int car= rs.getInt("car");
				int house = rs.getInt("house");
			    int parents= rs.getInt("parents");
			    int live_alone= rs.getInt("live_alone");
			    int house_form= rs.getInt("house_form");
			    int house_rental= rs.getInt("house_rental");
			    int health= rs.getInt("health");
			    int body= rs.getInt("body");
			    int exercise= rs.getInt("exercise");
			    int work_life= rs.getInt("work_life");
			    int real_dream= rs.getInt("real_dream");
			    int result_procedure= rs.getInt("result_procedure");
			    int individual_group= rs.getInt("individual_group");
			    int me_other= rs.getInt("me_other");
			    int for_happiness= rs.getInt("for_happiness");
				int int_family = rs.getInt("int_family");
				int int_friend = rs.getInt("int_friend");
				int int_other = rs.getInt("int_other");
			    int edu= rs.getInt("edu");
			    int sat_living= rs.getInt("sat_living");
			    int sat_health= rs.getInt("sat_health");
			    int sat_human= rs.getInt("sat_human");
			    int sat_all= rs.getInt("sat_all");
			    int pred_living= rs.getInt("pred_living");
			    int pred_health= rs.getInt("pred_health");
			    int pred_human= rs.getInt("pred_human");
			    int pred_all= rs.getInt("pred_all");
				dto = new SatDTO(ids, sex, age, about_marriage, marriage, car, house, parents, live_alone, house_form, house_rental,
						health, body, exercise, work_life, real_dream, result_procedure, individual_group, me_other, for_happiness,
					    int_family, int_friend, int_other, edu,	sat_living,	sat_health, sat_human, sat_all,
					    pred_living, pred_health, pred_human, pred_all);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
				if(rs != null) rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return dto;
	}
	
	public ArrayList<CoefDTO> result_coef() {
		ArrayList<CoefDTO> dtos = new ArrayList<>();
		CoefDTO coefDto = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			connection = dataSource.getConnection();
			String query = "SELECT * FROM COEFDATA WHERE SAT=?";
			preparedStatement = connection.prepareStatement(query);
			for(int i=0; i<4; i++) { 
				preparedStatement.setInt(1, 10+i);
				rs = preparedStatement.executeQuery();
				if(rs.next()) {
					 double about_marriage=rs.getDouble("about_marriage");
				     double marriage=rs.getDouble("marriage");
				     double car=rs.getDouble("car");
				     double house=rs.getDouble("house");
				     double parents=rs.getDouble("parents");
				     double live_alone=rs.getDouble("live_alone");
				     double house_form=rs.getDouble("house_form");
				     double house_rental=rs.getDouble("house_rental");
				     double health=rs.getDouble("health");
				     double body=rs.getDouble("body");
				     double exercise=rs.getDouble("exercise");
				     double work_life=rs.getDouble("work_life");
				     double real_dream=rs.getDouble("real_dream");
				     double result_procedure=rs.getDouble("result_procedure");
				     double individual_group=rs.getDouble("individual_group");
				     double me_other=rs.getDouble("me_other");
				     double for_happiness=rs.getDouble("for_happiness");
				     double edu=rs.getDouble("edu");
				     double int_family=rs.getDouble("int_family");
				     double int_friend=rs.getDouble("int_friend");
				     double int_other=rs.getDouble("int_other");
				     coefDto=new CoefDTO(about_marriage, marriage, car, house, parents, live_alone, house_form, house_rental,
				    		 health, body, exercise, work_life, real_dream, result_procedure, individual_group, me_other, for_happiness, edu, int_family, int_friend, int_other);
				    dtos.add(coefDto);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
				if(rs != null) rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return dtos;
	}

}
