package com.MyZoy.Command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface GraphCommand {
	void execute(HttpServletRequest request, HttpServletResponse response);
}

