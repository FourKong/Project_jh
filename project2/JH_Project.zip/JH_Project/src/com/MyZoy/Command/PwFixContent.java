package com.MyZoy.Command;

//import com.google.gson.Gson;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyZoy.Model.MemberDAO;

public class PwFixContent implements MemberCommand{
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		 
		String id = (String) request.getParameter("uid"); 
		String pw = (String) request.getParameter("pw1"); 
		MemberDAO dao = new MemberDAO();
		int ri = dao.updateMember(id,pw);
		return ri;
	}
}