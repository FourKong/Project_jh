package com.MyZoy.Command;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyZoy.Model.BoardDAO;
import com.MyZoy.Model.BoardDTO;

public class ListContent implements BoardCommand{
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		BoardDAO dao = new BoardDAO();
		String page = (String) request.getParameter("page");
		if(page==null) {page="1";}
				
		ArrayList<BoardDTO> dtos = dao.boardList(Integer.parseInt(page));
		String dtoJson = new com.google.gson.Gson().toJson(dtos);
		request.setAttribute("boardList", dtoJson);
		
		int postCount = dao.pagenate();
		
		request.setAttribute("postCount", postCount);

		request.setAttribute("currentPage", page);
		
		return 0;
	}
}