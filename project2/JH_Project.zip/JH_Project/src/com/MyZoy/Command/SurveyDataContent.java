package com.MyZoy.Command;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

//import com.google.gson.Gson;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.MyZoy.Model.MemberDAO;
import com.MyZoy.Model.MemberDTO;
import com.MyZoy.Model.SatDAO;
import com.MyZoy.Model.SatDTO; 

public class SurveyDataContent implements MemberCommand{
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id"); 
		
		SatDAO satDao = new SatDAO();
		SatDTO survey = satDao.predict_sat(id);
		
		if(survey==null) {
			MemberDAO dao = new MemberDAO();
			MemberDTO dto = dao.getMember(id);
			
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
			int sex = 0;
			int age = 0;
		
			if(dto.getSex().equals("male")) { sex=1; }
			if(dto.getSex().equals("female")) { sex=2; }
		
			try {
				Date birthDate = dateFormat.parse(dto.getBirthday());
				LocalDate birthLocalDate = birthDate.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
				LocalDate currentLocalDate = LocalDate.now();

				Period agePeriod = Period.between(birthLocalDate, currentLocalDate);
				int userAge = agePeriod.getYears();
				if(userAge>=30 && userAge<35) { age = 4; }
				if(userAge>=25 && userAge<30) { age = 3; }
				if(userAge>=20 && userAge<25) { age = 2; }
				if(userAge>=18 && userAge<20) { age = 1; }
            
			} catch (Exception e) {
				e.printStackTrace(); 
				// ParseException 처리 로직 추가
			}
		
			request.setAttribute("sex", sex);
			request.setAttribute("age", age);
		} else {
			request.setAttribute("dto", survey);
			request.setAttribute("sex", survey.getSex());
			request.setAttribute("age", survey.getAge());
		}
		
		return 0;
	}
}