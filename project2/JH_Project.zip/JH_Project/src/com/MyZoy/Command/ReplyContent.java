package com.MyZoy.Command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyZoy.Model.BoardDAO;
import com.MyZoy.Model.BoardDTO;

public class ReplyContent implements BoardCommand{
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		BoardDAO dao = new BoardDAO();

		String origin_bId = (String) request.getParameter("bId");
		BoardDTO dto = dao.getPost(Integer.parseInt(origin_bId));
		request.setAttribute("dto", dto);
		
		return 0;
	}
}