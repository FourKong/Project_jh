package com.MyZeneration.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyZeneration.Command.*;

/**
 * Servlet implementation class FrontController
 */
@WebServlet("*.do") // do로 들어오는 모든 패킷 받겠다는 선언.
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FrontController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("doGet");
		actionDo(request, response); // doGet으로 받아도 actionDo로 넘긴다.
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("doPost");
		actionDo(request, response); // 마찬가지로 doPost으로 받아도 actionDo로 넘긴다. 요즘 트렌드(?)
	}
	
	private void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("actionDo");
		
		request.setCharacterEncoding("UTF-8");
		
		String viewPage = null; // 넘겨줄 페이지 정보
		
		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String com = uri.substring(conPath.length());
		
		if (com.equals("/index.do")) {
			viewPage = "index.jsp"; 
		} else if(com.equals("/satisfaction.do")) { // 기능 1
			SatCommand command = new SatContent(); // command 종류.
			int result = command.execute(request, response);
			if(result == 1) { // dao is not null
				viewPage = "main-function1.jsp"; 
				CoefCommand command2 = new CoefContent(); // True일 경우 Coef 정보 받아오기
				command2.execute(request, response);
			} else if (result == 0) { 
				viewPage = "main-function1.jsp"; // ---추후 폼 양식 페이지로!!--추후 폼 양식 페이지로!!--추후 폼 양식 페이지로!!--
			}

		} else if(com.equals("/graph.do")) { // 기능 2
			GraphCommand command = new GraphContent(); // command 종류.
			viewPage = "main-function2.jsp";
			command.execute(request, response);
			
		} else if(com.equals("/join.do")) {
			viewPage = "sub-member-join.jsp";
			
		} else if(com.equals("/login.do")) {
			viewPage = "sub-member-login.jsp";
			
		} else if(com.equals("/joinOK.do")) {
			MemberCommand command = new JoinContent(); // command 종류
			int ri = command.execute(request, response);
			if(ri==1) {
			    viewPage="joinFalse.do";
			} else if(ri==0) {
				request.setAttribute("things", "회원가입이");
				request.setAttribute("message", "로그인 후 본 사이트에서 제공하는 모든 기능을 이용하실 수 있습니다.");
				viewPage = "sub-submit.jsp"; //
			}

		} else if(com.equals("/joinFalse.do")) {
			request.setAttribute("message", "이미 존재하는 아이디입니다!");
			viewPage="sub-member-false.jsp";
			
		} else if(com.equals("/userCheck.do")) {
			MemberCommand command = new LoginContent(); // command 종류
			int ri = command.execute(request, response);
			if (ri==1) {
				response.sendRedirect("index.do");
				return;
			} else if (ri==0) { // 비밀번호 오류
				request.setAttribute("message", "비밀번호가 일치하지 않습니다!");
				viewPage="sub-member-false.jsp";
			} else { // 아이디 없음
				request.setAttribute("message", "존재하지 않는 아이디입니다!");
				viewPage="sub-member-false.jsp";
			}
			
		} else if(com.equals("/logout.do")) {
			HttpSession session = request.getSession();
			session.invalidate();
			response.sendRedirect("index.do");
			return;
			
		} else if(com.equals("/myPage.do")) {
			request.setAttribute("page", "myPageFix.do");
			request.setAttribute("title", "회원 정보 수정");
			viewPage="sub-member-editinfo-authentication.jsp";
			
		} else if(com.equals("/myPageFix.do")) {
			MemberCommand command = new myPageContent(); // command 종류
			int ri = command.execute(request, response);
			if (ri==1) {
				viewPage="sub-member-editinfo-fix.jsp";
			} else if (ri==0) { // 비밀번호 오류
				request.setAttribute("message", "비밀번호가 일치하지 않습니다!");
				viewPage="sub-member-false.jsp";
			}
			
		} else if(com.equals("/userFix.do")) {
			MemberCommand command = new UserFixContent(); // command 종류
			command.execute(request, response);
			request.setAttribute("message", "변경이 완료되었습니다!");
			viewPage="sub-member-false.jsp";
			
		} else if(com.equals("/deleteCheck.do")) {
			request.setAttribute("title", "회원 탈퇴");
			request.setAttribute("page", "deletePage.do");
			viewPage="sub-member-editinfo-authentication.jsp";
			
		} else if(com.equals("/deletePage.do")) {
			viewPage="sub-member-editinfo-withdrawalCheck.jsp";	
	
		} else if(com.equals("/delete.do")) {
			MemberCommand command = new DeleteContent(); // command 종류
			command.execute(request, response);
			request.setAttribute("things", "회원 탈퇴가");
			request.setAttribute("message", "지금까지 본 사이트를 이용해주셔서 감사합니다.");
			HttpSession session = request.getSession();
			session.invalidate();
			viewPage = "sub-submit.jsp"; //
			
//		} else if(com.equals("/reply_view.do")) {
//			command = new BReplyViewCommand();
//			command.execute(request, response);
//			viewPage = "reply_view.jsp";
//		} else if(com.equals("/reply.do")) {
//			command = new BReplyCommand();
//			command.execute(request, response);
//			viewPage = "list.do";
		}
	
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
		dispatcher.forward(request, response);
	}

}
