package com.MyZeneration.Model;

public class GraphDTO{
	public GraphDTO(int age, int edu, int firmSize, int workingHour, int job, int marriage, int region, int sex,
			int wage, int hire, int fullTime, int firmType, int sat_workTotal, int sat_spareTime, int sat_lifeTotal,
			int sat_currentLife, int sat_total) {
		super();
		this.age = age;
		this.edu = edu;
		this.firmSize = firmSize;
		this.workingHour = workingHour;
		this.job = job;
		this.marriage = marriage;
		this.region = region;
		this.sex = sex;
		this.wage = wage;
		this.hire = hire;
		this.fullTime = fullTime;
		this.firmType = firmType;
		this.sat_workTotal = sat_workTotal;
		this.sat_spareTime = sat_spareTime;
		this.sat_lifeTotal = sat_lifeTotal;
		this.sat_currentLife = sat_currentLife;
		this.sat_total = sat_total;
	}

	int age, edu, firmSize,	workingHour, job, marriage,
	region,	sex, wage, hire, fullTime, firmType, sat_workTotal,
	sat_spareTime, sat_lifeTotal, sat_currentLife, sat_total;
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getEdu() {
		return edu;
	}

	public void setEdu(int edu) {
		this.edu = edu;
	}

	public int getFirmSize() {
		return firmSize;
	}

	public void setFirmSize(int firmSize) {
		this.firmSize = firmSize;
	}

	public int getWorkingHour() {
		return workingHour;
	}

	public void setWorkingHour(int workingHour) {
		this.workingHour = workingHour;
	}

	public int getJob() {
		return job;
	}

	public void setJob(int job) {
		this.job = job;
	}

	public int getMarriage() {
		return marriage;
	}

	public void setMarriage(int marriage) {
		this.marriage = marriage;
	}

	public int getRegion() {
		return region;
	}

	public void setRegion(int region) {
		this.region = region;
	}

	public int getSex() {
		return sex;
	}

	public void setSex(int sex) {
		this.sex = sex;
	}

	public int getWage() {
		return wage;
	}

	public void setWage(int wage) {
		this.wage = wage;
	}

	public int getHire() {
		return hire;
	}

	public void setHire(int hire) {
		this.hire = hire;
	}

	public int getFullTime() {
		return fullTime;
	}

	public void setFullTime(int fullTime) {
		this.fullTime = fullTime;
	}

	public int getFirmType() {
		return firmType;
	}

	public void setFirmType(int firmType) {
		this.firmType = firmType;
	}

	public int getSat_workTotal() {
		return sat_workTotal;
	}

	public void setSat_workTotal(int sat_workTotal) {
		this.sat_workTotal = sat_workTotal;
	}

	public int getSat_spareTime() {
		return sat_spareTime;
	}

	public void setSat_spareTime(int sat_spareTime) {
		this.sat_spareTime = sat_spareTime;
	}

	public int getSat_lifeTotal() {
		return sat_lifeTotal;
	}

	public void setSat_lifeTotal(int sat_lifeTotal) {
		this.sat_lifeTotal = sat_lifeTotal;
	}

	public int getSat_currentLife() {
		return sat_currentLife;
	}

	public void setSat_currentLife(int sat_currentLife) {
		this.sat_currentLife = sat_currentLife;
	}

	public int getSat_total() {
		return sat_total;
	}

	public void setSat_total(int sat_total) {
		this.sat_total = sat_total;
	}
}
