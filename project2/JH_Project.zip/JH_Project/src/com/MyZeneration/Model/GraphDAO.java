package com.MyZeneration.Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import com.MyZeneration.Model.SatDTO;

public class GraphDAO {
DataSource dataSource;
	
	public GraphDAO() {
		
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g"); // DB와 연결.
		} catch (Exception e) {
			System.out.println("DB 연결 오류!");
			e.printStackTrace();
		}
	}

	public GraphDTO graphData() {
		GraphDTO dto = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			connection = dataSource.getConnection();
			String query = "SELECT * FROM GRAPHDATA";
			preparedStatement = connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
			if(rs.next()) {
				int age = rs.getInt("age");
				int edu = rs.getInt("edu");
				int firmSize = rs.getInt("firmSize");
				int workingHour = rs.getInt("wokringHour");
				int job = rs.getInt("job");
				int marriage = rs.getInt("marriage");
				int region = rs.getInt("region");
				int sex = rs.getInt("sex");
				int wage = rs.getInt("wage");
				int hire = rs.getInt("hire");
				int fullTime = rs.getInt("fullTime");
				int firmType = rs.getInt("firmType");
				int sat_workTotal = rs.getInt("sat_workTotal");
				int sat_spareTime = rs.getInt("sat_spareTime");
				int sat_lifeTotal = rs.getInt("sat_lifeTotal");
				int sat_currentLife = rs.getInt("sat_currentLife");
				int sat_total = rs.getInt("sat_total");
				dto = new GraphDTO(age, edu, firmSize, workingHour, job, marriage, region, sex, wage, hire, fullTime,	firmType,
						sat_workTotal, sat_spareTime, sat_lifeTotal, sat_currentLife, sat_total);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
				if(rs != null) rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return dto;
	}
	
	public ArrayList<CoefDTO> result_coef() {
		ArrayList<CoefDTO> dtos = new ArrayList<>();
		CoefDTO coefDto = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null; 
		try {
			connection = dataSource.getConnection();
			String query = "SELECT * FROM COEFDATA WHERE SAT=?";
			preparedStatement = connection.prepareStatement(query);
			for(int i=0; i<4; i++) { 
				preparedStatement.setInt(1, 10+i);
				rs = preparedStatement.executeQuery();
				if(rs.next()) {
					 double about_marriage=rs.getDouble("about_marriage");
				     double marriage=rs.getDouble("marriage");
				     double car=rs.getDouble("car");
				     double house=rs.getDouble("house");
				     double parents=rs.getDouble("parents");
				     double live_alone=rs.getDouble("live_alone");
				     double house_form=rs.getDouble("house_form");
				     double house_rental=rs.getDouble("house_rental");
				     double health=rs.getDouble("health");
				     double body=rs.getDouble("body");
				     double exercise=rs.getDouble("exercise");
				     double work_life=rs.getDouble("work_life");
				     double real_dream=rs.getDouble("real_dream");
				     double result_procedure=rs.getDouble("result_procedure");
				     double individual_group=rs.getDouble("individual_group");
				     double me_other=rs.getDouble("me_other");
				     double for_happinese=rs.getDouble("for_happinese");
				     double edu=rs.getDouble("edu");
				     coefDto=new CoefDTO(about_marriage, marriage, car, house, parents, live_alone, house_form, house_rental,
				    		 health, body, exercise, work_life, real_dream, result_procedure, individual_group, me_other, for_happinese, edu);
				    dtos.add(coefDto);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
				if(rs != null) rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return dtos;
	}

}
