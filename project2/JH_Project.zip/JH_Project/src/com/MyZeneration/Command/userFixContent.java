package com.MyZeneration.Command;

//import com.google.gson.Gson;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyZeneration.Model.MemberDAO;
import com.MyZeneration.Model.MemberDTO;

public class UserFixContent implements MemberCommand{
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		 
		String id = (String) request.getParameter("uid"); 
		String pw = (String) request.getParameter("pw1"); 
		String name = (String) request.getParameter("uname"); 
		String tel = (String) request.getParameter("utel"); 
		String eMail = (String) request.getParameter("umail"); 
		String sex = (String) request.getParameter("usex"); 
		String birthday = (String) request.getParameter("ubirth");
		MemberDTO dto = new MemberDTO(id, pw, name, eMail, tel, sex, birthday);
		MemberDAO dao = new MemberDAO();
		int ri = dao.updateMember(dto);
		return ri;
	}
}