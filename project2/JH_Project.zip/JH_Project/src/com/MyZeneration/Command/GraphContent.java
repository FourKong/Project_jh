package com.MyZeneration.Command;

import com.google.gson.Gson;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyZeneration.Model.GraphDAO;
import com.MyZeneration.Model.GraphDTO;

public class GraphContent implements GraphCommand{
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		GraphDAO dao = new GraphDAO();
		GraphDTO dto = dao.graphData();
		String dtoJson = new com.google.gson.Gson().toJson(dto);
		request.setAttribute("graph_data", dtoJson);
	}
}