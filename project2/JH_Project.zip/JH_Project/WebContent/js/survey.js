function Flask() {
	
	var radioGroups = {}; // Object to store radio groups by name
    
    // Collect radio groups and their checked status
    $(".survey input[type='radio']").each(function() {
        var groupName = $(this).attr("name");
        if (!radioGroups[groupName]) {
            radioGroups[groupName] = {
                checked: false,
                elements: []
            };
        }
        
        if ($(this).is(":checked")) {
            radioGroups[groupName].checked = true;
        } else {
            radioGroups[groupName].elements.push($(this));
        }
    });
    
    // Find the first radio group with no checked radios and scroll
    for (var groupName in radioGroups) {
        if (!radioGroups[groupName].checked && radioGroups[groupName].elements.length > 0) {
            var targetLi = radioGroups[groupName].elements[0].closest("li.rowLabel");
            var targetOffsetTop = targetLi.offset().top - 100; // Adjust the offset as needed
        
            $('html, body').animate({
                scrollTop: targetOffsetTop
            }, 50);
            return; // Stop after finding the first group without checked radios
        }
    }
	
    var formData = {};
    $("#suv_frm").serializeArray().forEach(function(field) {
        formData[field.name] = field.value;
    });
    
    // Flask 서버
    $.ajax({
        type: "POST",
        url: "http://127.0.0.1:8182/predict",  // Flask 서버 주소
        data: JSON.stringify(formData),
        contentType: "application/json",
        success: function(response) {
            console.log(response);
            for (var key in response) {
                $("<input>").attr({
                    type: "hidden",
                    name: key,
                    value: response[key]
                }).appendTo(".fieldset");
                console.log(response[key]);
            }
            $("#suv_frm").submit();
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log("Error:", textStatus, errorThrown);
        }
    });
    
}


const radioButtons = document.querySelectorAll('input[name="parents"]');
const hiddenButtons1 = document.querySelectorAll('input[name="house_form"]');
const hiddenButtons2 = document.querySelectorAll('input[name="house_rental"]');

const parentElement = document.querySelector('.moreSurvey');

const formDefault = document.querySelector('#form_default');
const rentalDefault = document.querySelector('#rental_default');

for (const radioButton of radioButtons) {
   	radioButton.addEventListener('change', function() {
       	if (radioButton.value === '1') {
        	parentElement.style.display = 'none';
       		for (const hiddenButton of hiddenButtons1) {
       			hiddenButton.checked = false;
      	    }
       		for (const hiddenButton of hiddenButtons2) {
       			hiddenButton.checked = false;
       	    }
       		formDefault.checked=true;
       		rentalDefault.checked=true;
      	} else {
       		parentElement.style.display = 'block';
       		for (const hiddenButton of hiddenButtons1) {
       			hiddenButton.checked = false;
       	    }
       		for (const hiddenButton of hiddenButtons2) {
       			hiddenButton.checked = false;
       	    }
       	}
   	});
}