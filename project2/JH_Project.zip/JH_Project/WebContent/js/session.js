function sessionCheck(session) {
	if (session != "yes") {
		alert("로그인이 필요한 페이지입니다.");
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'login.do';
        document.body.appendChild(form);
        form.submit();
	}
}

function loginHeader(session) {
	if (session == "yes") {
		const log = document.querySelectorAll(".login_myP");
		const user = document.querySelectorAll(".join_logout");
		log.forEach(element => element.innerHTML="<a href=myPage.do>마이 페이지</a></li>"	);
		user.forEach(element => element.innerHTML="<a href=logout.do>로그아웃</a></li>");
	}
}