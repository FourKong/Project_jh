package com.MyZeneration.Command;

//import com.google.gson.Gson;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.MyZeneration.Model.MemberDAO;
import com.MyZeneration.Model.MemberDTO;

public class LoginContent implements MemberCommand{
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		 
		String id = (String) request.getParameter("id"); 
		String pw = (String) request.getParameter("pw"); 
		MemberDAO dao = new MemberDAO();
		MemberDTO dto = dao.takeSession(id);
		int ri = dao.userCheck(id, pw); // 해당 Id를 가진 튜플을 dto에 담아서
		HttpSession session = request.getSession();
		if(ri==1) {
			session.setAttribute("name", dto.getName());
			session.setAttribute("id", id);
			session.setAttribute("isValid", "yes");
			session.setAttribute("isAdmin", dto.getIsAdmin());
		}
		return ri;
	}
} 