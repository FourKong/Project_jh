package com.MyZeneration.Command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyZeneration.Model.BoardDAO;

public class PostContent implements BoardCommand{
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		BoardDAO dao = new BoardDAO();

		String writer = (String) request.getParameter("writer");
		if(writer=="") {writer="사용자";}
		String content = (String) request.getParameter("content"); 
		String title = (String) request.getParameter("title"); 
		String isReply = (String) request.getParameter("isReply");
		int ri = dao.post(writer, title, content, isReply);
		
		return ri;
	}
}