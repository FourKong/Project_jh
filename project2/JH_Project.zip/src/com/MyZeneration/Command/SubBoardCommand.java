package com.MyZeneration.Command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface SubBoardCommand {
	void execute(HttpServletRequest request, HttpServletResponse response);
}
