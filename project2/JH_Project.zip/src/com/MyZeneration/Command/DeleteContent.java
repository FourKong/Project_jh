package com.MyZeneration.Command;

//import com.google.gson.Gson;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;

import com.MyZeneration.Model.MemberDAO;

public class DeleteContent implements MemberCommand{
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		 
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id"); 
		MemberDAO dao = new MemberDAO();
		int ri = dao.deleteMember(id); 
		ri += dao.deleteLogin(id); 
		return ri; // 2여야 함. (0이면 안됨)
	}
} 