package com.MyZeneration.Command;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyZeneration.Model.CoefDTO;
import com.MyZeneration.Model.SatDAO;

public class CoefContent implements CoefCommand{
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		SatDAO dao = new SatDAO();
		ArrayList<CoefDTO> dto = dao.result_coef();
		String dtoJson = new com.google.gson.Gson().toJson(dto);
		request.setAttribute("coef_info", dtoJson);
	}
}