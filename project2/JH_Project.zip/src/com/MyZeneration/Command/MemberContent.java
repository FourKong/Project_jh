package com.MyZeneration.Command;

//import com.google.gson.Gson;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;

import com.MyZeneration.Model.MemberDAO;

public class MemberContent implements MemberCommand{
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		 
		String id = (String) request.getParameter("id"); 
		String pw = (String) request.getParameter("pw"); 
		MemberDAO dao = new MemberDAO();
		int ri = dao.userCheck(id, pw); // 해당 Id를 가진 튜플을 dto에 담아서
		HttpSession session = request.getSession();
		if(ri==1) {
			session.setAttribute("id", id);
			session.setAttribute("isValid", "yes");
		}
		return ri;
	}
} 