package com.MyZeneration.Command;

//import com.google.gson.Gson;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyZeneration.Model.BoardDAO;
import com.MyZeneration.Model.BoardDTO;

public class WatchContent implements BoardCommand{
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		
		String origin_bId = (String) request.getParameter("post"); 
		int bId = Integer.parseInt(origin_bId);
		BoardDAO dao = new BoardDAO();
		dao.hitUp(bId);
		BoardDTO dto = dao.getPost(bId);
		BoardDTO next = dao.getNext(bId);
		BoardDTO prev = dao.getPrev(bId);
		request.setAttribute("dto", dto);
		request.setAttribute("next", next);
		request.setAttribute("prev", prev);
		return 0;
	}
}