package com.MyZeneration.Command;

//import com.google.gson.Gson;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.MyZeneration.Model.BoardDAO;

public class DeletePostContent implements BoardCommand{
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		String sId = (String) session.getAttribute("id");
		System.out.println(sId);
		int admin = (Integer) session.getAttribute("isAdmin");
		String writer = (String) request.getParameter("writer");
		System.out.println(writer);
		String bId = (String) request.getParameter("bId");
		if(sId.equals(writer) || admin == 1) {
			BoardDAO dao = new BoardDAO();
			dao.deletePost(Integer.parseInt(bId));
			return 1;
		}
		return 0;
	}
} 