package com.MyZeneration.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyZeneration.Command.*;

/**
 * Servlet implementation class FrontController
 */
@WebServlet("*.do") // do로 들어오는 모든 패킷 받겠다는 선언.
//@Controller
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FrontController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("doGet");
		actionDo(request, response); // doGet으로 받아도 actionDo로 넘긴다.
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("doPost");
		actionDo(request, response); // 마찬가지로 doPost으로 받아도 actionDo로 넘긴다. 요즘 트렌드(?)
	}
	
	private void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("actionDo");
		
		request.setCharacterEncoding("UTF-8");
		
		String viewPage = null; // 넘겨줄 페이지 정보
		
		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String com = uri.substring(conPath.length());
		
		if (com.equals("/index.do") || com.equals("/")) {
			viewPage = "index.jsp"; 
			
		} else if(com.equals("/satisfaction.do")) { // 기능 1
			//@Autowired
			//@Qualifier("satCommand")
			SatCommand command = new SatContent(); // command 종류.
			int result = command.execute(request, response);
			if(result == 1) { // dao is not null
				viewPage = "main-function1.jsp"; 
				CoefCommand command2 = new CoefContent(); // True일 경우 Coef 정보 받아오기
				command2.execute(request, response);
			} else if (result == 0) { 
				viewPage = "main-function1.jsp"; // ---추후 폼 양식 페이지로!!--추후 폼 양식 페이지로!!--추후 폼 양식 페이지로!!--
			}

		} else if(com.equals("/graph.do")) { // 기능 2
			SatCommand command = new SatContent(); // command 종류.
			int result = command.execute(request, response);
			if(result==1) {
			GraphCommand command2 = new GraphContent(); // command 종류.
			viewPage = "main-function2.jsp";
			command2.execute(request, response);
			} else if (result == 0) {
				viewPage = "main-function2.jsp"; // ---추후 폼 양식 페이지로!!--추후 폼 양식 페이지로!!--추후 폼 양식 페이지로!!--
			}
			
		} else if(com.equals("/join.do")) {
			viewPage = "sub-member-join.jsp";
			
		} else if(com.equals("/login.do")) {
			viewPage = "sub-member-login.jsp";
			
		} else if(com.equals("/joinOK.do")) {
			MemberCommand command = new JoinContent(); // command 종류
			int ri = command.execute(request, response);
			if(ri==1) {
			    viewPage="idDup.do";
			} else if(ri==2) {
			    viewPage="mailDup.do";
			} else if(ri==0) { 

			    response.sendRedirect("joinFin.do"); // 리다이렉트
			    return;
			}
			
		} else if(com.equals("/joinFin.do")) {
			request.setAttribute("things", "회원가입이");
			request.setAttribute("message", "로그인 후 본 사이트에서 제공하는 모든 기능을 이용하실 수 있습니다.");
			viewPage = "sub-submit.jsp"; //

		} else if(com.equals("/idDup.do")) {
			request.setAttribute("message", "이미 존재하는 아이디입니다!");
			viewPage="sub-member-false.jsp";
			
		} else if(com.equals("/mailDup.do")) {
			request.setAttribute("message", "이미 사용중인 이메일입니다!");
			viewPage="sub-member-false.jsp";
			
		} else if(com.equals("/userCheck.do")) {
			MemberCommand command = new LoginContent(); // command 종류
			int ri = command.execute(request, response);
			if (ri==1) {
				response.sendRedirect("index.do");
				return;
			} else if (ri==0) { // 비밀번호 오류
				request.setAttribute("message", "비밀번호가 일치하지 않습니다!");
				viewPage="sub-member-false.jsp";
			} else { // 아이디 없음
				request.setAttribute("message", "존재하지 않는 아이디입니다!");
				viewPage="sub-member-false.jsp";
			}
			
		} else if(com.equals("/logout.do")) {
			HttpSession session = request.getSession();
			session.invalidate();
			response.sendRedirect("index.do");
			return;
			
		} else if(com.equals("/myPage.do")) {
			request.setAttribute("page", "myPageFix.do");
			request.setAttribute("title", "회원 정보 수정");
			viewPage="sub-member-editinfo-authentication.jsp";
			
		} else if(com.equals("/myPageFix.do")) {
			MemberCommand command = new myPageContent(); // command 종류
			int ri = command.execute(request, response);
			if (ri==1) {
				viewPage="sub-member-editinfo-fix.jsp";
			} else if (ri==0) { // 비밀번호 오류
				request.setAttribute("message", "비밀번호가 일치하지 않습니다!");
				viewPage="sub-member-false.jsp";
			}
			
		} else if(com.equals("/userFix.do")) {
			MemberCommand command = new UserFixContent(); // command 종류
			int ri = command.execute(request, response);
			if(ri>0) {
			request.setAttribute("message", "변경이 완료되었습니다!");
			viewPage="sub-member-false.jsp";
			} else {
				request.setAttribute("message", "변경이 실패하였습니다!");
				viewPage="sub-member-false.jsp";
			}
			
		} else if(com.equals("/deleteCheck.do")) {
			request.setAttribute("title", "회원 탈퇴");
			request.setAttribute("page", "deletePage.do");
			viewPage="sub-member-editinfo-authentication.jsp";
			
		} else if(com.equals("/deletePage.do")) {
			viewPage="sub-member-editinfo-withdrawalCheck.jsp";	
	
		} else if(com.equals("/delete.do")) {
			MemberCommand command = new DeleteContent(); // command 종류
			command.execute(request, response);
			request.setAttribute("things", "회원 탈퇴가");
			request.setAttribute("message", "지금까지 본 사이트를 이용해주셔서 감사합니다.");
			HttpSession session = request.getSession();
			session.invalidate();
			viewPage = "sub-submit.jsp"; //
			
		} else if(com.equals("/findId.do")) {
			viewPage = "sub-member-idFind.jsp"; 
			
		} else if(com.equals("/findIdOK.do")) {
			MemberCommand command = new FindIdContent(); // command 종류
			int ri = command.execute(request, response);
			if (ri==1) {
				viewPage = "sub-member-idFind-result.jsp"; 
			} else if (ri==0) { // 입력 정보 불일치
				request.setAttribute("message", "입력 정보를 확인해주세요!");
				viewPage="sub-member-false.jsp";
			}
			
		} else if(com.equals("/findPw.do")) {
			viewPage = "sub-member-pwFind.jsp"; 
			
		} else if(com.equals("/findPwOK.do")) {
			MemberCommand command = new FindPwContent(); // command 종류
			int ri = command.execute(request, response);
			if (ri==1) {
				viewPage = "sub-member-pwFind-change.jsp"; 
			} else if (ri==0) { // 입력 정보 불일치
				request.setAttribute("message", "입력 정보를 확인해주세요!");
				viewPage="sub-member-false.jsp";
			}
			
		} else if(com.equals("/pwFix.do")) {
			MemberCommand command = new PwFixContent(); // command 종류
			int ri = command.execute(request, response);
			if (ri>0) {
				request.setAttribute("things", "비밀번호 변경이");
				request.setAttribute("message", "변경된 비밀번호로 로그인해주시기 바랍니다.");
				viewPage = "sub-submit.jsp"; //
			} else {
				request.setAttribute("message", "변경이 실패하였습니다!");
				viewPage="sub-member-false.jsp";
			}
			
		} else if(com.equals("/board.do")) {
			BoardCommand command = new ListContent(); // command 종류
			command.execute(request, response);
			viewPage = "sub-board-list.jsp"; 
		
		} else if(com.equals("/post.do")) {
			viewPage = "sub-board-post.jsp";
			
		} else if(com.equals("/reply.do")) {
			BoardCommand command = new ReplyContent(); // command 종류
			command.execute(request, response);
			viewPage = "sub-board-reply.jsp";
			
		} else if(com.equals("/posting.do")) {
			BoardCommand command = new PostContent(); // command 종류
			command.execute(request, response);
		    response.sendRedirect("board.do"); // 리다이렉트
		    return;
			
		} else if(com.equals("/watch.do")) {
			BoardCommand command = new WatchContent(); // command 종류
			command.execute(request, response);
			viewPage = "sub-board-watch.jsp"; 
			
		} else if(com.equals("/deletePost.do")) {
			BoardCommand command = new DeletePostContent(); // command 종류
			command.execute(request, response);
			response.sendRedirect("board.do"); // 리다이렉트
		    return;
		}
	
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
		dispatcher.forward(request, response);
	}

}
