const radioButtons = document.querySelectorAll('input[name="parents"]');
const hiddenButtons1 = document.querySelectorAll('input[name="house_form"]');
const hiddenButtons2 = document.querySelectorAll('input[name="house_rental"]');

const parentElement = document.querySelector('.moreSurvey');

const formDefault = document.querySelector('#form_default');
const rentalDefault = document.querySelector('#rental_default');

for (const radioButton of radioButtons) {
   	radioButton.addEventListener('change', function() {
       	if (radioButton.value === '1') {
        	parentElement.style.display = 'none';
       		for (const hiddenButton of hiddenButtons1) {
       			hiddenButton.checked = false;
      	    }
       		for (const hiddenButton of hiddenButtons2) {
       			hiddenButton.checked = false;
       	    }
       		formDefault.checked=true;
       		rentalDefault.checked=true;
      	} else {
       		parentElement.style.display = 'block';
       		for (const hiddenButton of hiddenButtons1) {
       			hiddenButton.checked = false;
       	    }
       		for (const hiddenButton of hiddenButtons2) {
       			hiddenButton.checked = false;
       	    }
       	}
   	});
}