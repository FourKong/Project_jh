const sat_order = new Array("all", "living", "health", "human"); // 템플릿 리터럴에 사용할 배열.

const having_order = new Array("marriage", "car", "house"); // 템플릿 리터럴에 사용할 배열.

const value_order = new Array("work_life", "real_dream", "result_procedure", "individual_group", "me_other");

// 그래프 만드는 함수

function makeGraph(DBdata) {
	
	let avg = [];

      // ★★★★★만족도 그래프 코드 시작!★★★★★

	for (let i = 0; i < sat_order.length; i++) {
		var chartData = {
			labels: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], // x축 레이블.
			datasets: [{ // 데이터 외형 설정
				data: [], // 아래의 push를 통해 데이터 받음.
				backgroundColor: [ // 막대바 색상       
					'rgba(255, 000, 000, 0.2)',
					'rgba(255, 159, 64, 0.2)',
					'rgba(255, 051, 222, 0.2)',
					'rgba(153, 051, 000, 0.2)',
					'rgba(255, 206, 86, 0.2)',
					'rgba(40, 205, 30, 0.2)',
					'rgba(75, 192, 192, 0.2)',					
					'rgba(102, 204, 255, 0.2)',
					'rgba(54, 162, 235, 0.2)',
					'rgba(153, 102, 255, 0.2)'
					],
				borderColor: [ // 막대 테두리 색상              
					'rgba(255, 00, 000, 1)',
					'rgba(255, 159, 64, 1)',
					'rgba(255, 051, 222, 1)',
					'rgba(153, 051, 000, 1)',
					'rgba(255, 206, 86, 1)',
					'rgba(40, 205, 30, 1)',
					'rgba(75, 192, 192, 1)',					
					'rgba(102, 204, 255, 1)',
					'rgba(54, 162, 235, 1)',				
					'rgba(153, 102, 255, 1)'
					],
					borderWidth: 1.5 // 테두리 두께
		}]
	};

	var ctx = document.querySelector(`#${sat_order[i]}Chart`).getContext('2d');
        
	let sum=0;
    for (let a=0; a<10; a++) {
    	let count=0;
    	for (const key in DBdata) { 
    		if (DBdata.hasOwnProperty(key)) {
    			if (DBdata[key][`sat_${sat_order[i]}`] === a+1) {
    				count++;
    			}
    		}
    	}
    	chartData.datasets[0].data.push(count); // 데이터 입력.
		sum += count*(a+1);
    }
	avg.push(Math.round((sum/DBdata.length)*10)/10);
	
        // 그래프 생성
        new Chart(ctx, { 
          type: 'bar',
          data: chartData,
          options: {
            responsive: true, // 반응형 해제
            legend: {
              display: false, // 범례 표시 ON.
              labels: {
                boxWidth: 15 // 범례박스 크기
              }
            },
            scales: { // x, y축 관련 설정
            }
          }
        });
      } // Sat_for문 종료.

      // 만족도 그래프 코드 끝!

    // ★★★★★여부 관련 그래프 코드 시작!★★★★★

	for (let i = 0; i < having_order.length; i++) {
		var chartData = {
			labels: [], // x축 레이블. 아래서 push를 통해 받을 것.
			datasets: [{ // 데이터 외형 설정
				data: [], // 아래의 push를 통해 데이터 받음.
				backgroundColor: [ // 막대바 색상   
					'rgba(54, 162, 235, 0.2)',
					'rgba(255, 00, 000, 0.2)'
					],
				borderColor: [ // 막대 테두리 색상   
					'rgba(54, 162, 235, 1)',
					'rgba(255, 00, 000, 1)'			
					],
					borderWidth: 1 // 테두리 두께
		}]
	};
		
		if(having_order[i]=='marriage') {
			chartData.labels.push('기혼');
			chartData.labels.push('미혼');
		} else {
			chartData.labels.push('보유');
			chartData.labels.push('미보유'); 
		}

	var ctx = document.querySelector(`#${having_order[i]}Chart`).getContext('2d');
	
	let have=0;
    for (let a=0; a<2; a++) {
    	let count = 0;
    	for (const key in DBdata) { 
    		if (DBdata.hasOwnProperty(key)) {
    			if (DBdata[key][`${having_order[i]}`] === a+1) {
    				count++;
    			}
    		}
    	}
    	if(a==0) {have+=count}
    	chartData.datasets[0].data.push(count); // 데이터 입력.
    }
	avg.push(Math.round((have/DBdata.length)*1000)/10);
	
        // 그래프 생성
        new Chart(ctx, { 
          type: 'pie',
          data: chartData,
          options: {
            responsive: true, // 반응형 해제
            aspectRatio: 2, // 가로 : 세로(1) 비율
            legend: {
              display: false, // 범례 표시 ON.
              labels: {
                boxWidth: 15 // 범례박스 크기
              }
            },
            scales: { // x, y축 관련 설정
            }
          }
        });
      } // have_for문 종료.

      // 여부 관련 그래프 코드 끝!
	
    // ★★★★★가치관 관련 그래프 코드 시작!★★★★★
	
	const first_thing = ['일', '현실', '결과', '개인', '주관'];
	const second_thing = ['여가', '이상', '과정', '단체', '이목'];
	
	let explains = [];
	
	let color = ['rgba(255, 00, 000, 0.2)', 'rgba(255, 159, 64, 0.2)', 
					'rgba(75, 192, 192, 0.2)', 'rgba(54, 162, 235, 0.2)', 'rgba(153, 102, 255, 0.2)']
	let color_border = ['rgba(255, 00, 000, 1)', 'rgba(255, 159, 64, 1)', 
		'rgba(75, 192, 192, 1)', 'rgba(54, 162, 235, 1)', 'rgba(153, 102, 255, 1)']

	for (let i = 0; i < value_order.length; i++) {
		var chartData = {
			labels: [`${first_thing[i]}`,1,2,3,4,5,6,7,`${second_thing[i]}`], // x축 레이블. 아래서 push를 통해 받을 것.
			datasets: [{ // 데이터 외형 설정
				data: [0], // 아래의 push를 통해 데이터 받음.
				backgroundColor: [ // 막대바 색상   
					color[i]
					],
				borderColor: [ // 막대 테두리 색상   
					color_border[i]
					],
					borderWidth: 1 // 테두리 두께
		}]
	};
		
	var ctx = document.querySelector(`#${value_order[i]}Chart`).getContext('2d');
	
	let sum=0;
    for (let a=0; a<7; a++) {
    	let count = 0;
    	for (const key in DBdata) { 
    		if (DBdata.hasOwnProperty(key)) {
    			if (DBdata[key][`${value_order[i]}`] === a+1) {
    				count++;
    			}
    		}
    	}
		sum += count*(a+1);
    	chartData.datasets[0].data.push(count); // 데이터 입력.
    }
	chartData.datasets[0].data.push(0);
	let avg_result = Math.round((sum/DBdata.length)*10)/10;
	avg.push(avg_result);
	if(avg_result<2.8) {
		explains.push(`<span class="blue">${first_thing[i]}</span>에 대한 것을 매우 중시하는 경향을 보입니다.`);
	} else if(avg_result<3.6) {
		explains.push(`${first_thing[i]}의 중요성을 조금 더 높게 여깁니다.`);
	} else if(avg_result<4.4) {
		explains.push(`${first_thing[i]} · ${second_thing[i]} 양측을 비슷하게 생각하는 것으로 나타납니다.`);
	} else if(avg_result<=5.2) {
		explains.push(`${second_thing[i]}의 중요성을 조금 더 높게 여깁니다.`);
	} else if(avg_result<=7) {
		explains.push(`${second_thing[i]}에 대한 것을 매우 중시하는 경향을 보입니다.`);
	}

        // 그래프 생성
        new Chart(ctx, { 
          type: 'line',
          data: chartData,
          options: {
            responsive: true, // 반응형 해제
            aspectRatio: 2, // 가로 : 세로(1) 비율
            legend: {
              display: false, // 범례 표시 ON.
              labels: {
                boxWidth: 15 // 범례박스 크기
              }
            },
            scales: { // x, y축 관련 설정
            }
          }
        });
      } // value_for문 종료.

      // 가치관 관련 그래프 코드 끝!

	let avgs = document.querySelectorAll(".highlight");

	for(let i=0; i<avgs.length; i++) {
		avgs[i].innerHTML = `${avg[i]}`;
	}
	
	let exps = document.querySelectorAll(".explain_val");
	
	for(let i=0; i<exps.length; i++) {
		exps[i].innerHTML = `${explains[i]}`;
	}

}

function fixText(category, userData) {

	let first_cat = document.querySelector(".first_sel");
	let second_cat = document.querySelector(".second_sel");
	let explain_cat = document.querySelectorAll(".explain_sel");
	
	var cat_name;
	var cat_data;
	var cat_ex;
	if(category == 'house' || category ==  'car' || category ==  'marriage') {
		let hidden = document.querySelector(`.${category}Per`);
		hidden.style.display = 'none';
	}
	
	if(category == 'sex') {
		cat_name="성별";
		if(userData == 1) cat_data='남성';
		else if (userData==2) cat_data='여성';
	}else if(category == 'age') {
		cat_name="연령";
		if(userData == 1) cat_data='10대 후반';
		else if (userData==2) cat_data='20대 초반';
		else if (userData==3) cat_data='20대 중반';
		else if (userData==4) cat_data='20대 후반';
		else if (userData==5) cat_data='30대 초반';
	}else if(category == 'edu') {
		cat_name="학력";
		if (userData==2) cat_data='고등학교 졸업';
		else if (userData==3) cat_data='전문대 졸업';
		else if (userData==4) cat_data='4년제 졸업';
		cat_ex = `${cat_data}자`;
		if(userData == 1) cat_data='중졸 이하', cat_ex = null;
		else if (userData==5) cat_data='석사 이상', cat_ex = null;
	}else if(category == 'marriage') {
		cat_name="혼인";
		if(userData == 1) cat_data='기혼', cat_ex='기혼자';
		else if (userData==2) cat_data='미혼', cat_ex='미혼자';
	}else if(category == 'car') {
		cat_name="자차";
		if(userData == 1) cat_data='보유', cat_ex='자동차 보유자';
		else if (userData==2) cat_data='미보유', cat_ex='자동차 미보유자';
	}else if(category == 'house') {
		cat_name="자가";
		if(userData == 1) cat_data='보유', cat_ex='자가 보유자';
		else if (userData==2) cat_data='미보유', cat_ex='자가 미보유자';
	}
	
	if(cat_ex==null) cat_ex = cat_data;
	
	first_cat.innerHTML = cat_name;
	second_cat.innerHTML = cat_data;
	explain_cat.forEach((sel) => sel.innerHTML = cat_ex);
	
}