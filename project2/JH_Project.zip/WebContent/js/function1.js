function makePage(req, info, coef, name) {
  const which = new Array("me", "other");
  const sat_type = new Array("전체", "생활수준", "건강", "대인관계")
  const sat_me = new Array("all", "living", "health", "human"); // 템플릿 리터럴에 사용할 배열.
  const sat_color = new Array('rgba(60,179,113,0.8)', 'rgba(0,191,255, 0.8)', 'rgba(250,128,114,0.8)');
  for(let i = 0; i <2; i++) {
    for (let j = 0; j < sat_me.length; j++) {

    // 도넛 그래프 생성
    var ctx = document.querySelector(`#sat_${sat_me[j]}_${which[i]}`).getContext('2d');
    
    let color;
    if (i==0) {
    	if (req[i][j] == req[i+1][j]) {
    		color = sat_color[0];
    	} else if (req[i][j] > req[i+1][j]) {
    		color = sat_color[1];
    	} else if (req[i][j] < req[i+1][j]) {
    		color = sat_color[2];
    	}
    } else color = 'rgba(128,128,128,0.8)';
    let score = req[i][j];

let titleSize =$(`#sat_${sat_me[j]}_${which[i]}`).width()*0.087;

    // 그래프 생성
    var myChart = new Chart(ctx, { // 그래프 생성용 변수라 원래 안 쓰이는 게 맞음.
      type: 'doughnut',
        data: {
          labels: [], // x축 레이블
          datasets: [{ // 데이터 외형 설정
            data: [score, 10-score], // 아래의 push를 통해 데이터 받음.
            backgroundColor: [ // 막대바 색상       
            color,
            'rgb(255,255,255)'
            ],
            borderColor: [ // 막대 테두리 색상              
            color,
            color
            ],
            borderWidth: 2 // 테두리 두께
          }]
        },
        options: {
          tooltips: {enabled: false},
          hover: {mode: null},
          elements: {
            center: {
              text: `${score}점`,
              title: `${sat_type[j]} 만족도`,
              titleSize: titleSize,
              color: color, // Default is #000000
              fontStyle: 'GmarketSansMedium', // Default is Arial
              sidePadding: 20, // Default is 20 (as a percentage)
              minFontSize: 10, // Default is 20 (in px), set to false and text will not wrap.
              lineHeight: 25 // Default is 25 (in px), used for when text wraps
            },
          },
          responsive: false,
          cutoutPercentage: 90, // 중앙 구멍 크기
          legend: {
            display: false
          },
          layout: {
            padding: 0
          }
        }
      });
    }
  }
  // --------- 이하 나의 정보 관련 ----------
  let sex = info[0];let age = info[1];let about_marriage = info[2];let marriage = info[3];
  let car = info[4];let house = info[5];let parents = info[6];let live_alone = info[7];
  let house_form = info[8];let house_rental = info[9];let health = info[10];let body = info[11];
  let exercise = info[12];let work_life = info[13];let real_dream = info[14];let result_procedure = info[15];
  let individual_group = info[16];let me_other = info[17];let for_happinese = info[16];let edu = info[17];

  let age_info = document.querySelectorAll(".my_age")
  let sex_info = document.querySelectorAll(".my_sex")
  let edu_info = document.querySelectorAll(".my_edu")
  let marriage_info = document.querySelectorAll(".my_marriage")
  let house_info = document.querySelectorAll(".my_house")
  let car_info = document.querySelectorAll(".my_car")
  if(age==1) {
		for(let i =0; i<2; i++) {age_info[i].innerHTML="10대 후반";}
  } else if(age==2) {
 	for(let i =0; i<2; i++) {age_info[i].innerHTML="20대 초반";}
  } else if(age==3) {
 	for(let i =0; i<2; i++) {age_info[i].innerHTML="20대 후반";}
  } else if(age==4) {
 	for(let i =0; i<2; i++) {age_info[i].innerHTML="30대 초반";}
  }
  if(sex==1) {
 	for(let i =0; i<2; i++) {sex_info[i].innerHTML = "남성";}
  } else if(sex==2) {
 	for(let i =0; i<2; i++) {sex_info[i].innerHTML = "여성";}
  }
  if(edu==1) {
 	for(let i =0; i<2; i++) {edu_info[i].innerHTML = "중졸 이하";}
  } else if(edu==2) {
 	for(let i =0; i<2; i++) {edu_info[i].innerHTML = "고졸";}
  } else if(edu==3) {
 	for(let i =0; i<2; i++) {edu_info[i].innerHTML = "전문대졸";}
  } else if(edu==4) {
 	for(let i =0; i<2; i++) {edu_info[i].innerHTML = "4년제졸";}
  } else if(edu==5) {
 	for(let i =0; i<2; i++) {edu_info[i].innerHTML = "석·박사";}
  }
  if(marriage==1) {
 	for(let i =0; i<2; i++) {marriage_info[i].innerHTML = "기혼";}
  } else if(marriage==2) {
 	for(let i =0; i<2; i++) {marriage_info[i].innerHTML = "미혼";}
  }
  if(car==1) {
 	for(let i =0; i<2; i++) {car_info[i].innerHTML = "보유";}
  } else if(car==2) {
 	for(let i =0; i<2; i++) {car_info[i].innerHTML = "미보유";}
  }
  if(house==1) {
 	for(let i =0; i<2; i++) {house_info[i].innerHTML = "보유";}
  } else if(house==2) {
 	for(let i =0; i<2; i++) {house_info[i].innerHTML = "미보유";}
  }
  let life_value = [work_life, real_dream,result_procedure, individual_group, me_other];
  for(let i = 0; i<life_value.length; i++) {
  	var value_a = document.querySelectorAll(`.v-${i+1}-a`);
  	var value_b = document.querySelectorAll(`.v-${i+1}-b`);
  	if(life_value[i]==4) {
  		for(let j=0; j<2; j++) {
  			value_a[j].style.color='green';
  			value_a[j].style.fontSize='115%';
			value_a[j].style.fontWeight='bold';
  			value_b[j].style.color='green';
  			value_b[j].style.fontSize='115%';
			value_b[j].style.fontWeight='bold';
  		}
  	}else if(life_value[i]>4) {
  		for(let j=0; j<2; j++) {
  			value_a[j].style.color='gray';
  			value_a[j].style.fontSize='85%';
  			value_b[j].style.color='darkblue';
  			value_b[j].style.fontSize='115%';
			value_b[j].style.fontWeight='bold';
  		}
  	}else if(life_value[i]<4) { 
  		for(let j=0; j<2; j++) {
  			value_b[j].style.color='gray';
  			value_b[j].style.fontSize='85%';
  			value_a[j].style.color='darkblue';
  			value_a[j].style.fontSize='115%';
			value_a[j].style.fontWeight='bold';
  		}
  	}
  }
  // --------- 이하 추천 사항 관련 ----------
  const sat_set = ["전체", "생활수준", "건강", "대인관계"];
  const text_box = document.querySelectorAll(".rmd-updown");
  for(let i=0; i<coef.length; i++){
	  let enough = 0;
	  const coef_set = []
	  for (const key in coef[i]) {
		  const value = coef[i][key];
		  if (Math.abs(value)>0.25) {
			  if(key=="about_marriage") {
				  if(value > 0 && about_marriage!=3) {
					  coef_set.push([value, "<span>결혼에 대한 가치관</span>입니다. 결혼이 필요하다고 생각하는 경향이 짙을수록 만족도가 높게 나타났습니다. " +
					  		"<br>결혼이 필요 없거나 해도 그만 안 해도 그만이라고 생각하신다면, 생각을 바꿔서 인생의 동반자에 대해 고민해보시는 것을 추천드립니다."]);
				  } else if (value < 0 && about_marriage!=1) {
					  coef_set.push([value, "<span>결혼에 대한 가치관</span>입니다. 결혼이 필요없다고 생각하는 경향이 짙을수록 만족도가 높게 나타났습니다. " +
					  		"<br>결혼이 반드시 필요하다고 생각하시다면, 인생의 동반자의 필요성에 대해 재고해보시는 것을 추천드립니다."]);}
			  } else if (key=="marriage"){ // 결혼 안 한 경우
				  if(value < 0 && marriage==2) {coef_set.push([value, "<span>결혼</span>입니다. 결혼을 한 경우가 일반적으로 만족도가 높게 나타났습니다. " +
				  		"<br>당장 결혼 계획이 없으시다면, 천천히 주위를 둘러보고 결혼에 대해 고려해보는 것을 추천드립니다."]);}
			  } else if (key=="car") { // 차 없는 경우
				  if(value < 0 && car==2) {coef_set.push([value, "<span>자차 유무</span>입니다. 자차를 보유한 것이 만족도에 영향을 주는 것으로 분석되었습니다. " +
				  		"<br>저렴한 중고차를 구매하시거나, 조금 무리해서라도 멋진 신차를 구매하신다면 당신의 만족도가 눈에 띄게 상승할 것입니다."]);}
			  } else if (key=="house") { // 집 없는 경우만.
				  if(value < 0 && house==2) {coef_set.push([value, "<span>자가 유무</span>입니다. 자가를 보유한 것이 만족도에 영향을 주는 것으로 분석되었습니다. " +
				  		"<br>내 집 마련을 위해 대출을 받아보시는 것은 어떨까요? 대출로 인한 상심보다 내 집 마련으로 인한 행복이 더 크게 와닿을 것입니다."]);}
			  } else if (key == "parents") { // 부모 동거
				  if(value < 0 && parents!=1) {
					  coef_set.push([value, "<span>부모 동거 여부</span>입니다. 일반적으로 부모와 함께 사는 경우, 만족도가 높은 것으로 보여집니다. " +
					  		"<br>부모와 별거중인 당신! 여건이 된다면, 부모님 곁으로 돌아가세요! 부모님과 함께 사는 것이 정서적으로 만족감을 줄 것입니다."]);
				  } else if(value > 0 && parents!=3) {
					  coef_set.push([value, "<span>부모 동거 여부</span>입니다. 일반적으로 부모로부터의 독립 정도가 강할수록 만족도가 높게 나타납니다. " +
					  		"<br>특히 단순 별거보다, 경제적으로도 완전히 독립한 경우가 만족도가 높게 나타납니다. 지금부터 천천히 독립을 준비해보세요."]);
				  }
	          } else if (key == "live_alone") { // 1인 가구
				  if(value < 0 && live_alone!=1) {
					  coef_set.push([value, "<span>1인 가구 여부</span>입니다. 전체적으로 혼자 사는 사람들의 만족도가 더 높은 경향을 보입니다. " +
					  		"<br>가능하다면, 혼자만의 공간에서 새 삶을 꾸려보는 것은 어떨까요? 불가능하다면 혼자만의 시간을 늘리고, 혼자만의 공간을 가꾸는 것도 하나의 방법일 것입니다."]);
				  } else if (value > 0 && parents!=2){
					  coef_set.push([value, "<span>1인 가구 여부</span>입니다. 혼자 사는 사람들은 해당 만족도가 낮게 나타납니다. " +
					  		"<br>부모, 형제, 친구, 애인이 있다면, 그들과 당신의 삶의 공간을 공유해보세요. 당장 동거할 수 없는 상황이라면, 종종 그들에게 찾아가 하루이틀을 보내고 오는 것도 하나의 방법일 것입니다."]);
				  }
	          } else if (key == "house_form") { // 주택 형태
				   if (value > 0){
					  coef_set.push([value, "<span>주택 형태</span>입니다. 원룸보단 빌라, 빌라보단 단독주택 및 아파트, 오피스텔에 거주하는 것이 만족도가 높게 나타납니다. " +
					  		"<br>주택 형태와 무관하게 부모와 동거하는 것도 만족도를 올리는 비결입니다. 이사를 통해 새로운 공간에서 더 나은 삶을 영위해보세요."]);
				  }
	          } else if (key == "house_rental") { // 자가 아닌 경우만
				  if(value > 0 && house_rental!=3){
					  coef_set.push([value, "<span>주택 점유 형태</span>입니다. 월세보단 전세가, 전세보단 자가 보유가 더 높은 만족도를 보여줍니다. " +
					  		"<br>현재 월세에 거주하고 있다면 전세로 바꾸는 것도 좋은 방법입니다. 대출을 통해 내 집을 마련하는 것도 좋은 방법이며, 상황이 여의치 않다면 부모님과 함께 살면서 집에 드는 돈을 줄이는 것도 만족도를 올리는 방법 중 하나입니다."]);
				  }
	          } else if (key == "health") {  
				  if(value < 0 && health!=1) {
					  coef_set.push([value, "<span>건강</span>입니다. 건강이 만족도에 끼치는 영향이 작지 않다는 사실, 알고 계셨나요? " +
					  		"<br>건강 검진을 한 번 받아보시는 것은 어떨까요? 아니면 꾸준한 운동, 영양제 섭취, 숙면 등의 방법으로 건강과 만족도를 한 번에 올려보세요!"]);
				  }
	          } else if (key == "body") {  
	        	  if(value < 0 && body!=1) {
					  coef_set.push([value, "<span>체형</span>입니다. 체중이 많이 나갈수록, 비만일수록 만족도가 떨어지는 경향이 나타납니다. " +
					  		"<br>건강을 위해서, 스스로의 신체를 가꾸기 위해서, 행복을 위해서! 다양한 방법으로 당신의 체형을 교정해보세요. 효과는 즉시 나타날 것입니다."]);
	        	  }
	          } else if (key == "exercise") {  
				  if(value < 0 && exercise!=1) {
					  coef_set.push([value, "<span>운동</span>입니다. 지나친 운동은 당신의 만족도를 떨어뜨립니다. " +
					  		"<br>운동이 삶에 긍정적 영향을 끼친다는 사실은 부정할 수 없지만, 당신의 운동량이 너무 많거나, 운동의 정도가 격하다면 오히려 만족도가 떨어질 수 있습니다. 본인에게 맞는 적절한 운동 강도와 횟수를 찾아보세요!"]);
				  } else if (value > 0 && exercise!=5) {
					  coef_set.push([value, "<span>운동</span>입니다. 운동량이 많다면, 당신의 만족도도 높아집니다." +
					  		"<br>당신의 여력이 충분하다면, 운동량을 높여 건강과 행복을 동시에 잡아보세요!"]);
				  }
	          } else if (key == "work_life") {  
				  if(value < 0 && work_life>2){
					  coef_set.push([value, "<span>일과 여가에 대한 가치관</span>입니다. 일을 중요하게 여기는 사람일수록 만족도가 높게 나타났습니다. " +
					  		"<br>장기적인 행복을 위해서, 눈 앞의 안락함보다는 일에 조금만 더 집중해보시는 건 어떨까요?"]);
				  } else if (value > 0 && work_life<5){
					  coef_set.push([value, "<span>일과 여가에 대한 가치관</span>입니다. 여가를 중요하게 여기는 사람일수록 만족도가 높게 나타났습니다. " +
					  		"<br>너무 일에 몰입하고 있진 않은가요? 열심히 일하는 것도 좋습니다만, 조금만 숨을 돌리고 주위를 둘러보세요. 행복은 멀리 있지 않습니다."]);
				  }
	          } else if (key == "real_dream") {  
				  if(value < 0 && real_dream>2) {
					  coef_set.push([value, "<span>현실과 이상에 대한 가치관</span>입니다. 현실을 중시하는 사람일수록 행복의 정도가 높습니다. " +
					  		"<br>지나치게 이상적인 것을 좇고 계시진 않습니까? 조금만 더 현실적인 사람이 되어보세요. 현실적인 행복이 당신을 기다릴 것입니다."]);  
				  } else if (value > 0 && real_dream<5) {
					  coef_set.push([value, "<span>현실과 이상에 대한 가치관</span>입니다. 이상을 중시하는 사람일수록 행복의 정도가 높습니다. " +
					  		"<br>너무 현실에 목매지 마세요. 조금만 더 당신의 이상을 관철해보는 건 어떨까요? 당신의 꿈을 소중히 간직하세요."]);  
				  }
	          } else if (key == "result_procedure") {  
				  if(value < 0 && result_procedure>2) {
					  coef_set.push([value, "<span>결과와 과정에 대한 가치관</span>입니다. 결과를 중시하는 사람이 만족도도 높게 나타납니다. " +
					  		"<br>과정 또한 중요하지만, 결과가 따라주지 않는다면 쉽게 만족할 수 없겠죠. 과정에 만족하지 말고, 결과가 나올 때까지 노력하는 사람이 되어보세요."]);  
				  } else if (value > 0 && result_procedure<5) {
					  coef_set.push([value, "<span>결과와 과정에 대한 가치관</span>입니다. 과정을 중시하는 사람이 만족도도 높게 나타납니다. " +
					  		"<br>결과도 중요하지만, 그 과정에서 얼마나 노력했느냐도 당신의 만족도에 큰 영향을 미칩니다. 결과를 위해 과정을 경시하지 마세요. 당신이 노력해온 순간순간이 곧 당신의 행복입니다."]);  
				  }
	          } else if (key == "individual_group") {  
				  if(value < 0 && individual_group>2) {
					  coef_set.push([value, "<span>개인과 단체에 대한 가치관</span>입니다. 개인을 중요하게 여길수록 높은 만족도를 보입니다. " +
					  		"<br>단체 생활에 너무 집착하고 있진 않나요? 단체보다는 조금 더 자기 자신을 소중히 여겨보세요. 그것이 행복을 향해 내딛는 첫 발걸음이 될 겁니다."]);  
				  } else if (value > 0 && individual_group<5) {
					  coef_set.push([value, "<span>개인과 단체에 대한 가치관</span>입니다. 단체를 중요하게 여길수록 높은 만족도를 보입니다. " +
					  		"<br>너무 개인 중심적인 생활을 하고 있지는 않나요? 단체 생활 속에서만 느낄 수 있는 행복도 있는 법입니다. 조금 더 주위를 둘러보고, 주위 사람들과 어울리려는 노력을 해봅시다."]);   
				  }
	          } else if (key == "me_other") {
				  if(value < 0 && me_other>2) { 
					  coef_set.push([value, "<span>자기 주관과 타인의 이목에 대한 가치관</span>입니다. 타인의 시선에 얽매이지 않고, 뚜렷한 자기 주관을 가진 사람이 더 행복한 삶을 산다고 합니다. " +
					  		"<br>자기 주관을 좀 더 확고히 해보세요. 타인의 시선에 지나치게 얽매일 필요는 없습니다. 행복은 남이 주는 것이 아니라, 당신 스스로가 만드는 것입니다."]);  
				  } else if (value > 0 && me_other<5) {
					  coef_set.push([value, "<span>자기 주관과 타인의 이목에 대한 가치관</span>입니다. 자기 주관도 중요하지만, 타인의 이목에 관심을 두는 사람이 더 행복한 삶을 산다고 합니다. " +
					  		"<br>세상은 남들과 어우러져 살아가는 곳입니다. 타인의 시선이란 말이 언뜻 부정적으로 들릴 수 있지만, 자존감은 타인과의 관계 속에서 형성되는 것입니다. 조금만 남들이 나를 어떻게 생각하는지 돌아보세요."]);  
				  }
	          } else if (key == "for_happinese") {  
//				  coef_set.push([value, "11"]);
	          } else if (key == "edu") {  
				  if(value > 0 && edu!=5) {
					  coef_set.push([value, "<span>학력</span>입니다. 높은 학력은 당신에게 큰 만족감을 가져다줍니다." +
					  		"<br>우리는 아직 젊기 때문에, 공부를 위해 충분한 시간을 할애할 수 있습니다. 공부에 뜻을 두고, 더 높은 곳을 향해 도전해보세요."]);  
				  }
				  
	          }
		  } 
	  } // for문 종료.
	  coef_set.sort(compareValuesDescending);
	  let abj, sug;
	  let isNull = ["가장 큰 영향을 끼치는 것은", "두 번째로 영향을 주는 요인은", "대해 마지막으로 추천드리는 요소는"];
	  if (req[0][i] == req[1][i]) {
		  abj = "과 같습니다.";
		  if (req[0][i] >= 9) sug = "<br>이미 만족도가 충분히 높아, 저희의 제안이 필요하지 않을 것 같습니다. 이번 만족도는 넘어갈게요.";
          else sug = "<br>그러나 만족도가 더 올라갈 여지가 남아있네요. 다음과 같은 방법을 제안드려요."
	  }
	  else if (req[0][i] > req[1][i]) {
		  abj = "보다 높군요!";
		  if (req[0][i] >= 9) {sug = "<br>이미 만족도가 충분히 높아, 저희의 제안이 필요하지 않을 것 같습니다. 다음 만족도로 넘어가볼게요.";
		  enough=1;}
		  else sug = "<br>그러나 만족도가 더 올라갈 여지가 남아있네요. 다음과 같은 방법을 제안드려요."
	  }
	  else abj = "보다 낮네요.", sug = "<br>하지만 걱정하지 마세요. 만족도를 향상시킬 다음과 같은 방법을 제안드립니다.";
	  
	  text_box[i].innerHTML = `<span>${name}</span>님의 <span>${sat_set[i]} 만족도</span>는 <span>${req[0][i]}점</span>입니다.
		  예상 만족도 ${req[1][i]}점${abj}${sug}<br><span class="rmds" style="color:#606060"></span><span class="rmds" style="color:#606060"></span><span class="rmds" style="color:#606060"></span>`;
	  const rmds_box = text_box[i].querySelectorAll(".rmds");
	  
	  for(let a=0; a<3; a++) {
		  if (enough==1) {continue;}
		  if(coef_set[0]===undefined) {rmds_box[a].innerHTML =
			  `<br><br>저희가 추천해드릴 요소가 없습니다. 추천할 사항에 이미 전부 해당하고 계세요! 그럼에도 만족도가 낮다면, 다른 문제가 존재하는 것일 수 있습니다. 자신의 환경을 객관적으로 돌아보거나, 주변 환경을 개선하기 위해 노력해보세요.`;}
		  if(coef_set[a]!=undefined) {
			  rmds_box[a].innerHTML = `<br><span>${sat_set[i]} 만족도</span>에 ${isNull[a]} ${coef_set[a][1]}<br>`
		  }
	  }

	  }
	  // 이하 txt 박스 위한 변수 선언
	 
} // --------------------------- makePage 종료.

function compareValuesDescending(a, b) {
	  return Math.abs(b[0]) - Math.abs(a[0]);
	}

function updateTextBoxes() {
	  const textBoxes = document.querySelectorAll(".rmd-textbox");
	  textBoxes.forEach(textBox => {
	    const rmdUpDown = textBox.querySelector(".rmd-updown");

	    // <div>의 높이를 텍스트의 길이에 맞추기
	    textBox.style.height = "auto"; // 높이 초기화
	    const textHeight = rmdUpDown.clientHeight + 50;
	    textBox.style.height = textHeight + 'px'; // 텍스트의 길이에 맞춤
	  });
	}

$(window).on('load resize',function(){
	updateTextBoxes();
	  let leng = $(window).width()+17;
	  if(leng>1200) {
	      var graph = document.querySelectorAll('.graph-mini');
	      graph.forEach(mini => {
	          mini.style.width = '27.33333333%';
	          mini.style.margin = '3%';
	      });
	      var graphs = document.querySelectorAll('.graph');
	      graphs.forEach(mini => {
	          mini.style.width = '37%';
	          mini.style.margin = '0 auto';
	      });
	} else if(leng<=1200) {
	  var graph = document.querySelectorAll('.graph-mini');
	      graph.forEach(mini => {
	          mini.style.width = '60%';
	          mini.style.margin = '15px 20% 0 20%';
	      });
	      var graphs = document.querySelectorAll('.graph');
	      graphs.forEach(mini => {
	          mini.style.width = '60%';
	          mini.style.margin = '15px 20% 0 20%';
	      });
	} 
	});



Chart.plugins.register({
  beforeDraw: function (chart) {
	  if (chart.config.options.elements.center) {
	      //Get ctx from string
	      var ctx = chart.chart.ctx;

	      //Get options from the center object in options
	      var centerConfig = chart.config.options.elements.center;
	      var fontSize = centerConfig.fontSize || '50';
	      var fontStyle = centerConfig.fontStyle || 'Arial';
	      var txt = centerConfig.text;
        var title = centerConfig.title;
	      var color = centerConfig.color || '#000';
	      var sidePadding = centerConfig.sidePadding || 20;
	      var sidePaddingCalculated = (sidePadding/100) * (chart.innerRadius * 2)
	      //Start with a base font of 30px
	      ctx.font = fontSize + "px " + fontStyle;

	      //Get the width of the string and also the width of the element minus 10 to give it 5px side padding
	      var stringWidth = ctx.measureText(txt).width;
	      var elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;

	      // Find out how much the font can grow in width.
	      var widthRatio = elementWidth / stringWidth;
	      var newFontSize = Math.floor(30 * widthRatio);
	      var elementHeight = (chart.innerRadius * 0.7);

	      // Pick a new font size so it will not be larger than the height of label.
	      var fontSizeToUse = Math.min(newFontSize, elementHeight);

	      //Set font settings to draw it correctly.
	      ctx.textAlign = 'center';
	      ctx.textBaseline = 'middle';
	      var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
	      var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);

	      ctx.font = fontSizeToUse+"px " + fontStyle;
	      ctx.fillStyle = color;

	      //Draw text in center
	      ctx.fillText(txt, centerX, centerY*(1.23));
        fontSize = centerConfig.titleSize*1.2;
        fontStyle = 'GmarketSansMedium';
        ctx.font = fontSize + "px " + fontStyle;
        ctx.fillText(title, centerX, centerY*(0.75));
	    }
  }
});