package com.MyZoy.Model;

public class GraphDTO{

	public GraphDTO(int sex, int age, int about_marriage, int marriage, int car, int house, int parents,
			int live_alone, int house_form, int house_rental, int health, int body, int exercise, int work_life,
			int real_dream, int result_procedure, int individual_group, int me_other, int for_happinese, int edu,
			int int_family, int int_friend, int int_other, int sat_living, int sat_health, int sat_achieve,
			int sat_human, int sat_all) {
		super();
		this.sex = sex;
		this.age = age;
		this.about_marriage = about_marriage;
		this.marriage = marriage;
		this.car = car;
		this.house = house;
		this.parents = parents;
		this.live_alone = live_alone;
		this.house_form = house_form;
		this.house_rental = house_rental;
		this.health = health;
		this.body = body;
		this.exercise = exercise;
		this.work_life = work_life;
		this.real_dream = real_dream;
		this.result_procedure = result_procedure;
		this.individual_group = individual_group;
		this.me_other = me_other;
		this.for_happinese = for_happinese;
		this.edu = edu;
		this.int_family = int_family;
		this.int_friend = int_friend;
		this.int_other = int_other;
		this.sat_living = sat_living;
		this.sat_health = sat_health;
		this.sat_achieve = sat_achieve;
		this.sat_human = sat_human;
		this.sat_all = sat_all;
	}

	int sex,age,about_marriage,marriage,car,house,parents,live_alone,house_form,
	house_rental,health,body,exercise,work_life,real_dream,result_procedure,
	individual_group,me_other,for_happinese,edu,int_family,int_friend,int_other,sat_living,
	sat_health,sat_achieve,sat_human,sat_all;

	public int getSex() {
		return sex;
	}

	public void setSex(int sex) {
		this.sex = sex;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getAbout_marriage() {
		return about_marriage;
	}

	public void setAbout_marriage(int about_marriage) {
		this.about_marriage = about_marriage;
	}

	public int getMarriage() {
		return marriage;
	}

	public void setMarriage(int marriage) {
		this.marriage = marriage;
	}

	public int getCar() {
		return car;
	}

	public void setCar(int car) {
		this.car = car;
	}

	public int getHouse() {
		return house;
	}

	public void setHouse(int house) {
		this.house = house;
	}

	public int getParents() {
		return parents;
	}

	public void setParents(int parents) {
		this.parents = parents;
	}

	public int getLive_alone() {
		return live_alone;
	}

	public void setLive_alone(int live_alone) {
		this.live_alone = live_alone;
	}

	public int getHouse_form() {
		return house_form;
	}

	public void setHouse_form(int house_form) {
		this.house_form = house_form;
	}

	public int getHouse_rental() {
		return house_rental;
	}

	public void setHouse_rental(int house_rental) {
		this.house_rental = house_rental;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public int getBody() {
		return body;
	}

	public void setBody(int body) {
		this.body = body;
	}

	public int getExercise() {
		return exercise;
	}

	public void setExercise(int exercise) {
		this.exercise = exercise;
	}

	public int getWork_life() {
		return work_life;
	}

	public void setWork_life(int work_life) {
		this.work_life = work_life;
	}

	public int getReal_dream() {
		return real_dream;
	}

	public void setReal_dream(int real_dream) {
		this.real_dream = real_dream;
	}

	public int getResult_procedure() {
		return result_procedure;
	}

	public void setResult_procedure(int result_procedure) {
		this.result_procedure = result_procedure;
	}

	public int getIndividual_group() {
		return individual_group;
	}

	public void setIndividual_group(int individual_group) {
		this.individual_group = individual_group;
	}

	public int getMe_other() {
		return me_other;
	}

	public void setMe_other(int me_other) {
		this.me_other = me_other;
	}

	public int getFor_happinese() {
		return for_happinese;
	}

	public void setFor_happinese(int for_happinese) {
		this.for_happinese = for_happinese;
	}

	public int getEdu() {
		return edu;
	}

	public void setEdu(int edu) {
		this.edu = edu;
	}

	public int getInt_family() {
		return int_family;
	}

	public void setInt_family(int int_family) {
		this.int_family = int_family;
	}

	public int getInt_friend() {
		return int_friend;
	}

	public void setInt_friend(int int_friend) {
		this.int_friend = int_friend;
	}

	public int getInt_other() {
		return int_other;
	}

	public void setInt_other(int int_other) {
		this.int_other = int_other;
	}

	public int getSat_living() {
		return sat_living;
	}

	public void setSat_living(int sat_living) {
		this.sat_living = sat_living;
	}

	public int getSat_health() {
		return sat_health;
	}

	public void setSat_health(int sat_health) {
		this.sat_health = sat_health;
	}

	public int getSat_achieve() {
		return sat_achieve;
	}

	public void setSat_achieve(int sat_achieve) {
		this.sat_achieve = sat_achieve;
	}

	public int getSat_human() {
		return sat_human;
	}

	public void setSat_human(int sat_human) {
		this.sat_human = sat_human;
	}

	public int getSat_all() {
		return sat_all;
	}

	public void setSat_all(int sat_all) {
		this.sat_all = sat_all;
	}


}
