package com.MyZoy.Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class MemberDAO {
DataSource dataSource;

public static final int MEMBER_NONEXISTENT = 0;
public static final int MEMBER_EXISTENT = 1;

public static final int MEMBER_JOIN_FAIL = 0;
public static final int MEMBER_JOIN_SUCCESS = 1;

public static final int MEMBER_LOGIN_PW_NO_GOOD = 0;
public static final int MEMBER_LOGIN_SUCCESS = 1;
public static final int MEMBER_LOGIN_IS_NOT = -1;
	
	public MemberDAO() {
		
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g"); // DB와 연결.
		} catch (Exception e) {
			System.out.println("DB 연결 오류!");
			e.printStackTrace();
		}
	}
	
	public int insertMember(MemberDTO dto) { // 새 회원 정보 DB에 넣는 메서드.
		int ri=0; // 데이터 변경 결과 확인용 변수.
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = dataSource.getConnection();
			String query = "insert into LOGINDATA values(?,?,?,?,?,?,?,0)"; // PreparedStatement 객체가 사용할 쿼리문.
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,  dto.getId()); // 상단 query문 ?에 하나씩 set.
			preparedStatement.setString(2,  dto.getPw());
			preparedStatement.setString(3,  dto.getName());
			preparedStatement.setString(4,  dto.geteMail());
			preparedStatement.setInt(5,  Integer.parseInt(dto.getTel()));
			preparedStatement.setString(6,  dto.getSex());
			preparedStatement.setString(7,  dto.getBirthday());
			preparedStatement.executeUpdate(); // UPADATE, DELETE, INSERT 등 DB를 직접 건드릴 때 사용하는 메서드. 처리된 데이터의 수를 반환.
			ri = MemberDAO.MEMBER_JOIN_SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement!=null) preparedStatement.close(); // sql문 닫아주기.
				if(connection!=null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}		
		return ri;
	}
	
	public int insertSurvey(SatDTO dto) { // 새 회원 정보 DB에 넣는 메서드.
		int ri=0; // 데이터 변경 결과 확인용 변수.
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = dataSource.getConnection();
			String query = "insert into MEMBERDATA values(?,?,?,?,?,  ?,?,?,?,?,  ?,?,?,?,?,  ?,?,?,?,?,  ?,?,?,?,?,  ?,?,?,?,?, ?,?)"; // PreparedStatement 객체가 사용할 쿼리문.
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,  dto.getId()); // 상단 query문 ?에 하나씩 set.
			preparedStatement.setInt(2, dto.getSex());
			preparedStatement.setInt(3, dto.getAge());
			preparedStatement.setInt(4, dto.getAbout_marriage());
			preparedStatement.setInt(5, dto.getMarriage());
			
			preparedStatement.setInt(6, dto.getCar());
			preparedStatement.setInt(7, dto.getHouse());
			preparedStatement.setInt(8, dto.getParents());
			preparedStatement.setInt(9, dto.getLive_alone());
			preparedStatement.setInt(10, dto.getHouse_form());
			preparedStatement.setInt(11, dto.getHouse_rental());

			preparedStatement.setInt(12, dto.getHealth());
			preparedStatement.setInt(13, dto.getBody());
			preparedStatement.setInt(14, dto.getExercise());

			preparedStatement.setInt(15, dto.getWork_life());
			preparedStatement.setInt(16, dto.getReal_dream());
			preparedStatement.setInt(17, dto.getResult_procedure());
			preparedStatement.setInt(18, dto.getIndividual_group());
			preparedStatement.setInt(19, dto.getMe_other());
			preparedStatement.setInt(20, dto.getFor_happinese());
			
			preparedStatement.setInt(21, dto.getInt_family());
			preparedStatement.setInt(22, dto.getInt_friend());
			preparedStatement.setInt(23, dto.getInt_other());	
			
			preparedStatement.setInt(24, dto.getEdu());
				
			preparedStatement.setInt(25, dto.getSat_living());
			preparedStatement.setInt(26, dto.getSat_health());
			preparedStatement.setInt(27, dto.getSat_human());
			preparedStatement.setInt(28, dto.getSat_all());
			
			preparedStatement.setInt(29, dto.getPred_living());
			preparedStatement.setInt(30, dto.getPred_health());
			preparedStatement.setInt(31, dto.getPred_human());
			preparedStatement.setInt(32, dto.getPred_all());
			preparedStatement.executeUpdate(); // UPADATE, DELETE, INSERT 등 DB를 직접 건드릴 때 사용하는 메서드. 처리된 데이터의 수를 반환.
			ri = MemberDAO.MEMBER_JOIN_SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(preparedStatement!=null) preparedStatement.close(); // sql문 닫아주기.
				if(connection!=null) connection.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}		
		return ri;
	}
	
	public int updateSurvey(SatDTO dto) { // 유저가 입력한 정보 Dto 객체에 담아서 업데이트하기
		int ri = 0;
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = dataSource.getConnection();
			String query = "update MEMBERDATA set id=?, sex=?, age=?, about_marriage=?, marriage=?, car=?, "
					+ "house=?, parents=?, live_alone=?, house_form=?, house_rental=?, health=?, body=?, exercise=?, "
					+ "work_life=?, real_dream=?, result_procedure=?, individual_group=?, me_other=?, for_happinese=?, "
					+ "int_family=?, int_friend=?, int_other=?, edu=?, sat_living=?, sat_health=?, sat_human=?, sat_all=?, "
					+ "pred_living=?, pred_health=?, pred_human=?, pred_all=? where id=?";

			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,  dto.getId()); // 상단 query문 ?에 하나씩 set.
			preparedStatement.setInt(2, dto.getSex());
			preparedStatement.setInt(3, dto.getAge());
			preparedStatement.setInt(4, dto.getAbout_marriage());
			preparedStatement.setInt(5, dto.getMarriage());
			
			preparedStatement.setInt(6, dto.getCar());
			preparedStatement.setInt(7, dto.getHouse());
			preparedStatement.setInt(8, dto.getParents());
			preparedStatement.setInt(9, dto.getLive_alone());
			preparedStatement.setInt(10, dto.getHouse_form());
			preparedStatement.setInt(11, dto.getHouse_rental());

			preparedStatement.setInt(12, dto.getHealth());
			preparedStatement.setInt(13, dto.getBody());
			preparedStatement.setInt(14, dto.getExercise());

			preparedStatement.setInt(15, dto.getWork_life());
			preparedStatement.setInt(16, dto.getReal_dream());
			preparedStatement.setInt(17, dto.getResult_procedure());
			preparedStatement.setInt(18, dto.getIndividual_group());
			preparedStatement.setInt(19, dto.getMe_other());
			preparedStatement.setInt(20, dto.getFor_happinese());
			
			preparedStatement.setInt(21, dto.getInt_family());
			preparedStatement.setInt(22, dto.getInt_friend());
			preparedStatement.setInt(23, dto.getInt_other());	
			
			preparedStatement.setInt(24, dto.getEdu());
				
			preparedStatement.setInt(25, dto.getSat_living());
			preparedStatement.setInt(26, dto.getSat_health());
			preparedStatement.setInt(27, dto.getSat_human());
			preparedStatement.setInt(28, dto.getSat_all());
			
			preparedStatement.setInt(29, dto.getPred_living());
			preparedStatement.setInt(30, dto.getPred_health());
			preparedStatement.setInt(31, dto.getPred_human());
			preparedStatement.setInt(32, dto.getPred_all());
			preparedStatement.setString(33,  dto.getId());
			preparedStatement.executeUpdate(); // UPADATE, DELETE, INSERT 등 DB를 직접 건드릴 때 사용하는 메서드. 처리된 데이터의 수를 반환.
			ri = MemberDAO.MEMBER_JOIN_SUCCESS;
		} catch(Exception e) {
			e.printStackTrace();
	    } finally {
	    	try {
	    		preparedStatement.close();
			    connection.close();
		    } catch (Exception e2) {
		    	e2.printStackTrace();
			}
		}
		return ri;
	}

	public int idCheck(String id) {
		int ri=0; // 데이터 변경 결과 확인용 변수.
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {  
			connection = dataSource.getConnection();
			String query = "SELECT ID FROM LOGINDATA WHERE ID=?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, id);
			rs = preparedStatement.executeQuery();
			if(rs.next()) {
				ri=MemberDAO.MEMBER_EXISTENT;
			} else {
				ri =MemberDAO.MEMBER_NONEXISTENT;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
				if(rs != null) rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return ri;
	}
	
	public int emailCheck(String email) {
		int ri=0; // 데이터 변경 결과 확인용 변수.
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {  
			connection = dataSource.getConnection();
			String query = "SELECT EMAIL FROM LOGINDATA WHERE EMAIL=?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, email);
			rs = preparedStatement.executeQuery();
			if(rs.next()) {
				ri=MemberDAO.MEMBER_EXISTENT;
			} else {
				ri =MemberDAO.MEMBER_NONEXISTENT;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
				if(rs != null) rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return ri;
	}
	
	public int userCheck(String id, String pw) { // 로그인 시 아이디 비밀번호 일치 여부 확인
		int ri = 0;
		String dbPw;
		Connection connection = null; // DB와의 연결 위한 Connection 객체.
		PreparedStatement preparedStatement = null; // SQL문 사용 위한 PreparedStatement 객체.
		ResultSet rs = null; // 변동 결과 DB 미리보기 할 수 있는 객체.
		String query = "select pw from LOGINDATA where id = ?"; // PreparedStatement 객체가 사용할 쿼리문. id가 parameter인 pw를 select.
		
		try {
			connection = dataSource.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, id);
			rs=preparedStatement.executeQuery();
			
			if(rs.next()) {
			    dbPw=rs.getString("pw"); // String으로 pw를 반환받는 메소드.
			    if(dbPw.equals(pw)) {
			    	ri = MemberDAO.MEMBER_LOGIN_SUCCESS;
			    } else {
			    	ri = MemberDAO.MEMBER_LOGIN_PW_NO_GOOD; // 아이디는 있으나 비밀번호가 틀림
			    }
			} else {
				ri = MemberDAO.MEMBER_LOGIN_IS_NOT; // 아이디가 없음
			}
		} catch(Exception e) {
			e.printStackTrace();
	    } finally {
	    	try {
	    		rs.close(); // sql문 닫아주기.
	    		preparedStatement.close();
			    connection.close();
		    } catch (Exception e2) {
		    	e2.printStackTrace();
			}
		}
		return ri;
	}
	
	public MemberDTO takeSession(String id) {
		MemberDTO dto = null;
		Connection connection = null; // DB와의 연결 위한 Connection 객체.
		PreparedStatement preparedStatement = null; // SQL문 사용 위한 PreparedStatement 객체.
		ResultSet rs = null; // 변동 결과 DB 미리보기 할 수 있는 객체.
		String query = "select name, isAdmin from LOGINDATA where id = ?"; // PreparedStatement 객체가 사용할 쿼리문. id가 parameter인 pw를 select.
		
		try {
			connection = dataSource.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, id);
			rs=preparedStatement.executeQuery(); // SELECT 문을 사용할 때 사용하는 메서드.
			
			if(rs.next()) { 
				String name = rs.getString("name");
				int isAdmin = rs.getInt("isAdmin");
				dto = new MemberDTO(name, isAdmin);				
			} // else { 없을 경우 }
		} catch(Exception e) {
			e.printStackTrace();
	    } finally {
	    	try {
	    		rs.close();
	    		preparedStatement.close();
			    connection.close();
		    } catch (Exception e2) {
		    	e2.printStackTrace();
			}
		}
		return dto;
	}
	
	public MemberDTO getMember(String id) { // 해당 id의 개인정보 싹 긁어서 dto 객체로 리턴해주는 메서드
		Connection connection = null; // DB와의 연결 위한 Connection 객체.
		PreparedStatement preparedStatement = null; // SQL문 사용 위한 PreparedStatement 객체.
		ResultSet rs = null; // 변동 결과 DB 미리보기 할 수 있는 객체.
		String query = "select * from LOGINDATA where id = ?";
		MemberDTO dto = null;
		
		try {
			connection = dataSource.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, id);
			rs=preparedStatement.executeQuery(); // SELECT 문을 사용할 때 사용하는 메서드.
			
			if(rs.next()) { 
				String uid = rs.getString("Id");
				String upw = rs.getString("pw");
				String name = rs.getString("name");
				String eMail = rs.getString("eMail");
				String tel = rs.getString("tel");
				String sex = rs.getString("sex");
				String birth = rs.getString("birthday");
				dto = new MemberDTO(uid, upw, name, eMail, tel, sex, birth);
			} // else { 없을 경우 }
		} catch(Exception e) {
			e.printStackTrace();
	    } finally {
	    	try {
	    		rs.close();
	    		preparedStatement.close();
			    connection.close();
		    } catch (Exception e2) {
		    	e2.printStackTrace();
			}
		}
		return dto;
	}
	
	public int updateMember(MemberDTO dto) { // 유저가 입력한 정보 Dto 객체에 담아서 업데이트하기
		int ri = 0;
		
		Connection connection = null; // DB와의 연결 위한 Connection 객체.
		PreparedStatement preparedStatement = null; // SQL문 사용 위한 PreparedStatement 객체..
		String query = "update LOGINDATA set pw=?, eMail=?, tel=? where id=?"; //
		
		try {
			connection = dataSource.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,  dto.getPw());
			preparedStatement.setString(2,  dto.geteMail());
			preparedStatement.setString(3,  dto.getTel());
			preparedStatement.setString(4,  dto.getId());
			ri=preparedStatement.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
	    } finally {
	    	try {
	    		preparedStatement.close();
			    connection.close();
		    } catch (Exception e2) {
		    	e2.printStackTrace();
			}
		}
		return ri;
	}
	
	public int updateMember(String id, String pw) { // 유저가 입력한 정보 Dto 객체에 담아서 업데이트하기
		int ri = 0;
		
		Connection connection = null; // DB와의 연결 위한 Connection 객체.
		PreparedStatement preparedStatement = null; // SQL문 사용 위한 PreparedStatement 객체..
		String query = "update LOGINDATA set pw=? where id=?"; //
		
		try {
			connection = dataSource.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,  pw);
			preparedStatement.setString(2,  id);
			ri=preparedStatement.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
	    } finally {
	    	try {
	    		preparedStatement.close();
			    connection.close();
		    } catch (Exception e2) {
		    	e2.printStackTrace();
			}
		}
		return ri;
	}
	
	public int deleteMember(String id) { // 유저가 입력한 정보 Dto 객체에 담아서 업데이트하기
		int ri = 0;
		Connection connection = null; // DB와의 연결 위한 Connection 객체.
		PreparedStatement preparedStatement = null; // SQL문 사용 위한 PreparedStatement 객체..
		String query = "delete FROM MEMBERDATA where id=?"; //
		
		try {
			connection = dataSource.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,  id);
			ri=preparedStatement.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
	    } finally {
	    	try {
	    		preparedStatement.close();
			    connection.close();
		    } catch (Exception e2) {
		    	e2.printStackTrace();
			}
		}
		return ri;
	}
	
	public int deleteLogin(String id) { // 유저가 입력한 정보 Dto 객체에 담아서 업데이트하기
		int ri = 0;
		Connection connection = null; // DB와의 연결 위한 Connection 객체.
		PreparedStatement preparedStatement = null; // SQL문 사용 위한 PreparedStatement 객체..
		String query = "delete FROM LOGINDATA where id=?"; //
		
		try {
			connection = dataSource.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1,  id);
			ri=preparedStatement.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
	    } finally {
	    	try {
	    		preparedStatement.close();
			    connection.close();
		    } catch (Exception e2) {
		    	e2.printStackTrace();
			}
		}
		return ri;
	}
	
	public String findId(String name, String email) {
		String id = null;
		Connection connection = null; // DB와의 연결 위한 Connection 객체.
		PreparedStatement preparedStatement = null; // SQL문 사용 위한 PreparedStatement 객체.
		ResultSet rs = null; // 변동 결과 DB 미리보기 할 수 있는 객체.
		String query = "select id from LOGINDATA WHERE NAME = ? AND EMAIL = ?"; // PreparedStatement 객체가 사용할 쿼리문. id가 parameter인 pw를 select.
		
		try {
			connection = dataSource.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, name);
			preparedStatement.setString(2, email);
			rs=preparedStatement.executeQuery();
			
			if(rs.next()) {
			    id=rs.getString("id"); // String으로 pw를 반환받는 메소드.
			}
		} catch(Exception e) {
			e.printStackTrace();
	    } finally {
	    	try {
	    		rs.close(); // sql문 닫아주기.
	    		preparedStatement.close();
			    connection.close();
		    } catch (Exception e2) {
		    	e2.printStackTrace();
			}
		}
		return id;
	}
	
	public String findPw(String id, String email) {
		String uid = null;
		Connection connection = null; // DB와의 연결 위한 Connection 객체.
		PreparedStatement preparedStatement = null; // SQL문 사용 위한 PreparedStatement 객체.
		ResultSet set = null; // 변동 결과 DB 미리보기 할 수 있는 객체.
		String query = "select ID from LOGINDATA WHERE ID = ? AND EMAIL = ?"; // PreparedStatement 객체가 사용할 쿼리문. id가 parameter인 pw를 select.
		
		try {
			connection = dataSource.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, id);
			preparedStatement.setString(2, email);
			set=preparedStatement.executeQuery();
			
			if(set.next()) {
				uid = set.getString("Id");
			}
		} catch(Exception e) {
			e.printStackTrace();
	    } finally {
	    	try {
	    		set.close(); // sql문 닫아주기.
	    		preparedStatement.close();
			    connection.close();
		    } catch (Exception e2) {
		    	e2.printStackTrace();
			}
		}
		return uid;
	}

}
