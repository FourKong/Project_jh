package com.MyZoy.Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class GraphDAO {
DataSource dataSource;
	
	public GraphDAO() {
		
		try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g"); // DB와 연결.
		} catch (Exception e) {
			System.out.println("DB 연결 오류!");
			e.printStackTrace();
		}
	}
	
	public int categoryCheck(String category, String id) {
		int userData = 100;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			connection = dataSource.getConnection();
			String query = "SELECT " + category + " FROM MEMBERDATA WHERE Id=?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, id);
			rs = preparedStatement.executeQuery();
			if(rs.next()) {
				userData = rs.getInt(1);
				}
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
				if(rs != null) rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		System.out.println(userData);
		return userData;
	}

	public ArrayList<GraphDTO> graphData(String category, int userData) {
		ArrayList<GraphDTO> dtos = new ArrayList<GraphDTO>();
		GraphDTO dto = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			connection = dataSource.getConnection();
			String query = "SELECT * FROM GRAPHDATA WHERE " + category + "=?";
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, userData);
			rs = preparedStatement.executeQuery();
			while(rs.next()) {
				int sex = rs.getInt("sex");
				int age = rs.getInt("age");
				int about_marriage = rs.getInt("about_marriage");
				int marriage = rs.getInt("marriage");
				int car = rs.getInt("car");
				int house = rs.getInt("house");
				int parents = rs.getInt("parents");
				int live_alone = rs.getInt("live_alone");
				int house_form = rs.getInt("house_form");
				int house_rental = rs.getInt("house_rental");
				int health = rs.getInt("health");
				int body = rs.getInt("body");
				int exercise = rs.getInt("exercise");
				int work_life = rs.getInt("work_life");
				int real_dream = rs.getInt("real_dream");
				int result_procedure = rs.getInt("result_procedure");
				int individual_group = rs.getInt("individual_group");
				int me_other = rs.getInt("me_other");
				int for_happinese = rs.getInt("for_happinese");
				int edu = rs.getInt("edu");
				int int_family = rs.getInt("int_family");
				int int_friend = rs.getInt("int_friend");
				int int_other = rs.getInt("int_other");
				int sat_living = rs.getInt("sat_living");
				int sat_health = rs.getInt("sat_health");
				int sat_achieve = rs.getInt("sat_achieve");
				int sat_human = rs.getInt("sat_human");
				int sat_all = rs.getInt("sat_all");
				dto = new GraphDTO(sex,age,about_marriage,marriage,car,house,parents,live_alone,house_form,
						house_rental,health,body,exercise,work_life,real_dream,result_procedure,
						individual_group,me_other,for_happinese,edu,int_family,int_friend,int_other,sat_living,
						sat_health,sat_achieve,sat_human,sat_all);
				dtos.add(dto);
				}
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // DB 관련은 다 닫아줘야 함!
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
				if(rs != null) rs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return dtos;
	}

}
