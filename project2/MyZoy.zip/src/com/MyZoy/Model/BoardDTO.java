package com.MyZoy.Model;

public class BoardDTO{

	public BoardDTO() {

	}

	int bId;
	String writer;
	String title;
	String content;
	String bDate;
	int hit;
	int isReply;
	
	public BoardDTO(int bId, String writer, String title, String bDate, int hit, int isReply) {
		super();
		this.bId = bId;
		this.writer = writer;
		this.title = title;
		this.bDate = bDate;
		this.hit = hit;
		this.isReply = isReply;
	}
	
	public BoardDTO(int bId, String writer, String title, String content, String bDate, int hit, int isReply) {
		super();
		this.bId = bId;
		this.writer = writer;
		this.title = title;
		this.content = content;
		this.bDate = bDate;
		this.hit = hit;
		this.isReply = isReply;
	}

	public int getbId() {
		return bId;
	}
	public void setbId(int bId) {
		this.bId = bId;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getbDate() {
		return bDate;
	}
	public void setbDate(String bDate) {
		this.bDate = bDate;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	public int getIsReply() {
		return isReply;
	}
	public void setIsReply(int isReply) {
		this.isReply = isReply;
	}

}
