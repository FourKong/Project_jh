package com.MyZoy.Command;

//import com.google.gson.Gson;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyZoy.Model.SatDAO;
import com.MyZoy.Model.SatDTO;

public class SatContent implements SatCommand{
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		 
		String id = (String) request.getSession().getAttribute("id"); // request에서 세션 받고, 세션에서 id 받아서 String으로.
		SatDAO dao = new SatDAO();
		SatDTO dto = dao.predict_sat(id); // 해당 Id를 가진 튜플을 dto에 담아서
		String dtoJson = new com.google.gson.Gson().toJson(dto);
		request.setAttribute("sat_info", dto); // sat_info라는 이름으로 request 패킷에 넣기.
		request.setAttribute("sat_Json", dtoJson); // sat_info라는 이름으로 request 패킷에 넣기.
		if (dto == null) {
			return 0;
		} else return 1;
	}
}