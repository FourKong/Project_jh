package com.MyZoy.Command;

//import com.google.gson.Gson;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.MyZoy.Model.MemberDAO;
import com.MyZoy.Model.SatDAO;
import com.MyZoy.Model.SatDTO;

public class SurveyContent implements MemberCommand {
	@Override
	public int execute(HttpServletRequest request, HttpServletResponse response) {
		
		String id = (String) request.getParameter("id"); 
		int sex = Integer.parseInt((String) request.getParameter("sex"));
		int age = Integer.parseInt((String) request.getParameter("age"));
		
		int about_marriage = Integer.parseInt((String) request.getParameter("about_marriage"));
		int marriage = Integer.parseInt((String) request.getParameter("marriage"));
		int car = Integer.parseInt((String) request.getParameter("car"));
		int house = Integer.parseInt((String) request.getParameter("house"));
		
		int parents = Integer.parseInt((String) request.getParameter("parents"));
		int live_alone = Integer.parseInt((String) request.getParameter("live_alone"));
		int house_form = Integer.parseInt((String) request.getParameter("house_form"));
		int house_rental = Integer.parseInt((String) request.getParameter("house_rental"));
		
		int health = Integer.parseInt((String) request.getParameter("health"));
		int body  = Integer.parseInt((String) request.getParameter("body"));
		int exercise = Integer.parseInt((String) request.getParameter("exercise"));
		
		int work_life = Integer.parseInt((String) request.getParameter("work_life"));
		int real_dream = Integer.parseInt((String) request.getParameter("real_dream"));
		int result_procedure = Integer.parseInt((String) request.getParameter("result_procedure"));
		int individual_group = Integer.parseInt((String) request.getParameter("individual_group"));
		int me_other = Integer.parseInt((String) request.getParameter("me_other"));
		int for_happinese = Integer.parseInt((String) request.getParameter("for_happinese"));
		
		int int_family = Integer.parseInt((String) request.getParameter("int_family"));
		int int_friend = Integer.parseInt((String) request.getParameter("int_friend"));
		int int_other = Integer.parseInt((String) request.getParameter("int_other"));
		
		int	edu = Integer.parseInt((String) request.getParameter("edu"));
		
		int sat_living = Integer.parseInt((String) request.getParameter("sat_living"));
		int sat_health = Integer.parseInt((String) request.getParameter("sat_health"));
		int sat_human = Integer.parseInt((String) request.getParameter("sat_human"));
		int sat_all = Integer.parseInt((String) request.getParameter("sat_all"));
		
		int pred_living = Integer.parseInt((String) request.getParameter("pred_living"));
		int pred_health = Integer.parseInt((String) request.getParameter("pred_health"));
		int pred_human = Integer.parseInt((String) request.getParameter("pred_human"));
		int pred_all = Integer.parseInt((String) request.getParameter("pred_all"));
		
		SatDTO dto = new SatDTO(id, sex, age, about_marriage, marriage, car, house, parents, live_alone, house_form, house_rental,
				health, body, exercise, work_life, real_dream, result_procedure, individual_group, me_other, for_happinese,
			    int_family, int_friend, int_other, edu,	sat_living,	sat_health, sat_human, sat_all,
			    pred_living, pred_health, pred_human, pred_all);
		MemberDAO dao = new MemberDAO();
		
		SatDAO satDao = new SatDAO();
		int ri = 0;
		if (satDao.predict_sat(id)==null) {	ri = dao.insertSurvey(dto);	}
		else { ri = dao.updateSurvey(dto); }

		return ri;
	}
}