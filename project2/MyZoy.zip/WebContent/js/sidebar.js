    $.fn.isInViewport = function() {
        var elementTop = $(this).offset().top;
        var elementBottom = elementTop + $(this).outerHeight();

        var viewportTop = $(window).scrollTop();
        var viewportBottom = viewportTop + $(window).height();

        return elementBottom > viewportTop + 50 && elementTop < viewportBottom -50;

    };

    $(window).on('load resize scroll',function(){
        $('.ani').each(function(){
            if($(this).isInViewport()){
                $(this).addClass('active');
            }
        });

    });

    $(window).on('load resize scroll',function(){
        $('.ani').each(function(){
            if($(this).isInViewport()){
                $(this).addClass('active');
            }
        });

    });

// 이벤트에 등록할 함수
const sideFunc = function () {

    const viewportHeight = $(window).height(); // 보이는 화면 높이
    const documentHeight = $(document).height(); // 문서의 총 높이
    const scrolltop = $(window).scrollTop(); // Scroll Top
    const y = $(footer).offset().top;
    const elementHeight = $(footer).height();
    const head = $(header).height();
    var sideHide = documentHeight - viewportHeight - scrolltop; // 보이지 않는 아래쪽의 길이
    var fixAgain;

    if (y < (viewportHeight + scrolltop)) {
        $(window).scroll(function(){
            $(".sidebar").css("height", viewportHeight-head-(elementHeight-sideHide));
        });
        clearTimeout(fixAgain);
        fixAgain = setTimeout(function() {
                if($('.sidebar').height!=viewportHeight-head-(elementHeight-sideHide)){
                $(".sidebar").css("height", viewportHeight-head-(elementHeight-sideHide));
                }
            }, 10); // 여유 되면 사이드바 스크롤 백분율 유지하는 코드!
    } else if (y > (viewportHeight + scrolltop)) {
        $(window).scroll(function(){
            $(".sidebar").css("height", viewportHeight-head);
        });
    }
}

// 스크롤 이벤트 등록
window.addEventListener('scroll', function() {
    if (window.innerWidth >= 768) {
    sideFunc();
  }
    if (window.innerWidth < 768) {
    	$(".sidebar").removeAttr('style');
    }
});

window.addEventListener('resize', function() {
    if (window.innerWidth >= 768) {
    sideFunc();
  }
    if (window.innerWidth < 768) {
    	$(".sidebar").removeAttr('style');
    }
});