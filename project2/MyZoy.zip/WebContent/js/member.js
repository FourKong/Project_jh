window.onresize = function () {
    if (document.body.offsetWidth <= 500) {
        let width = document.querySelector(".site-width");
        width.classList.remove(`col-xs-offset-2`);
        width.classList.remove(`col-xs-8`);
        width.classList.add(`col-xs-12`);
    } else if (document.body.offsetWidth > 500) {
        let width = document.querySelector(".site-width");
        width.classList.remove(`col-xs-12`);
        width.classList.add(`col-xs-offset-2`);
        width.classList.add(`col-xs-8`);
    }
}
window.onload = function () {
    if (document.body.offsetWidth <= 500) {
        let width = document.querySelector(".site-width");
        width.classList.remove(`col-xs-offset-2`);
        width.classList.remove(`col-xs-8`);
        width.classList.add(`col-xs-12`);
    }
}

function infoConfirm(idCheck) {
	if(document.querySelector("#uid").value.length == 0) {// 즉, 아이디를 입력하지 않았을 때.
		alert("아이디는 필수 사항입니다!");
		document.querySelector("#uid").focus();
	    return;
	}
	
	if(document.querySelector("#uid").value.length < 4 ) {// 아이디가 4글자 미만일 때
		alert("아이디는 4글자 이상이어야 합니다!");
		document.querySelector("#uid").focus();
	    return;	
	}
	
	if(document.querySelector("#uid").value.length > 15 ) {// 아이디가 4글자 미만일 때
		alert("아이디는 15글자 이하여야 합니다!");
		document.querySelector("#uid").focus();
	    return;	
	}
	
//	if(document.querySelector(".isDup").value == "no") {
//		alert("아이디 중복 확인을 해주세요!");
//		document.querySelector("#uid").focus();
//	    return;
//	}
	
	if(document.querySelector("#pw1").value.length == 0) {
		alert("비밀번호는 필수 사항입니다!");
		document.querySelector("#pw1").focus();
	    return;
	}
	
	if(document.querySelector("#pw1").value.length > 16) {
		alert("비밀번호는 16글자 이하여야 합니다!");
		document.querySelector("#pw1").focus();
	    return;
	}
	
	if(document.querySelector("#pw1").value.length < 8) {
		alert("비밀번호는 8글자 이상이어야 합니다!");
		document.querySelector("#pw1").focus();
	    return;
	}
	
	if(document.querySelector("#pw2").value.length != document.querySelector("#pw1").value.length) {
		alert("비밀번호가 일치하지 않습니다!");
		document.querySelector("#pw2").focus();
	    return;	
	}
	
	if(document.querySelector("#uname").value.length == 0) {
		alert("이름을 입력해주세요!");
		document.querySelector("#uname").focus();
	    return;	
	}
	
	if(document.querySelector("#utel").value.length == 0) {
		alert("번호를 입력해주세요!");
		document.querySelector("#utel").focus();
	    return;	
	}
	
	const numPattern = /^[0-9]+$/; // 숫자 패턴 정규식
	if(!numPattern.test(document.querySelector("#utel").value)) {
		alert("연락처에는 숫자를 입력해주세요!");
		document.querySelector("#utel").focus();
		console.log()
	    return;	
	}
	
	if(document.querySelector("#umail").value.length == 0) {
		alert("이메일을 입력해주세요!");
		document.querySelector("#umail").focus();
	    return;	
	}
	
     const form = document.querySelector('.form-group');

     form.submit();
	
}

function dupConfirm() {
	if(document.querySelector("#uid").value.length == 0) {// 즉, 아이디를 입력하지 않았을 때.
		alert("아이디를 입력해주세요!");
		document.querySelector("#uid").focus();
	    return;
	}
	
	if(document.querySelector("#uid").value.length < 4 ) {// 아이디가 4글자 미만일 때
		alert("아이디는 4글자 이상이어야 합니다!");
		document.querySelector("#uid").focus();
	    return;	
	}
	
	if(document.querySelector("#uid").value.length > 15 ) {// 아이디가 4글자 미만일 때
		alert("아이디는 15글자 이하여야 합니다!");
		document.querySelector("#uid").focus();
	    return;	
	}

	window.open("JH_Project/idCheck.do?uid=" + document.querySelector("#uid").value, "", width=100, height=100);
	
}
