package com.mycompany.MyZoy.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mycompany.MyZoy.model.MemberVO;
import com.mycompany.MyZoy.service.IMemberService;

@Controller
@RequestMapping("/member")
public class MemberController {
	
	@Autowired
	IMemberService memberService;
	
	@PostMapping("/join") // '/member/join'.
	public String join(@RequestParam("uid") String id, @RequestParam("pw1") String pw,
			@RequestParam("uname") String name, @RequestParam("umail") String eMail,
			@RequestParam("utel") String tel, @RequestParam("usex") String sex,
			@RequestParam("ubirth") String birthday, Model model){
		int ri = memberService.idCheck(id);
		if(ri==1) {
			model.addAttribute("message", "이미 존재하는 아이디입니다!");
			return "member/false";
		}
		int ri2 = memberService.emailCheck(eMail);
		if(ri2==1) {
			model.addAttribute("message", "이미 사용중인 메일입니다!");
			return "member/false";
		}
		MemberVO vo = new MemberVO(id, pw, name, eMail, tel, sex, birthday);
		memberService.insertMember(vo);
		model.addAttribute("things", "회원가입이");
		model.addAttribute("message", "로그인 후 본 사이트에서 제공하는 모든 기능을 이용하실 수 있습니다.");
		return "member/submit?things=회원가입이&message=로그인 후 본 사이트에서 제공하는 모든 기능을 이용하실 수 있습니다.";
	}
	
	@PostMapping("/login") // '/member/login'.
	public String login(@RequestParam("id") String id, @RequestParam("pw") String pw, HttpSession session, Model model){
		int ri = memberService.userCheck(id, pw);
		if (ri==1) { // id Exist && pw Exist
			MemberVO vo = memberService.setSession(id);
	        session.setAttribute("name", vo.getName());
	        session.setAttribute("id", id);
	        session.setAttribute("isValid", "yes");
	        session.setAttribute("isAdmin", vo.getIsAdmin());
			return "redirect:/index";
		} else if (ri==0) { // id Exist but pw dosent Exist
			model.addAttribute("message", "비밀번호가 일치하지 않습니다!");
			return "member/false";
		} else { // id doesnt Exist. ri == null.
			model.addAttribute("message", "존재하지 않는 아이디입니다!");
			return "member/false";
		}
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/index";
	}
	
	@RequestMapping("/myPage/userFix")
	public String myPageFix(Model model) {
		model.addAttribute("page", "/MyZoy/member/userFix");
		model.addAttribute("title", "회원 정보 수정");
		return "member/authentication";
	}
	
	@RequestMapping("/myPage/userDelete")
	public String myPageDel(Model model) {
		model.addAttribute("page", "/MyZoy/member/userDelete");
		model.addAttribute("title", "회원 탈퇴");
		return "member/authentication";
	}
	
	@RequestMapping("/myPage/surveyFix")
	public String myPageSurFix(Model model) {
		model.addAttribute("page", "/MyZoy/member/surveyFix");
		model.addAttribute("title", "설문 정보 수정");
		return "member/authentication";
	}
	
	@RequestMapping("/userFix")
	public String userFix(@RequestParam("Id") String id) {
		return "member";
	}
	
//	@RequestMapping("userDelete")
//	
//	@RequestMapping("")
//	

//			
//		} else if(com.equals("/joinFin.do")) {

//		} else if(com.equals("/idDup.do")) {
//			request.setAttribute("message", "이미 존재하는 아이디입니다!");
//			viewPage="sub-member-false.jsp";
//			
//		} else if(com.equals("/mailDup.do")) {
//			request.setAttribute("message", "이미 사용중인 이메일입니다!");
//			viewPage="sub-member-false.jsp";
//			
//		} else if(com.equals("/member/login")) {
//			MemberCommand command = new LoginContent(); // command 종류
//			int ri = command.execute(request, response);
//			if (ri==1) {
//				response.sendRedirect("index");
//				return;
//			} else if (ri==0) { // 비밀번호 오류
//				request.setAttribute("message", "비밀번호가 일치하지 않습니다!");
//				viewPage="sub-member-false.jsp";
//			} else { // 아이디 없음
//				request.setAttribute("message", "존재하지 않는 아이디입니다!");
//				viewPage="sub-member-false.jsp";
//			}
//			
//			
//		} else if(com.equals("/myPage.do")) {
//			request.setAttribute("page", "myPageFix.do");
//			request.setAttribute("title", "회원 정보 수정");
//			viewPage="sub-member-editinfo-authentication.jsp";
//			
//		} else if(com.equals("/myPageFix.do")) {
//			MemberCommand command = new MyPageContent(); // command 종류
//			int ri = command.execute(request, response);
//			if (ri==1) {
//				viewPage="sub-member-editinfo-fix.jsp";
//			} else if (ri==0) { // 비밀번호 오류
//				request.setAttribute("message", "비밀번호가 일치하지 않습니다!");
//				viewPage="sub-member-false.jsp";
//			}
//			
//		} else if(com.equals("/userFix.do")) {
//			MemberCommand command = new UserFixContent(); // command 종류
//			int ri = command.execute(request, response);
//			if(ri>0) {
//			request.setAttribute("message", "변경이 완료되었습니다!");
//			viewPage="sub-member-false.jsp";
//			} else {
//				request.setAttribute("message", "변경이 실패하였습니다!");
//				viewPage="sub-member-false.jsp";
//			}
//			
//		} else if(com.equals("/surveyFix.do")) {
//			request.setAttribute("title", "설문 정보 수정");
//			request.setAttribute("page", "survey.do");
//			viewPage="sub-member-editinfo-authentication.jsp";
//			
//		} else if(com.equals("/deleteCheck.do")) {
//			request.setAttribute("title", "회원 탈퇴");
//			request.setAttribute("page", "deletePage.do");
//			viewPage="sub-member-editinfo-authentication.jsp";
//			
//		} else if(com.equals("/deletePage.do")) {
//			viewPage="sub-member-editinfo-withdrawalCheck.jsp";	
//	
//		} else if(com.equals("/delete.do")) {
//			MemberCommand command = new DeleteContent(); // command 종류
//			command.execute(request, response);
//			request.setAttribute("things", "회원 탈퇴가");
//			request.setAttribute("message", "지금까지 본 사이트를 이용해주셔서 감사합니다.");
//			HttpSession session = request.getSession();
//			session.invalidate();
//			viewPage = "sub-submit.jsp"; //
//			
//		} else if(com.equals("/findId.do")) {
//			viewPage = "sub-member-idFind.jsp"; 
//			
//		} else if(com.equals("/findIdOK.do")) {
//			MemberCommand command = new FindIdContent(); // command 종류
//			int ri = command.execute(request, response);
//			if (ri==1) {
//				viewPage = "sub-member-idFind-result.jsp"; 
//			} else if (ri==0) { // 입력 정보 불일치
//				request.setAttribute("message", "입력 정보를 확인해주세요!");
//				viewPage="sub-member-false.jsp";
//			}
//			
//		} else if(com.equals("/findPw.do")) {
//			viewPage = "sub-member-pwFind.jsp"; 
//			
//		} else if(com.equals("/findPwOK.do")) {
//			MemberCommand command = new FindPwContent(); // command 종류
//			int ri = command.execute(request, response);
//			if (ri==1) {
//				viewPage = "sub-member-pwFind-change.jsp"; 
//			} else if (ri==0) { // 입력 정보 불일치
//				request.setAttribute("message", "입력 정보를 확인해주세요!");
//				viewPage="sub-member-false.jsp";
//			}
//			
//		} else if(com.equals("/pwFix.do")) {
//			MemberCommand command = new PwFixContent(); // command 종류
//			int ri = command.execute(request, response);
//			if (ri>0) {
//				request.setAttribute("things", "비밀번호 변경이");
//				request.setAttribute("message", "변경된 비밀번호로 로그인해주시기 바랍니다.");
//				viewPage = "sub-submit.jsp"; //
//			} else {
//				request.setAttribute("message", "변경이 실패하였습니다!");
//				viewPage="sub-member-false.jsp";
//			}
//			
//		} else if(com.equals("/board")) {
//			BoardCommand command = new ListContent(); // command 종류
//			command.execute(request, response);
//			viewPage = "sub-board-list.jsp"; 
//		
//		} else if(com.equals("/post.do")) {
//			viewPage = "sub-board-post.jsp";
//			
//		} else if(com.equals("/reply.do")) {
//			BoardCommand command = new ReplyContent(); // command 종류
//			command.execute(request, response);
//			viewPage = "sub-board-reply.jsp";
//			
//		} else if(com.equals("/posting.do")) {
//			BoardCommand command = new PostContent(); // command 종류
//			command.execute(request, response);
//		    response.sendRedirect("board"); // 리다이렉트
//		    return;
//			 
//		} else if(com.equals("/watch.do")) {
//			BoardCommand command = new WatchContent(); // command 종류
//			command.execute(request, response);
//			viewPage = "sub-board-watch.jsp"; 
//			
//		} else if(com.equals("/deletePost.do")) {
//			BoardCommand command = new DeletePostContent(); // command 종류
//			command.execute(request, response);
//			response.sendRedirect("board"); // 리다이렉트
//		    return;
//		    
//		} else if(com.equals("/survey.do")) {
//			HttpSession session = request.getSession();
//			if(session.getAttribute("id")==null) {
//				response.sendRedirect("index"); // 리다이렉트
//				return;
//			}
//			MemberCommand command = new SurveyDataContent(); // command 종류
//			command.execute(request, response);
//			viewPage = "sub-member-survey.jsp";
//
//		} else if(com.equals("/surveyOK.do")) {
//			MemberCommand command = new SurveyContent(); // command 종류
//			command.execute(request, response);
//			response.sendRedirect("index"); // 리다이렉트
//		    return;
//		}
//	
//		RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
//		dispatcher.forward(request, response);
//	}

}
