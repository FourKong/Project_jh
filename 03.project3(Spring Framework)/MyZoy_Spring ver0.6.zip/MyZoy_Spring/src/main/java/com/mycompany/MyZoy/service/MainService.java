package com.mycompany.MyZoy.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.mycompany.MyZoy.dao.IMainRepository;
import com.mycompany.MyZoy.model.CoefVO;
import com.mycompany.MyZoy.model.SurveyVO;

@Service
public class MainService implements IMainService{
	
	@Autowired
	@Qualifier("IMainRepository")
	IMainRepository mainRepository;
	
	@Override
	public SurveyVO getPredictData(String id) {
		return mainRepository.getPredictData(id);
	}
	
	@Override
	public ArrayList<CoefVO> getCoefData() {
		return mainRepository.getCoefData();
	}
	
	@Override
	public int categoryCheck(String category, String id) {
		return mainRepository.categoryCheck(category, id);
	}
	
	@Override
	public ArrayList<SurveyVO> getGraphData(String category, int userData) {
		return mainRepository.getGraphData(category, userData);
	}

}