package com.mycompany.MyZoy.dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Param;

import com.mycompany.MyZoy.model.CoefVO;
import com.mycompany.MyZoy.model.SurveyVO;

public interface IBoardRepository {
	SurveyVO getPredictData(@Param("id") String id);
	ArrayList<CoefVO> getCoefData();
	int categoryCheck(@Param("category") String category, @Param("id") String id);
	ArrayList<SurveyVO> getGraphData(@Param("category") String category, @Param("userData") int userData);
}