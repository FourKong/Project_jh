package com.mycompany.MyZoy.service;

import java.util.ArrayList;

import com.mycompany.MyZoy.model.CoefVO;
import com.mycompany.MyZoy.model.SurveyVO;

public interface IMainService {
	SurveyVO getPredictData(String id);
	ArrayList<CoefVO> getCoefData();
	int categoryCheck(String category, String id);
	ArrayList<SurveyVO> getGraphData(String category, int userData);
}
