package com.mycompany.MyZoy.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mycompany.MyZoy.model.CoefVO;
import com.mycompany.MyZoy.model.SurveyVO;
import com.mycompany.MyZoy.service.IMainService;

@Controller
@RequestMapping("/main")
public class MainController {
	
	@Autowired
	IMainService mainService;

	@RequestMapping("/satisfaction")
	public String surveyData(HttpSession session, Model model) {
        String id = (String) session.getAttribute("id");
        if(id==null) {
			model.addAttribute("message", "회원 가입이 필요한 기능입니다!");
			return "member/false";
        }
        SurveyVO rs = mainService.getPredictData(id);
		if(rs==null) {
			model.addAttribute("need", "need");
			return "member/survey";
		}
		model.addAttribute("sat_info", rs);
		String voJson = new com.google.gson.Gson().toJson(rs);
		model.addAttribute("sat_Json", voJson);
		List<CoefVO> rs2 = mainService.getCoefData();
		String voJson2 = new com.google.gson.Gson().toJson(rs2);
		model.addAttribute("coef_info", voJson2);
		return "main/function1";
	}

	@RequestMapping("/graph")
	public String graphData(@RequestParam(value="category", required=false,
	defaultValue="sex") String category, HttpSession session, Model model) {
		String id = (String) session.getAttribute("id");
        if(id==null) {
			model.addAttribute("message", "회원 가입이 필요한 기능입니다!");
			return "member/false";
        }
        SurveyVO check = mainService.getPredictData(id);
		if(check==null) {
			model.addAttribute("need", "need");
			return "member/survey";
		}
		int userData = mainService.categoryCheck(category, id);
		System.out.println(userData);
		ArrayList<SurveyVO> rs = mainService.getGraphData(category, userData);
		String voJson = new com.google.gson.Gson().toJson(rs);
		model.addAttribute("graph_data", voJson);
		model.addAttribute("userData", userData);
		model.addAttribute("category", category);
		return "main/function2";
	}
}
