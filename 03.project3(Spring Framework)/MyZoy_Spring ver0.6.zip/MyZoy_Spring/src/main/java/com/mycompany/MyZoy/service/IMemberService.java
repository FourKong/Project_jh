package com.mycompany.MyZoy.service;

import com.mycompany.MyZoy.model.MemberVO;
import com.mycompany.MyZoy.model.SurveyVO;

public interface IMemberService {
	void insertMember(MemberVO vo); 
	void insertSurvey(SurveyVO vo); 
	void updateSurvey(SurveyVO vo);
	int idCheck(String id);
	int emailCheck(String eMail);
	int userCheck(String id, String pw);
	MemberVO setSession(String id); // takeSession
	MemberVO getMember(String id);
	void updateMember(MemberVO vo);
	void updateMember(String id, String pw); // 비밀번호 변경 시
	void deleteMember(String id);
	void deleteSurvey(String id);
	String findId(String name, String eMail);
	String findPw(String id, String eMail);
}
