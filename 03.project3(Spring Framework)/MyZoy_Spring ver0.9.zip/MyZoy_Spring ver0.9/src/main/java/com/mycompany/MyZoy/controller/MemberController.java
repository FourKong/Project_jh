package com.mycompany.MyZoy.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mycompany.MyZoy.model.MemberVO;
import com.mycompany.MyZoy.model.SurveyVO;
import com.mycompany.MyZoy.service.IMemberService;

@Controller
@RequestMapping("/member")
public class MemberController {
	
	@Autowired
	IMemberService memberService;
	
	@PostMapping("/join") // '/member/join'. 
	public String join(@RequestParam("uid") String id, @RequestParam("pw1") String pw,
			@RequestParam("uname") String name, @RequestParam("umail") String eMail,
			@RequestParam("utel") String tel, @RequestParam("usex") String sex,
			@RequestParam("ubirth") String birthday, Model model){
		int ri = memberService.idCheck(id);
		if(ri==1) {
			model.addAttribute("message", "이미 존재하는 아이디입니다!");
			return "member/false";
		} 
		int ri2 = memberService.emailCheck(eMail);
		if(ri2==1) {
			model.addAttribute("message", "이미 사용중인 메일입니다!");
			return "member/false";
		} 
		MemberVO vo = new MemberVO(id, pw, name, eMail, tel, sex, birthday);
		memberService.insertMember(vo);
		model.addAttribute("things", "회원가입이");
		model.addAttribute("message", "로그인 후 본 사이트에서 제공하는 모든 기능을 이용하실 수 있습니다.");
		return "member/submit";
	}
	
	@PostMapping("/login") // '/member/login'.
	public String login(@RequestParam("id") String id, @RequestParam("pw") String pw, HttpSession session, Model model){
		int ri = memberService.userCheck(id, pw);
		if (ri==1) { // id Exist && pw Exist
			MemberVO vo = memberService.setSession(id);
	        session.setAttribute("name", vo.getName());
	        session.setAttribute("id", id);
	        session.setAttribute("isValid", "yes");
	        session.setAttribute("isAdmin", vo.getIsAdmin());
			return "redirect:/index";
		} else if (ri==0) { // id Exist but pw dosent Exist
			model.addAttribute("message", "비밀번호가 일치하지 않습니다!");
			return "member/false";
		} else { // id doesnt Exist. ri == null.
			model.addAttribute("message", "존재하지 않는 아이디입니다!");
			return "member/false";
		}
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/index";
	}
	
	@RequestMapping("/myPage")
	public String myPageFix(Model model) {
		model.addAttribute("page", "/MyZoy/member/userFix");
		model.addAttribute("title", "회원 정보 수정");
		return "member/authentication";
	}
	
	@RequestMapping("/userFix")
	public String userFix(HttpSession session, Model model) {
		String id = (String) session.getAttribute("id");
		MemberVO rs = memberService.getMember(id);
		model.addAttribute("vo", rs);
		return "member/userFix";
	}
	
	@RequestMapping("/fixOk")
	public String fixOk(@RequestParam("uid") String id, @RequestParam("pw1") String pw,
			@RequestParam("uname") String name, @RequestParam("umail") String eMail,
			@RequestParam("utel") String tel, Model model) {
		MemberVO vo = new MemberVO(id, pw, name, eMail, tel);
		memberService.updateMember(vo);
		return "redirect:/member/userFix";
	}

	@RequestMapping("/surveyFix")
	public String myPageSurFix(Model model) {
		model.addAttribute("page", "/MyZoy/member/survey");
		model.addAttribute("title", "설문 정보 수정");
		return "member/authentication";
	}
	
	@RequestMapping("/survey")
	public String myPageSur(HttpSession session, Model model) {
		String id = (String) session.getAttribute("id");
		SurveyVO rs = memberService.getSurvey(id);
		model.addAttribute("vo", rs);
		return "member/survey";
	}
	
	@RequestMapping("/surveyOk")
	public String surveyOk(@RequestParam("id") String id,
			@RequestParam("sex") int sex,
			@RequestParam("age") int age,
			@RequestParam("about_marriage") int about_marriage,
			@RequestParam("marriage") int marriage,
			@RequestParam("car") int car,
			@RequestParam("house") int house,
			@RequestParam("parents") int parents,
			@RequestParam("live_alone") int live_alone,
			@RequestParam("house_form") int house_form,
			@RequestParam("house_rental") int house_rental,
			@RequestParam("health") int health,
			@RequestParam("body") int body,
			@RequestParam("exercise") int exercise,
			@RequestParam("work_life") int work_life,
			@RequestParam("real_dream") int real_dream,
			@RequestParam("result_procedure") int result_procedure,
			@RequestParam("individual_group") int individual_group,
			@RequestParam("me_other") int me_other,
			@RequestParam("for_happiness") int for_happiness,
			@RequestParam("edu") int edu,
			@RequestParam("int_family") int int_family,
			@RequestParam("int_friend") int int_friend,
			@RequestParam("int_other") int int_other,
			@RequestParam("sat_living") int sat_living,
			@RequestParam("sat_health") int sat_health,
			@RequestParam("sat_human") int sat_human,
			@RequestParam("sat_all") int sat_all,
			@RequestParam("pred_living") int pred_living,
			@RequestParam("pred_health") int pred_health,
			@RequestParam("pred_human") int pred_human,
			@RequestParam("pred_all") int pred_all, Model model){
		SurveyVO rs = new SurveyVO(id, sex, age, about_marriage, marriage, car, house, parents, live_alone, house_form,
				house_rental, health, body, exercise, work_life, real_dream, result_procedure,
				individual_group, me_other, for_happiness, edu, int_family, int_friend, int_other,
				sat_living, sat_health, sat_human, sat_all, pred_living, pred_health, pred_human, pred_all);
		if(memberService.getSurvey(id)==null) {
			memberService.insertSurvey(rs);	
		} else memberService.updateSurvey(rs);
		return "redirect:/index";
		}
	
	@RequestMapping("/deleteOk")
	public String deleteOk(HttpSession session, Model model) {
		String id = (String) session.getAttribute("id");
		memberService.deleteMember(id);
		model.addAttribute("things", "회원 탈퇴가");
		model.addAttribute("message", "지금까지 본 사이트를 이용해주셔서 감사합니다.");
		session.invalidate();
		return "member/submit";
	}
	
	@RequestMapping("/deleteCheck")
	public String myPageDel(Model model) {
		model.addAttribute("page", "/MyZoy/member/userDelete");
		model.addAttribute("title", "회원 탈퇴");
		return "member/authentication";
	}
	
	@RequestMapping("/userDelete")
	public String userDelete(Model model) {
		return "member/userDelete";
	}
	
	@RequestMapping("/findId")
	public String findId() {
		return "member/idFind";
	}
	
	@RequestMapping("/idFind")
	public String idFind(@RequestParam("uname") String name, @RequestParam("umail") String eMail,
			Model model) {
		MemberVO rs = memberService.findId(eMail);
		if(rs==null) {
			model.addAttribute("message", "존재하지 않는 회원입니다!");
			return "member/false";
		}

		if(rs.getName().equals(name)) {
			model.addAttribute("id", rs.getId());	
		} else {
			model.addAttribute("message", "존재하지 않는 회원입니다!");
			return "member/false";
		}
		return "member/idFind-result";
	}
	
	@RequestMapping("/findPw")
	public String findPw() {
		return "member/pwFind";
	}
	
	@RequestMapping("/pwFind-change")
	public String pwFindChange() {
		return "member/pwFind-change";
	}
	
	@RequestMapping("/pwFind")
	public String pwFind(@RequestParam("uid") String id, @RequestParam("umail") String eMail,
			Model model) {
		MemberVO rs = memberService.findId(eMail);
		if(rs==null) {
			model.addAttribute("message", "존재하지 않는 회원입니다!");
			return "member/false";
		}
		if(rs.getId().equals(id)) {
			model.addAttribute("id", rs.getId());
			model.addAttribute("tel", rs.getTel());
			return "member/pwFind-change";	
		} else {
			model.addAttribute("message", "존재하지 않는 회원입니다!");
			return "member/false";
		}
	}
	
	@RequestMapping("/changePw")
	public String changePw(@RequestParam("uid") String id, @RequestParam("pw1") String pw, @RequestParam("utel") String tel,
			Model model) {
			MemberVO vo = new MemberVO(id, pw, null, null, tel);
			memberService.updateMember(vo);
			model.addAttribute("things", "비밀번호 변경이");
			model.addAttribute("message", "변경된 비밀번호로 로그인 해주시기 바랍니다.");
			return "member/submit";
	}

}
