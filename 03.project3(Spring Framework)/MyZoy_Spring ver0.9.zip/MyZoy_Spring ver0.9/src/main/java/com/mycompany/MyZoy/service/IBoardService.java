package com.mycompany.MyZoy.service;

public interface IBoardService {
}
