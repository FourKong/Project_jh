package com.mycompany.MyZoy.model;

public class CoefVO{

	 public CoefVO(double about_marriage, double marriage, double car, double house, double parents, double live_alone, double house_form, double house_rental,
			double health, double body, double exercise, double work_life, double real_dream, double result_procedure, double individual_group, double me_other,
			double for_happiness, double edu, double int_family, double int_friend, double int_other) {
		super();
		this.about_marriage = about_marriage;
		this.marriage = marriage;
		this.car = car;
		this.house = house;
		this.parents = parents;
		this.live_alone = live_alone;
		this.house_form = house_form;
		this.house_rental = house_rental;
		this.health = health;
		this.body = body;
		this.exercise = exercise;
		this.work_life = work_life;
		this.real_dream = real_dream;
		this.result_procedure = result_procedure;
		this.individual_group = individual_group;
		this.me_other = me_other;
		this.for_happiness = for_happiness;
		this.edu = edu;
		this.int_family = int_family;
		this.int_friend = int_friend;
		this.int_other = int_other;
	}
	 
	 public CoefVO() {}

	double about_marriage, marriage, car, house, parents, live_alone, house_form, house_rental,
     health, body, exercise, work_life, real_dream, result_procedure, individual_group, me_other,
     for_happiness, edu, int_family, int_friend, int_other;

	public double getAbout_marriage() {
		return about_marriage;
	}

	public void setAbout_marriage(double about_marriage) {
		this.about_marriage = about_marriage;
	}

	public double getMarriage() {
		return marriage;
	}

	public void setMarriage(double marriage) {
		this.marriage = marriage;
	}

	public double getCar() {
		return car;
	}

	public void setCar(double car) {
		this.car = car;
	}

	public double getHouse() {
		return house;
	}

	public void setHouse(double house) {
		this.house = house;
	}

	public double getParents() {
		return parents;
	}

	public void setParents(double parents) {
		this.parents = parents;
	}

	public double getLive_alone() {
		return live_alone;
	}

	public void setLive_alone(double live_alone) {
		this.live_alone = live_alone;
	}

	public double getHouse_form() {
		return house_form;
	}

	public void setHouse_form(double house_form) {
		this.house_form = house_form;
	}

	public double getHouse_rental() {
		return house_rental;
	}

	public void setHouse_rental(double house_rental) {
		this.house_rental = house_rental;
	}

	public double getHealth() {
		return health;
	}

	public void setHealth(double health) {
		this.health = health;
	}

	public double getBody() {
		return body;
	}

	public void setBody(double body) {
		this.body = body;
	}

	public double getExercise() {
		return exercise;
	}

	public void setExercise(double exercise) {
		this.exercise = exercise;
	}

	public double getWork_life() {
		return work_life;
	}

	public void setWork_life(double work_life) {
		this.work_life = work_life;
	}

	public double getReal_dream() {
		return real_dream;
	}

	public void setReal_dream(double real_dream) {
		this.real_dream = real_dream;
	}

	public double getResult_procedure() {
		return result_procedure;
	}

	public void setResult_procedure(double result_procedure) {
		this.result_procedure = result_procedure;
	}

	public double getIndividual_group() {
		return individual_group;
	}

	public void setIndividual_group(double individual_group) {
		this.individual_group = individual_group;
	}

	public double getMe_other() {
		return me_other;
	}

	public void setMe_other(double me_other) {
		this.me_other = me_other;
	}

	public double getFor_happiness() {
		return for_happiness;
	}

	public void setFor_happiness(double for_happiness) {
		this.for_happiness = for_happiness;
	}

	public double getEdu() {
		return edu;
	}

	public void setEdu(double edu) {
		this.edu = edu;
	}

	public double getInt_family() {
		return int_family;
	}

	public void setInt_family(double int_family) {
		this.int_family = int_family;
	}

	public double getInt_friend() {
		return int_friend;
	}

	public void setInt_friend(double int_friend) {
		this.int_friend = int_friend;
	}

	public double getInt_other() {
		return int_other;
	}

	public void setInt_other(double int_other) {
		this.int_other = int_other;
	}
	
}