package com.mycompany.MyZoy.dao;

import org.apache.ibatis.annotations.Param;

import com.mycompany.MyZoy.model.MemberVO;
import com.mycompany.MyZoy.model.SurveyVO;

public interface IMemberRepository {
	void insertMember(@Param("vo") MemberVO vo);
	void insertSurvey(@Param("vo") SurveyVO vo);
	void updateSurvey(@Param("vo") SurveyVO vo);
	SurveyVO getSurvey(@Param("id") String id);
	int idCheck(@Param("id") String id);
	int emailCheck(@Param("eMail") String eMail);
	int userCheck(@Param("id") String id, @Param("pw") String pw);
	MemberVO setSession(@Param("id") String id); // takeSession
	MemberVO getMember(@Param("id") String id);
	void updateMember(@Param("vo") MemberVO vo);
	void updateMember(@Param("id, pw") String id, String pw);
	void deleteMember(@Param("id") String id);
	void deleteSurvey(@Param("id") String id);
	MemberVO findId(@Param("eMail") String eMail);
	String findPw(@Param("id, eMail") String id, String eMail);
}