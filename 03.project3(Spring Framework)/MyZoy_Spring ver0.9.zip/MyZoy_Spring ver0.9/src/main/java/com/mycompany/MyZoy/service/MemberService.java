package com.mycompany.MyZoy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.mycompany.MyZoy.dao.IMemberRepository;
import com.mycompany.MyZoy.model.MemberVO;
import com.mycompany.MyZoy.model.SurveyVO;

@Service
public class MemberService implements IMemberService{
	
	@Autowired
	@Qualifier("IMemberRepository")
	IMemberRepository memberRepository;
	
	@Override
	public void insertMember(MemberVO vo) { // insertMember
		memberRepository.insertMember(vo);
	}
	@Override
	public void insertSurvey(SurveyVO vo) { // insertSurvey
		memberRepository.insertSurvey(vo);
	}
	@Override
	public void updateSurvey(SurveyVO vo) {
		memberRepository.updateSurvey(vo);
	}
	@Override
	public SurveyVO getSurvey(String id) {
		return memberRepository.getSurvey(id);
	}
	@Override
	public int idCheck(String id) {
		return memberRepository.idCheck(id);
	}
	@Override
	public int emailCheck(String eMail) {
		return memberRepository.emailCheck(eMail);
	}
	@Override
	public int userCheck(String id, String pw) {
		return memberRepository.userCheck(id, pw);
	}
	@Override
	public MemberVO setSession(String id) { // takeSession
		return memberRepository.setSession(id);
	}
	@Override
	public MemberVO getMember(String id) {
		return memberRepository.getMember(id);
	}
	@Override
	public void updateMember(MemberVO vo) {
		memberRepository.updateMember(vo);
	}
	@Override
	public void updateMember(String id, String pw) { // 비밀번호 변경 시
		memberRepository.updateMember(id, pw);
	}
	@Override
	public void deleteMember(String id) {
		memberRepository.deleteMember(id);
	}
	@Override
	public void deleteSurvey(String id) {
		memberRepository.deleteSurvey(id);
	}
	@Override
	public MemberVO findId(String eMail) {
		return memberRepository.findId(eMail);
	}
	@Override
	public String findPw(String id, String eMail) {
		return memberRepository.findPw(id, eMail);
	}

}