var myChartArray = [];

function makePage(sat_data, coef, name) {
	
  const req = [[sat_data.sat_all, sat_data.sat_living, sat_data.sat_health, sat_data.sat_human],
  	  [sat_data.pred_all, sat_data.pred_living, sat_data.pred_health, sat_data.pred_human]];
  
  const which = new Array("me", "other");
  const sat_type = new Array("전체", "생활수준", "건강", "대인관계")
  const sat_me = new Array("all", "living", "health", "human"); // 템플릿 리터럴에 사용할 배열.
  const sat_color = new Array('rgba(60,179,113,0.8)', 'rgba(0,191,255, 0.8)', 'rgba(250,128,114,0.8)');
  for(let i = 0; i <2; i++) {
    for (let j = 0; j < sat_me.length; j++) {

    // 도넛 그래프 생성
    var ctx = document.querySelector(`#sat_${sat_me[j]}_${which[i]}`).getContext('2d');
    
    let color;
    if (i==0) { a=1; }
    else { a= -1; }
    if (req[i][j] == req[i+a][j]) {
    	color = sat_color[0];
    } else if (req[i][j] > req[i+a][j]) {
    	color = sat_color[1];
    } else if (req[i][j] < req[i+a][j]) {
    	color = sat_color[2];
    }
    let score = req[i][j];

    let titleSize =$(`#sat_${sat_me[j]}_${which[i]}`).width()*0.087;

    // 그래프 생성
    myChartArray.push(new Chart(ctx, { // 그래프 생성용 변수라 원래 안 쓰이는 게 맞음.
    	type: 'doughnut',
        data: {
          labels: [], // x축 레이블
          datasets: [{ // 데이터 외형 설정
            data: [score, 10-score], // 아래의 push를 통해 데이터 받음.
            backgroundColor: [ // 바 색상       
            color,
            'rgb(255,255,255)'
            ],
            borderColor: [ // 막대 테두리 색상              
            color,
            color
            ],
            borderWidth: 2 // 테두리 두께
          }]
        },
        options: {
          tooltips: {enabled: false},
          hover: {mode: null},
          elements: {
            center: {
              text: `${score}점`,
              title: `${sat_type[j]} 만족도`,
              titleSize: titleSize,
              color: color, // Default is #000000
              fontStyle: 'GmarketSansMedium', // Default is Arial
              sidePadding: 20, // Default is 20 (as a percentage)
              minFontSize: 10, // Default is 20 (in px), set to false and text will not wrap.
              lineHeight: 25 // Default is 25 (in px), used for when text wraps
            },
          },
          responsive: false,
          cutoutPercentage: 90, // 중앙 구멍 크기
          legend: {
            display: false
          },
          layout: {
            padding: 0
          }
        }
      }));
    }
  }
  myInfo(sat_data);
  recommand(sat_data, coef, name);
}
// --------- 이하 나의 정보 관련 ----------
 
function myInfo(sat_data) {
  let age_info = document.querySelector(".my_age")
  let sex_info = document.querySelector(".my_sex")
  let edu_info = document.querySelector(".my_edu")
  let marriage_info = document.querySelector(".my_marriage")
  let house_info = document.querySelector(".my_house")
  let car_info = document.querySelector(".my_car")

  let life_value = [sat_data.work_life, sat_data.real_dream, sat_data.result_procedure, sat_data.individual_group, sat_data.me_other];
  for(let i = 0; i<life_value.length; i++) {
  	var value_a = document.querySelector(`.v-${i+1}-a`);
  	var value_b = document.querySelector(`.v-${i+1}-b`);
  	var value = document.querySelectorAll(".slider-value")
 	if(life_value[i]<3) {
    	value_a.style.color='darkblue';
    	value_a.style.fontSize='108%';
  		value_a.style.fontWeight='bold';
  		value_a.style.lineHeight='1.5';
    	value_b.style.color='gray';
    	value_b.style.fontSize='85%';
    	value_b.style.fontWeight='normal';
    	value_b.style.lineHeight='1';
 		value[i].style.color='darkblue';
    } else if(life_value[i]==3) { 
   		value_a.style.color='darkblue';
   		value_a.style.fontSize='108%';
 		value_a.style.fontWeight='bold';
 		value_a.style.lineHeight='1.5';
   		value_b.style.color='RGB(96, 120, 96)';
    	value_b.style.fontSize='96%';
    	value_b.style.fontWeight='bold';
    	value_b.style.lineHeight='1.2';
 		value[i].style.color='darkblue';
   	} else if(life_value[i]==4) {
   		value_a.style.color='green';
   		value_a.style.fontSize='108%';
 		value_a.style.fontWeight='bold';
 		value_a.style.lineHeight='1.5';
   		value_b.style.color='green';
   		value_b.style.fontSize='108%';
 		value_b.style.fontWeight='bold';
 		value_b.style.lineHeight='1.5';
 		value[i].style.color='green';
   	} else if(life_value[i]==5) {
   		value_a.style.color='RGB(96, 120, 96)';
   		value_a.style.fontSize='96%';
 		value_a.style.fontWeight='bold';
 		value_a.style.lineHeight='1.2';
   		value_b.style.color='brown';
   		value_b.style.fontSize='108%';
 		value_b.style.fontWeight='bold';
 		value_b.style.lineHeight='1.5';
 		value[i].style.color='brown';
   	}else if(life_value[i]>5) {
   		value_a.style.color='gray';
   		value_a.style.fontSize='85%';
    	value_a.style.fontWeight='normal';
    	value_a.style.lineHeight='1';
   		value_b.style.color='brown';
   		value_b.style.fontSize='108%';
 		value_b.style.fontWeight='bold';
 		value_b.style.lineHeight='1.5';
 		value[i].style.color='brown';
 		}
 	}
}
  // --------- 이하 추천 사항 관련 ----------
function recommand(sat_data, coef, name){
  const req = [[sat_data.sat_all, sat_data.sat_living, sat_data.sat_health, sat_data.sat_human],
 	  [sat_data.pred_all, sat_data.pred_living, sat_data.pred_health, sat_data.pred_human]];
  const sat_set = ["전체", "생활수준", "건강", "대인관계"];
  const text_box = document.querySelectorAll(".rmd-updown");
  for(let i=0; i<coef.length; i++){
	  let enough = 0;
	  const coef_set = []
	  for (const key in coef[i]) {
		  const value = coef[i][key];
		  if (Math.abs(value)>=0.22) {
			  if(key=="about_marriage") {
				  if(value > 0 && sat_data.about_marriage!=3) {
					  coef_set.push([value, "<span>결혼에 대한 가치관</span>입니다. 결혼이 필요하다고 생각하는 경향이 짙을수록 만족도가 높게 나타났습니다. " +
					  		"<br>결혼이 필요 없거나 해도 그만 안 해도 그만이라고 생각하신다면, 생각을 바꿔서 인생의 동반자에 대해 고민해보시는 것을 추천드립니다."]);
				  } else if (value < 0 && sat_data.about_marriage!=1) {
					  coef_set.push([value, "<span>결혼에 대한 가치관</span>입니다. 결혼이 필요없다고 생각하는 경향이 짙을수록 만족도가 높게 나타났습니다. " +
					  		"<br>결혼이 반드시 필요하다고 생각하시다면, 인생의 동반자의 필요성에 대해 재고해보시는 것을 추천드립니다."]);}
			  } else if (key=="marriage"){ // 결혼 안 한 경우
				  if(value < 0 && sat_data.marriage==2) {coef_set.push([value, "<span>결혼</span>입니다. 결혼을 한 경우가 일반적으로 만족도가 높게 나타났습니다. " +
				  		"<br>당장 결혼 계획이 없으시다면, 천천히 주위를 둘러보고 결혼에 대해 고려해보는 것을 추천드립니다."]);}
			  } else if (key=="car") { // 차 없는 경우
				  if(value < 0 && sat_data.car==2) {coef_set.push([value, "<span>자차 유무</span>입니다. 자차를 보유한 것이 만족도에 영향을 주는 것으로 분석되었습니다. " +
				  		"<br>저렴한 중고차를 구매하시거나, 조금 무리해서라도 멋진 신차를 구매하신다면 당신의 만족도가 눈에 띄게 상승할 것입니다."]);}
			  } else if (key=="house") { // 집 없는 경우만.
				  if(value < 0 && sat_data.house==2) {coef_set.push([value, "<span>자가 유무</span>입니다. 자가를 보유한 것이 만족도에 영향을 주는 것으로 분석되었습니다. " +
				  		"<br>내 집 마련을 위해 대출을 받아보시는 것은 어떨까요? 대출로 인한 상심보다 내 집 마련으로 인한 행복이 더 크게 와닿을 것입니다."]);}
			  } else if (key == "parents") { // 부모 동거
				  if(value < 0 && sat_data.parents!=1) {
					  coef_set.push([value, "<span>부모 동거 여부</span>입니다. 일반적으로 부모와 함께 사는 경우, 만족도가 높은 것으로 보여집니다. " +
					  		"<br>부모와 별거중인 당신! 여건이 된다면, 부모님 곁으로 돌아가세요! 부모님과 함께 사는 것이 정서적으로 만족감을 줄 것입니다."]);
				  } else if(value > 0 && sat_data.parents!=3) {
					  coef_set.push([value, "<span>부모 동거 여부</span>입니다. 일반적으로 부모로부터의 독립 정도가 강할수록 만족도가 높게 나타납니다. " +
					  		"<br>특히 단순 별거보다, 경제적으로도 완전히 독립한 경우가 만족도가 높게 나타납니다. 지금부터 천천히 독립을 준비해보세요."]);
				  }
	          } else if (key == "live_alone") { // 1인 가구
				  if(value < 0 && sat_data.live_alone!=1) {
					  coef_set.push([value, "<span>1인 가구 여부</span>입니다. 전체적으로 혼자 사는 사람들의 만족도가 더 높은 경향을 보입니다. " +
					  		"<br>가능하다면, 혼자만의 공간에서 새 삶을 꾸려보는 것은 어떨까요? 불가능하다면 혼자만의 시간을 늘리고, 혼자만의 공간을 가꾸는 것도 하나의 방법일 것입니다."]);
				  } else if (value > 0 && sat_data.parents!=2){
					  coef_set.push([value, "<span>1인 가구 여부</span>입니다. 혼자 사는 사람들은 해당 만족도가 낮게 나타납니다. " +
					  		"<br>부모, 형제, 친구, 애인이 있다면, 그들과 당신의 삶의 공간을 공유해보세요. 당장 동거할 수 없는 상황이라면, 종종 그들에게 찾아가 하루이틀을 보내고 오는 것도 하나의 방법일 것입니다."]);
				  }
	          } else if (key == "house_form") { // 주택 형태
				   if (value > 0){
					  coef_set.push([value, "<span>주택 형태</span>입니다. 원룸보단 빌라, 빌라보단 단독주택 및 아파트, 오피스텔에 거주하는 것이 만족도가 높게 나타납니다. " +
					  		"<br>주택 형태와 무관하게 부모와 동거하는 것도 만족도를 올리는 비결입니다. 이사를 통해 새로운 공간에서 더 나은 삶을 영위해보세요."]);
				  }
	          } else if (key == "house_rental") { // 자가 아닌 경우만
				  if(value > 0 && sat_data.house_rental!=3){
					  coef_set.push([value, "<span>주택 점유 형태</span>입니다. 월세보단 전세가, 전세보단 자가 보유가 더 높은 만족도를 보여줍니다. " +
					  		"<br>현재 월세에 거주하고 있다면 전세로 바꾸는 것도 좋은 방법입니다. 대출을 통해 내 집을 마련하는 것도 좋은 방법이며, 상황이 여의치 않다면 부모님과 함께 살면서 집에 드는 돈을 줄이는 것도 만족도를 올리는 방법 중 하나입니다."]);
				  }
	          } else if (key == "health") {  
				  if(value > 0 && sat_data.health!=5) {
					  coef_set.push([value, "<span>건강</span>입니다. 건강이 만족도에 끼치는 영향이 작지 않다는 사실, 알고 계셨나요? " +
					  		"<br>건강 검진을 한 번 받아보시는 것은 어떨까요? 아니면 꾸준한 운동, 영양제 섭취, 숙면 등의 방법으로 건강과 만족도를 한 번에 올려보세요!"]);
				  }
	          } else if (key == "body") {  
	        	  if(value < 0 && sat_data.body!=1) {
					  coef_set.push([value, "<span>체형</span>입니다. 체중이 많이 나갈수록, 비만일수록 만족도가 떨어지는 경향이 나타납니다. " +
					  		"<br>건강을 위해서, 스스로의 신체를 가꾸기 위해서, 행복을 위해서! 다양한 방법으로 당신의 체형을 교정해보세요. 효과는 즉시 나타날 것입니다."]);
	        	  }
	          } else if (key == "exercise") {  
				  if(value < 0 && sat_data.exercise!=1) {
					  coef_set.push([value, "<span>운동</span>입니다. 지나친 운동은 당신의 만족도를 떨어뜨립니다. " +
					  		"<br>운동이 삶에 긍정적 영향을 끼친다는 사실은 부정할 수 없지만, 당신의 운동량이 너무 많거나, 운동의 정도가 격하다면 오히려 만족도가 떨어질 수 있습니다. 본인에게 맞는 적절한 운동 강도와 횟수를 찾아보세요!"]);
				  } else if (value > 0 && sat_data.exercise!=5) {
					  coef_set.push([value, "<span>운동</span>입니다. 운동량이 많다면, 당신의 만족도도 높아집니다." +
					  		"<br>당신의 여력이 충분하다면, 운동량을 높여 건강과 행복을 동시에 잡아보세요!"]);
				  }
	          } else if (key == "work_life") {  
				  if(value < 0 && sat_data.work_life>2){
					  coef_set.push([value, "<span>일과 여가에 대한 가치관</span>입니다. 일을 중요하게 여기는 사람일수록 만족도가 높게 나타났습니다. " +
					  		"<br>장기적인 행복을 위해서, 눈 앞의 안락함보다는 일에 조금만 더 집중해보시는 건 어떨까요?"]);
				  } else if (value > 0 && sat_data.work_life<5){
					  coef_set.push([value, "<span>일과 여가에 대한 가치관</span>입니다. 여가를 중요하게 여기는 사람일수록 만족도가 높게 나타났습니다. " +
					  		"<br>너무 일에 몰입하고 있진 않은가요? 열심히 일하는 것도 좋습니다만, 조금만 숨을 돌리고 주위를 둘러보세요. 행복은 멀리 있지 않습니다."]);
				  }
	          } else if (key == "real_dream") {  
				  if(value < 0 && sat_data.real_dream>2) {
					  coef_set.push([value, "<span>현실과 이상에 대한 가치관</span>입니다. 현실을 중시하는 사람일수록 행복의 정도가 높습니다. " +
					  		"<br>지나치게 이상적인 것을 좇고 계시진 않습니까? 조금만 더 현실적인 사람이 되어보세요. 현실적인 행복이 당신을 기다릴 것입니다."]);  
				  } else if (value > 0 && sat_data.real_dream<5) {
					  coef_set.push([value, "<span>현실과 이상에 대한 가치관</span>입니다. 이상을 중시하는 사람일수록 행복의 정도가 높습니다. " +
					  		"<br>너무 현실에 목매지 마세요. 조금만 더 당신의 이상을 관철해보는 건 어떨까요? 당신의 꿈을 소중히 간직하세요."]);  
				  }
	          } else if (key == "result_procedure") {  
				  if(value < 0 && sat_data.result_procedure>2) {
					  coef_set.push([value, "<span>결과와 과정에 대한 가치관</span>입니다. 결과를 중시하는 사람이 만족도도 높게 나타납니다. " +
					  		"<br>과정 또한 중요하지만, 결과가 따라주지 않는다면 쉽게 만족할 수 없겠죠. 과정에 만족하지 말고, 결과가 나올 때까지 노력하는 사람이 되어보세요."]);  
				  } else if (value > 0 && sat_data.result_procedure<5) {
					  coef_set.push([value, "<span>결과와 과정에 대한 가치관</span>입니다. 과정을 중시하는 사람이 만족도도 높게 나타납니다. " +
					  		"<br>결과도 중요하지만, 그 과정에서 얼마나 노력했느냐도 당신의 만족도에 큰 영향을 미칩니다. 결과를 위해 과정을 경시하지 마세요. 당신이 노력해온 순간순간이 곧 당신의 행복입니다."]);  
				  }
	          } else if (key == "individual_group") {  
				  if(value < 0 && sat_data.individual_group>2) {
					  coef_set.push([value, "<span>개인과 집단에 대한 가치관</span>입니다. 개인을 중요하게 여길수록 높은 만족도를 보입니다. " +
					  		"<br>집단 생활에 너무 집착하고 있진 않나요? 집단보다는 조금 더 자기 자신을 소중히 여겨보세요. 그것이 행복을 향해 내딛는 첫 발걸음이 될 겁니다."]);  
				  } else if (value > 0 && sat_data.individual_group<5) {
					  coef_set.push([value, "<span>개인과 집단에 대한 가치관</span>입니다. 집단를 중요하게 여길수록 높은 만족도를 보입니다. " +
					  		"<br>너무 개인 중심적인 생활을 하고 있지는 않나요? 단체 생활 속에서만 느낄 수 있는 행복도 있는 법입니다. 조금 더 주위를 둘러보고, 주위 사람들과 어울리려는 노력을 해봅시다."]);   
				  }
	          } else if (key == "me_other") {
				  if(value < 0 && sat_data.me_other>2) { 
					  coef_set.push([value, "<span>자기 주관과 타인의 이목에 대한 가치관</span>입니다. 타인의 시선에 얽매이지 않고, 뚜렷한 자기 주관을 가진 사람이 더 행복한 삶을 산다고 합니다. " +
					  		"<br>자기 주관을 좀 더 확고히 해보세요. 타인의 시선에 지나치게 얽매일 필요는 없습니다. 행복은 남이 주는 것이 아니라, 당신 스스로가 만드는 것입니다."]);  
				  } else if (value > 0 && sat_data.me_other<5) {
					  coef_set.push([value, "<span>자기 주관과 타인의 이목에 대한 가치관</span>입니다. 자기 주관도 중요하지만, 타인의 이목에 관심을 두는 사람이 더 행복한 삶을 산다고 합니다. " +
					  		"<br>세상은 남들과 어우러져 살아가는 곳입니다. 타인의 시선이란 말이 언뜻 부정적으로 들릴 수 있지만, 자존감은 타인과의 관계 속에서 형성되는 것입니다. 조금만 남들이 나를 어떻게 생각하는지 돌아보세요."]);  
				  }
	          } else if (key == "int_family") {  
				  if(value < 0 && sat_data.int_family>2) {
					  coef_set.push([value, "<span>가족 교류 빈도</span>입니다. 가족과 교류 빈도가 높은 경우 만족도가 높게 나타납니다. " +
					  		"<br>가족과 너무 소원하지 않나요? 가족과의 적당한 교류는 당신의 심신에 안정을 심어줍니다. 간만에 가족에게 연락해보는 건 어떨까요?"]);  
				  } else if (value > 0 && sat_data.int_family<5) {
					  coef_set.push([value, "<span>가족 교류 빈도</span>입니다.가족과의 교류 빈도가 낮은 경우 만족도가 높게 나타납니다. " +
					  		"<br>가족에 너무 얽매여 있진 않으신가요? 가족과 적당한 거리를 유지하는 것이 오히려 돈독함과 행복을 향한 길일 수 있습니다."]);  
				  }
	          } else if (key == "int_friend") {  
				  if(value < 0 && sat_data.int_friend>2) {
					  coef_set.push([value, "<span>친구 교류 빈도</span>입니다. 친구를 자주 만나는 사람일수록 만족도가 높게 나타납니다. " +
					  		"<br>친구와 마지막으로 연락한 것이 언제인가요? 소중한 친구들과 더욱 자주 만나 놀며 스트레스를 날려봅시다."]);  
				  } else if (value > 0 && sat_data.int_friend<5) {
					  coef_set.push([value, "<span>친규 교류 빈도</span>입니다. 친구와 만나는 횟수가 적을수록 만족도가 높게 나타납니다.. " +
					  		"<br>너무 친구 관계에 집착하고 계신 건 아닐까요? 제아무리 죽마고우라도, 혼자만의 시간을 대체할 순 없습니다. 오롯이 당신의 시간을 가져보세요."]);   
				  }
	          } else if (key == "int_other") {
				  if(value < 0 && sat_data.int_other>2) { 
					  coef_set.push([value, "<span>대인 교류 빈도</span>입니다. 다른 사람과 자주 교류할수록 만족도가 높게 나타납니다. " +
					  		"<br>세상에는 가족과 친구만 있는 것이 아닙니다. 직장 동료, 동호회 회원, 이웃집 주민 등 다양한 사람들을 만나고 인간 관계를 넓혀보는 건 어떨까요? 늘어난 관계만큼 만족도도 올라갈 것입니다."]);  
				  } else if (value > 0 && sat_data.int_other<5) {
					  coef_set.push([value, "<span>대인 교류 빈도</span>입니다. 타인과의 교류가 적을수록 만족도는 높은 추세를 보입니다.. " +
					  		"<br>세상 많은 사람들을 다 챙길 순 없습니다. 직장, 학교, 동호회, 자치회… 많고 많은 관계에 지치신 건 아닐까요? 잠시 혼자만의 시간을 가져봅시다."]);  
				  }
	          } else if (key == "for_happiness") {  
//				  coef_set.push([value, "11"]);
	          } else if (key == "edu") {  
				  if(value > 0 && sat_data.edu!=5) {
					  coef_set.push([value, "<span>학력</span>입니다. 높은 학력은 당신에게 큰 만족감을 가져다줍니다." +
					  		"<br>우리는 아직 젊기 때문에, 공부를 위해 충분한 시간을 할애할 수 있습니다. 공부에 뜻을 두고, 더 높은 곳을 향해 도전해보세요."]);  
				  }
				  
	          }
		  } 
	  } // for문 종료.
	  coef_set.sort(compareValuesDescending);
	  let abj, sug;
	  let isNull = ["가장 큰 영향을 끼치는 것은", "두 번째로 영향을 주는 요인은", "대해 마지막으로 추천드리는 요소는"];
	  if (req[0][i] == req[1][i]) {
		  abj = "과 같습니다.";
		  if (req[0][i] >= 9) sug = "<br>이미 만족도가 충분히 높아, 저희의 제안이 필요하지 않을 것 같습니다. 이번 만족도는 넘어갈게요.";
          else sug = "<br>그러나 만족도가 더 올라갈 여지가 남아있네요. 다음과 같은 방법을 제안드려요."
	  }
	  else if (req[0][i] > req[1][i]) {
		  abj = "보다 높군요!";
		  if (req[0][i] >= 9) {sug = "<br>이미 만족도가 충분히 높아, 저희의 제안이 필요하지 않을 것 같습니다. 다음 만족도로 넘어가볼게요.";
		  enough=1;}
		  else sug = "<br>그러나 만족도가 더 올라갈 여지가 남아있네요. 다음과 같은 방법을 제안드려요."
	  }
	  else abj = "보다 낮네요.", sug = "<br>하지만 걱정하지 마세요. 만족도를 향상시킬 다음과 같은 방법을 제안드립니다.";
	  
	  text_box[i].innerHTML = `<span>${name}</span>님의 <span>${sat_set[i]} 만족도</span>는 <span>${req[0][i]}점</span>입니다.
		  예상 만족도 ${req[1][i]}점${abj}${sug}<br><span class="rmds" style="color:#606060"></span><span class="rmds" style="color:#606060"></span><span class="rmds" style="color:#606060"></span>`;
	  const rmds_box = text_box[i].querySelectorAll(".rmds");
	  
	  for(let a=0; a<3; a++) {
		  if (enough==1) {continue;}
		  if(coef_set[0]===undefined) {rmds_box[a].innerHTML =
			`<br>저희가 추천해드릴 요소가 없습니다. 추천할 사항에 이미 전부 해당하고 계세요! 그럼에도 만족도가 낮다면, 다른 문제가 존재하는 것일 수 있습니다. 자신의 환경을 객관적으로 돌아보거나, 주변 환경을 개선하기 위해 노력해보세요.`;
		  	enough=1;}
		  if(coef_set[a]!=undefined) {
			  rmds_box[a].innerHTML = `<br><span>${sat_set[i]} 만족도</span>에 ${isNull[a]} ${coef_set[a][1]}<br>`
		  }
	  }

	  }
	  // 이하 txt 박스 위한 변수 선언
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function updateGraphs(coef, name) {
	var form = document.querySelector('#userForm');
    var formData = new FormData(form);
    var sat_data = {};
    for (const [name, value] of formData.entries()) {
        sat_data[name] = parseInt(value);
    }
    
        // Flask 서버
    $.ajax({
        type: "POST",
        url: "http://127.0.0.1:8182/predict",  // Flask 서버 주소
        data: JSON.stringify(sat_data),
        contentType: "application/json",
        success: function(response) {
            for (var key in response) {
                $("<input>").attr({
                    type: "hidden",
                    name: key,
                    value: response[key]
                }).appendTo(".fieldset");

                // 업데이트를 위한 클로저 생성
                (function(key) {
                    sat_data[key] = response[key];
                })(key);
            }

            // 업데이트된 데이터로 req 배열 구성
            const req = [
                [sat_data.sat_all, sat_data.sat_living, sat_data.sat_health, sat_data.sat_human],
                [sat_data.pred_all, sat_data.pred_living, sat_data.pred_health, sat_data.pred_human]
            ];
      	  const which = new Array("me", "other");
    	  const sat_type = new Array("전체", "생활수준", "건강", "대인관계")
    	  const sat_me = new Array("all", "living", "health", "human"); // 템플릿 리터럴에 사용할 배열.
    	  const sat_color = new Array('rgba(60,179,113,0.8)', 'rgba(0,191,255, 0.8)', 'rgba(250,128,114,0.8)');
    	  
    	  for (let i = 0; i < 2; i++) {
    		    for (let j = 0; j < sat_me.length; j++) {		      
    		      let color;
    		      if (i==0) { a=1; }
    		      else { a= -1; }
    		      if (req[i][j] == req[i+a][j]) {
    		       	color = sat_color[0];
    		      } else if (req[i][j] > req[i+a][j]) {
    		       	color = sat_color[1];
    		      } else if (req[i][j] < req[i+a][j]) {
    		      	color = sat_color[2];
    		      }
    		      let score = req[i][j];
    		      
    		    myChartArray[i * sat_me.length + j].data.datasets[0].data = [score, 10-score]; // 데이터 업데이트
    		    myChartArray[i * sat_me.length + j].options.elements.center.text = `${score}점`;
    		    myChartArray[i * sat_me.length + j].data.datasets[0].backgroundColor = [color, 'rgb(255,255,255)'];
    		    myChartArray[i * sat_me.length + j].data.datasets[0].borderColor = [color, color];
    		    myChartArray[i * sat_me.length + j].options.elements.center.color = color;
    		    myChartArray[i * sat_me.length + j].update(); // 그래프 다시 그리기
    		    }
    		  }
    	  recommand(sat_data, coef, name);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log("Error:", textStatus, errorThrown);
        }
        
    });
    
    if (window.innerWidth > 1200) {
    	const targetElement = document.querySelector('.img-center-mysat');
    	targetElement.scrollIntoView({
    		behavior: 'smooth', 
    		block: 'center'
    	});
    } else if (window.innerWidth <= 1200) {
    	const targetElement = document.querySelector('#clickBtn');
    	targetElement.scrollIntoView({
    		behavior: 'smooth', 
    		block: 'start'
    	});
    }
}


// 이하 익명 함수/별도의 호출 필요 X 함수.


// 추천 박스 높이 조절 함수

function compareValuesDescending(a, b) {
	  return Math.abs(b[0]) - Math.abs(a[0]);
	}

function updateTextBoxes() {
	  const textBoxes = document.querySelectorAll(".rmd-textbox");
	  textBoxes.forEach(textBox => {
	    const rmdUpDown = textBox.querySelector(".rmd-updown");

	    // <div>의 높이를 텍스트의 길이에 맞추기
	    textBox.style.height = "auto"; // 높이 초기화
	    const textHeight = rmdUpDown.clientHeight + 50;
	    textBox.style.height = textHeight + 'px'; // 텍스트의 길이에 맞춤
	  });
	}


// 초기값 설정을 위한 함수

function setSelectedValues(dto) {
	  var firstTableSelectElements = document.querySelectorAll('.myInformation select');
	  firstTableSelectElements.forEach(function (selectElement) {
	    var dtoPropertyName = selectElement.getAttribute('name'); 
	    var selectedValue = dto[dtoPropertyName];
	    if (selectedValue !== undefined) {
	      selectElement.value = selectedValue;
	    }
	  });

	  var secondTableSelectElements = document.querySelectorAll('.ectValue select');
	  secondTableSelectElements.forEach(function (selectElement) {
	    var dtoPropertyName = selectElement.getAttribute('name');
	    var selectedValue = dto[dtoPropertyName];
	    if (selectedValue !== undefined) {
	      selectElement.value = selectedValue;
	    }
	  });
	}

// load resize시 graph 크기 조절 함수

$(window).on('load resize',function(){
	updateTextBoxes();
	  let leng = $(window).width()+17;
	  if(leng>1200) {
	      var graph = document.querySelectorAll('.graph-mini');
	      graph.forEach(mini => {
	          mini.style.width = '27.33333333%';
	          mini.style.margin = '3%';
	      });
	      var graphs = document.querySelectorAll('.graph');
	      graphs.forEach(mini => {
	          mini.style.width = '37%';
	          mini.style.margin = '0 auto';
	      });
	} else if(leng<=1200) {
	  var graph = document.querySelectorAll('.graph-mini');
	      graph.forEach(mini => {
	          mini.style.width = '60%';
	          mini.style.margin = '15px 20% 0 20%';
	      });
	      var graphs = document.querySelectorAll('.graph');
	      graphs.forEach(mini => {
	          mini.style.width = '60%';
	          mini.style.margin = '15px 20% 0 20%';
	      });
	} 
	});


// slider 움직이면 thumb 안의 숫자도 움직이는 함수

$(document).ready(function() {
	  function updateSliderValue(slider) {
	    var value = $(slider).val();
	    var sliderValue = $(slider).next(".slider-value");
	    var sliderValueElement = document.querySelector('.slider-value');
	    var thumbWidth = sliderValueElement.offsetWidth;

	    var offset = (value - 1) / (parseInt($(slider).attr("max")) - 1) * ($(slider).width() - thumbWidth);
	    
	    sliderValue.text(value);
	    if(parseInt(value) >4) {offset+=0.2;}
	    sliderValue.css("left", offset + "px");
	    
        var sliderValues = {}; 

        $(".slide").each(function() {
            var id = $(this).attr("id");
            var value = $(this).val();
            sliderValues[id] = parseInt(value);
        });
        let timerId;
        myInfo(sliderValues);
        clearTimeout(timerId);
        timerId = setTimeout(function() {myInfo(sliderValues);}, 10);
	  }

	  function handleSliderEvents() {
		    $(".slide").on("input", function() {
		      updateSliderValue(this);
		    });

		    $(".slide").each(function() {
		      updateSliderValue(this);
		    });
		  }

		  // 슬라이더 이벤트 핸들링 함수 호출
		  handleSliderEvents();
		  
		  var fixAgain;

		  // 윈도우 리사이즈에 대응
		  $(window).on("resize", function() {
		    handleSliderEvents();
		    clearTimeout(fixAgain);
	        fixAgain = setTimeout(function() {handleSliderEvents();}, 25); 
		  });
});
const sliders = document.querySelectorAll('.slide');

sliders.forEach(slider => {
const sliderValue = slider.nextElementSibling;

slider.addEventListener('input', function() {
  const value = this.value;
  sliderValue.textContent = value;
});
});


// Chart 위에 text 올리는 함수

Chart.plugins.register({
  beforeDraw: function (chart) {
	  if (chart.config.options.elements.center) {
	      //Get ctx from string
	      var ctx = chart.chart.ctx;

	      //Get options from the center object in options
	      var centerConfig = chart.config.options.elements.center;
	      var fontSize = centerConfig.fontSize || '50';
	      var fontStyle = centerConfig.fontStyle || 'Arial';
	      var txt = centerConfig.text;
	      var title = centerConfig.title;
	      var color = centerConfig.color || '#000';
	      var sidePadding = centerConfig.sidePadding || 20;
	      var sidePaddingCalculated = (sidePadding/100) * (chart.innerRadius * 2)
	      //Start with a base font of 30px
	      ctx.font = fontSize + "px " + fontStyle;

	      //Get the width of the string and also the width of the element minus 10 to give it 5px side padding
	      var stringWidth = ctx.measureText(txt).width;
	      var elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;

	      // Find out how much the font can grow in width.
	      var widthRatio = elementWidth / stringWidth;
	      var newFontSize = Math.floor(30 * widthRatio);
	      var elementHeight = (chart.innerRadius * 0.7);

	      // Pick a new font size so it will not be larger than the height of label.
	      var fontSizeToUse = Math.min(newFontSize, elementHeight);

	      //Set font settings to draw it correctly.
	      ctx.textAlign = 'center';
	      ctx.textBaseline = 'middle';
	      var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
	      var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);

	      ctx.font = fontSizeToUse+"px " + fontStyle;
	      ctx.fillStyle = color;

	      //Draw text in center
	      ctx.fillText(txt, centerX, centerY*(1.23));
	      fontSize = centerConfig.titleSize*1.2;
	      fontStyle = 'GmarketSansMedium';
	      ctx.font = fontSize + "px " + fontStyle;
	      ctx.fillText(title, centerX, centerY*(0.75));
	    }
  	}
});

document.addEventListener("DOMContentLoaded", function() {
    const parentsSelect = document.querySelector("select[name='parents']");
    const houseFormSelect = document.querySelector("select[name='house_form']");
    const houseRentalSelect = document.querySelector("select[name='house_rental']");
    
    parentsSelect.addEventListener("change", function() {
        if (parentsSelect.value === "1") {
            houseFormSelect.value = "6";
            houseRentalSelect.value = "5";
            
            houseFormSelect.readOnly = true;
            houseRentalSelect.readOnly = true;
        } else {
            houseFormSelect.value = "1";
            houseRentalSelect.value = "1";
            
            houseFormSelect.readOnly = false;
            houseRentalSelect.readOnly = false;
        }
        updateSelectStyles();
    });

    function updateSelectStyles() {
        if (parentsSelect.value === "1") {
            houseFormSelect.classList.add("disabled-select");
            houseRentalSelect.classList.add("disabled-select");
        } else {
            houseFormSelect.classList.remove("disabled-select");
            houseRentalSelect.classList.remove("disabled-select");
        }
    }
    
    parentsSelect.dispatchEvent(new Event("change"));
});