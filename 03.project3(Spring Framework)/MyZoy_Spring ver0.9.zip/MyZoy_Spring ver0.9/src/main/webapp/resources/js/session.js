function sessionCheck(session) {
	if (session != "yes") {
		alert("로그인이 필요한 페이지입니다.");
        const form = document.createElement('form');
        form.method = 'GET';
        form.action = '/MyZoy/login';
        document.body.appendChild(form);
        form.submit();
	}
}

function loginHeader(session) {
	const log = document.querySelectorAll(".login_myP");
	const user = document.querySelectorAll(".join_logout");
	if (session == "yes") {
		log.forEach(element => element.innerHTML="<a href=/MyZoy/member/myPage>마이 페이지</a>");
		user.forEach(element => element.innerHTML="<a href=/MyZoy/member/logout>로그아웃</a>");
	} else if (session != "yes") {
		log.forEach(element => element.innerHTML="<a href=/MyZoy/login>로그인</a>");
		user.forEach(element => element.innerHTML="<a href=/MyZoy/join>회원가입</a>");
	}
}

function loginPage(session) {
	if (session == "yes") {
        const form = document.createElement('form');
        form.method = 'GET';
        form.action = '/MyZoy';
        document.body.appendChild(form);
        form.submit();
	}
}

function pwFindSession(request) {
	if (request != "find") {
        const form = document.createElement('form');
        form.method = 'GET';
        form.action = '/MyZoy';
        document.body.appendChild(form);
        form.submit();
	}
}

function adminCheck(session) {
	if (session != "1") {
        const form = document.createElement('form');
        form.method = 'GET';
        form.action = '/MyZoy/board';
        document.body.appendChild(form);
        form.submit();
	}
}