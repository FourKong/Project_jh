
import java.util.Scanner;

public class SmartPhoneMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner in = new Scanner(System.in);
		
		SmartPhone smartPhone = new SmartPhone();
		
		System.out.println("#데이터 2개를 입력합니다.");
		for(int i=0; i<2; i++)
			smartPhone.addAddr(smartPhone.inputAddrData());
		
		smartPhone.printAllAddr();
		
		while(true) {
			smartPhone.menu();
			String select = in.nextLine();
			
			if(select.equals("1")) {
				smartPhone.addAddr(smartPhone.inputAddrData());
			} else if(select.equals("2")) {
			    smartPhone.printAllAddr();
			} else if(select.equals("3")) {
				System.out.println("검색할 이름을 입력해주세요.");
				smartPhone.searchAddr(in.nextLine());
			} else if(select.equals("4")) {
				System.out.println("삭제할 이름을 입력해주세요.");
				smartPhone.deleteAddr(in.nextLine());
			} else if(select.equals("5")) {
				System.out.println("수정할 이름을 입력해주세요.");
				String name = in.nextLine();
				System.out.println("수정할 정보를 입력해주세요.");
				smartPhone.editAddr(name, smartPhone.inputAddrData());
			} else if(select.equals("6")) {
				System.out.print("프로그램이 종료되었습니다.");
				in.close();
				break;
			}			
		}		
	}
}
