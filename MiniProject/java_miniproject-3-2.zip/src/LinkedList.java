
public class LinkedList {
	
	private ListNode head;
	ListNode temp;

	public LinkedList() {
		head = null;
	}
	
	//메소드
	
	public void insertLastNode(String data) {
		if (head==null) {
			head = new ListNode(data);
		}
		else {
			temp = head;
			while (true) {
				if (temp.link==null) {
					ListNode newNode = new ListNode(data);
					temp.link = newNode;
					return;
				}
				temp = temp.link;
			}
		}
	}
	
	public void insertMiddleNode(ListNode pre, String data) {
		ListNode newNode = new ListNode(data, pre.link);
		pre.link = newNode;
	}
	
	
	public void printList() {
		temp = head;
		System.out.printf("L : ");
		while (true) {
			if(temp!=null) {
				System.out.print(temp.getData());
		        temp = temp.link;
		        if (temp!=null)
					System.out.print(", ");
		        else System.out.println();
			} else if (temp==null)
				return;
	}
	}
	
	public ListNode searchNode(String data) {
		temp = head;
		while (true) {
			if(temp.getData().equals(data)) {
				return temp;
			} else if (temp==null) {
				return null;
			} else
				temp = temp.link;
	}	
	}
	
	public void reverseList() {
		temp = null;
		
		while(true) {
			ListNode newNode = new ListNode(head.getData(),temp);
			temp = newNode;
			if (head.link==null) {
				head.link = newNode.link;
				break;
				} else head = head.link;
		}
	}
	
	public void deleteLastNode() {
		temp = head;
		while (true) {
			if (temp.link.link==null) {
				temp.link = null;
				return;
			}
			temp = temp.link;
		}
	}
}
