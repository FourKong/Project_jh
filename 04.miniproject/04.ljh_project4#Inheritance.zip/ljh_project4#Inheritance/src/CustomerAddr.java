
public class CustomerAddr extends Addr {

	private String customer;
	private String item;
	private String rank;
	
	CustomerAddr() {}
	CustomerAddr(Addr addr, String customer, String item, String rank) {
		setName(addr.getName());
		setNumber(addr.getNumber());
		setMail(addr.getMail());
		setHome(addr.getHome());
		setBirth(addr.getBirth());
		setGroup(addr.getGroup());
		this.customer = customer;
		this.item = item;
		this.rank = rank;
	}
	
	@Override
	void printInfo() {
		super.printInfo();
		System.out.printf("거래처이름 : %s\n거래품목 : %s\n직급 : %s\n",
					customer, item, rank);	
	}
	
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public String getRank() {
		return rank;
	}
	public void setRank(String rank) {
		this.rank = rank;
	}

}
