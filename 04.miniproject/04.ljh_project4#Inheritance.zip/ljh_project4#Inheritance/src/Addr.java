

public class Addr {
	
	//필드 생성
	private String name;
	private String number;
	private String mail;
	private String home;
	private String birth;
	private String group;


	//생성자 선언
	Addr() {}
	Addr(String name, String number, String mail, String home, String birth, String group) {
		this.name = name;
		this.number = number;
		this.mail = mail;
		this.home = home;
		this.birth = birth;
		this.group = group;
	}
	
	//메소드
	public String getName() {
		return name;
	}
	public String getNumber() {
		return number;
	}
	public String getMail() {
		return mail;
	}
	public String getHome() {
		return home;
	}
	public String getBirth() {
		return birth;
	}
	public String getGroup() {
		return group;
	}
	
	public void setName(String name) {
		this.name=name;
	}
	public void setNumber(String number) {
		this.number=number;
	}
	public void setMail(String mail) {
		this.mail=mail;
	}
	public void setHome(String home) {
		this.home=home;
	}
	public void setBirth(String birth) {
		this.birth=birth;
	}
	public void setGroup(String group) {
		this.group=group;
	}
	
	void printInfo() {
		System.out.printf("이름 : %s\n번호 : %s\n메일 : %s\n주소 : %s\n생일 : %s\n그룹 : %s\n",
					name, number, mail, home, birth, group);	
	}
	
	void changeInfo(String group) {
		System.out.println("-----------------");
		System.out.println("그룹 정보 변경");
		System.out.println("-----------------");
		this.group = group;
	}
	
	
	

}
