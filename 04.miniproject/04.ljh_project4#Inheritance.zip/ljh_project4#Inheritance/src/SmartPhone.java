
import java.util.Scanner;
public class SmartPhone {
	
	//필드
	Addr[] info = new Addr[10];
//	Addr addr = new Addr();
	int addressCount = 0;
	//Addr[] tempArray;
	Scanner in = new Scanner(System.in);
	
	//생성자
		
	//메소드
	Addr inputAddrData(String select) { // 检查完
		System.out.print("이름 : ");
		String name = in.nextLine();
		System.out.print("전화번호 : ");
		String phoneNumber = in.nextLine();
		System.out.print("이메일 : ");
		String email = in.nextLine();
		System.out.print("주소 : ");
		String address = in.nextLine();
		System.out.print("생일 : ");
		String birthday = in.nextLine();
		
		String group = null;
		if (select==null) {
			System.out.print("그룹 : ");
			group = in.nextLine();
		} else if (select.equals("1")) {
			System.out.println("그룹 : 회사");
			group = "회사";
		} else if (select.equals("2")) {
			System.out.println("그룹 : 거래처");
			group = "거래처";
		}
		
	    Addr addr = new Addr(name, phoneNumber, email, address, birthday, group);
		
	    if(group.contentEquals("회사")) {
			System.out.print("회사명 : ");
		    String company = in.nextLine();
		    System.out.print("부서 : ");
		    String depart = in.nextLine();
		    System.out.print("직급 : ");
		    String rank = in.nextLine();
		    return new CompanyAddr(addr, company, depart, rank);
	    } else if (group.contentEquals("거래처")) {
	    	System.out.print("회사명 : ");
	    	String customer = in.nextLine();
			System.out.print("품목이름 : ");
			String item = in.nextLine();
			System.out.print("직급 : ");
		    String rank = in.nextLine();
			return new CustomerAddr(addr, customer, item, rank);
	    }
	    return addr;
	}

	void addAddr(Addr Addr) { // 检查完
		if(addressCount<info.length) {
			info[addressCount]=Addr;
	        System.out.println(">> 데이터가 저장되었습니다. (" + (addressCount+1) + ")");
	        addressCount +=1;
		} else
			System.out.println("주소록이 가득 차서 등록할 수 없습니다.");	
		} // 주소록 추가 종료
	
	void printAddr(Addr Addr) { // 检查完
//		if (Addr instanceof CompanyAddr) {
//			CompanyAddr addr = (CompanyAddr) Addr; 
//		    addr.printInfo();
//		}
//		else if (Addr instanceof CustomerAddr) {
//			CustomerAddr addr = (CustomerAddr) Addr; 
//	        addr.printInfo();
//		} else {
		Addr.printInfo();
//		}
	} // 일반 출력

	void printAllAddr() { // 检查完
		for(int i=0; i<addressCount; i++) {
			System.out.println("----------(" + (i+1) + ")----------");
		    printAddr(info[i]);
		}
	} // 전체 출력 종료
	
	void searchAddr(String name) { // 检查完
		for(int i=0; i<addressCount; i++) {
			if(name.contentEquals(info[i].getName())) {
				printAddr(info[i]);
				break;
			} else if(i>=addressCount-1) {
				System.out.println("존재하지 않는 이름입니다.");
			}
		}	
	} // 검색 종료
	
	void deleteAddr(String name) { // 检查完
		for (int i=0; i<addressCount; i++) {
			if (name.contentEquals(info[i].getName())) {
				System.out.println(name + " 님의 정보가 삭제되었습니다.");
				addressCount-=1; // count 빼는 구간
				for(int j=addressCount; j>i; j--) {
					info[j-1] = info[j];
				}
				return;
			} else if(i==addressCount-1) {
				System.out.println("존재하지 않는 이름입니다.");
			}
		}	
	} // 삭제 종료
	
	void editAddr(String name, Addr newAddr) { // 检查完
		for(int i=0; i<addressCount;i++) {
			if(name.contentEquals(info[i].getName())) {
				info[i]=newAddr;
				System.out.println(">> 데이터가 수정되었습니다. (" + (i+1) + ")");
				return;
			} else if(i>=addressCount-1) {
				System.out.println("이름이 존재하지 않아 수정할 수 없습니다.");
			}
		}	
	} // 수정 종료
	
	void menu() {
		System.out.println("주소 관리 메뉴------------");
		System.out.println(">> 1. 연락처 등록(회사)");
		System.out.println(">> 2. 연락처 등록(거래처)");
		System.out.println(">> 3. 모든 연락처 출력");
		System.out.println(">> 4. 연락처 검색");
		System.out.println(">> 5. 연락처 삭제");
		System.out.println(">> 6. 연락처 수정");
		System.out.println(">> 7. 프로그램 종료");
		System.out.println("----------------------");
		}
	}
