import java.util.*;

public class SmartPhoneMain {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		SmartPhone smartPhone = new SmartPhone();

//		for(int i=0; i<2; i++) {
//			System.out.println("(" + (i+1) + ")-------------");
//			smartPhone.addAddr(smartPhone.inputAddr());
//		}
		
		while(true) {
			
			System.out.println("주소 관리 메뉴------------");
			System.out.println(">> 1. 연락처 등록");
			System.out.println(">> 2. 연락처 검색");
			System.out.println(">> 3. 연락처 삭제");
			System.out.println(">> 4. 연락처 수정");
			System.out.println(">> 5. 연락처 전체 리스트 보기");
			System.out.println(">> 6. 연락처 파일 저장");
			System.out.println(">> 7. 연락처 파일 불러오기");
			System.out.println(">> 8. 프로그램 종료");
			System.out.println("----------------------");
			String select = scan.nextLine();
			
			if(select.equals("1")) {
				smartPhone.addAddr(smartPhone.inputAddr());
			} else if (select.equals("2")) {
				System.out.println("검색할 이름을 입력해주세요.");
				String tempName = scan.nextLine();
				if (smartPhone.searchAddr(tempName)==-1)
					System.out.println("이름을 찾을 수 없습니다.");
				else smartPhone.printAddr(smartPhone.list.get(smartPhone.searchAddr(tempName)));
			} else if(select.equals("3")) {
				System.out.println("삭제할 이름을 입력해주세요.");
				String tempName = scan.nextLine();
				if (smartPhone.searchAddr(tempName)==-1)
					System.out.println("이름을 찾을 수 없습니다.");
				else smartPhone.removeAddr(tempName);
			} else if(select.equals("4")) {
				System.out.println("수정할 이름을 입력해주세요.");
				String tempName = scan.nextLine();
				if (smartPhone.searchAddr(tempName)==-1)
					System.out.println("이름을 찾을 수 없습니다.");
				else smartPhone.fixAddr(tempName);
			} else if (select.equals("5")) {
			    smartPhone.printAll();
			} else if (select.equals("6")) {
			    smartPhone.saveAddr();
			} else if (select.equals("7")) {
			    smartPhone.loadAddr();
			} else if(select.equals("8")) {
				System.out.print("프로그램이 종료되었습니다.");
				scan.close();
				break;
			}			
		}	
	}

}
