
import java.util.Scanner;
public class SmartPhone {
	
	//필드
	Addr[] info = new Addr[10];
	Addr method = new Addr();
	int addressCount = 0;
	//Addr[] tempArray;
	Scanner in = new Scanner(System.in);
	
	//생성자
		
	//메소드
	Addr inputAddrData() { // 检查完
		System.out.print("이름 : ");
		method.setName(in.nextLine());
		System.out.print("전화번호 : ");
		method.setNumber(in.nextLine());
		System.out.print("이메일 : ");
		method.setMail(in.nextLine());
		System.out.print("주소 : ");
		method.setHome(in.nextLine());
		System.out.print("그룹(가족/친구) : ");
		method.setGroup(in.nextLine());
	    return new Addr(method.getName(), method.getNumber(), method.getMail(), method.getHome(), method.getGroup());
	}	

	void addAddr(Addr Addr) { // 检查完
		if(addressCount<info.length) {
			info[addressCount]=Addr;
	        System.out.println(">> 데이터가 저장되었습니다. (" + (addressCount+1) + ")");
	        addressCount +=1;
		} else
			System.out.println("주소록이 가득 차서 등록할 수 없습니다.");	
		} // 주소록 추가 종료
	
	void printAddr(Addr Addr) { // 检查完
		System.out.printf("이름 : %s\n번호 : %s\n메일 : %s\n주소 : %s\n그룹 : %s\n",
				Addr.getName(), Addr.getNumber(), Addr.getMail(), Addr.getHome(), Addr.getGroup());
	} // 일반 출력

	void printAllAddr() { // 检查完
		for(int i=0; i<addressCount; i++) {
			System.out.println("----------(" + (i+1) + ")----------");
		    printAddr(info[i]);
		}
	} // 전체 출력 종료
	
	void searchAddr(String name) { // 检查完
		for(int i=0; i<addressCount; i++) {
			if(name.contentEquals(info[i].getName())) {
				printAddr(info[i]);
				break;
			} else if(i>=addressCount-1) {
				System.out.println("존재하지 않는 이름입니다.");
			}
		}	
	} // 검색 종료
	
/*	void deleteAddr(String name) { // 检查完
		for (int i=0; i<addressCount; i++) {
			if (name.contentEquals(info[i].getName())) {
				System.out.println(name + " 님의 정보가 삭제되었습니다.");
				tempArray = info;
				for(int j=0; j<i; j++) {
					info[j] = tempArray[j];
				}
				addressCount-=1; // count 빼는 구간
				for(int j=addressCount; j>i; j--) {
					info[j-1] = tempArray[j];
				}
				break;
			} else if(i==addressCount-1) {
				System.out.println("존재하지 않는 이름입니다.");
			}
		}	
	} // 삭제 종료*/
	
	void deleteAddr(String name) { // 检查完
		for (int i=0; i<addressCount; i++) {
			if (name.contentEquals(info[i].getName())) {
				System.out.println(name + " 님의 정보가 삭제되었습니다.");
				addressCount-=1; // count 빼는 구간
				for(int j=addressCount; j>i; j--) {
					info[j-1] = info[j];
				}
				break;
			} else if(i==addressCount-1) {
				System.out.println("존재하지 않는 이름입니다.");
			}
		}	
	} // 삭제 종료
	
	void editAddr(String name, Addr newAddr) { // 检查完
		for(int i=0; i<addressCount;i++) {
			if(name.contentEquals(info[i].getName())) {
				info[i]=newAddr;
				System.out.println(">> 데이터가 수정되었습니다. (" + (i+1) + ")");
				break;
			} else if(i>=addressCount-1) {
				System.out.println("이름이 존재하지 않아 수정할 수 없습니다.");
			}
		}	
	} // 수정 종료
	
	void menu() {
		System.out.println("주소 관리 메뉴------------");
		System.out.println(">> 1. 연락처 등록");
		System.out.println(">> 2. 모든 연락처 출력");
		System.out.println(">> 3. 연락처 검색");
		System.out.println(">> 4. 연락처 삭제");
		System.out.println(">> 5. 연락처 수정");
		System.out.println(">> 6. 프로그램 종료");
		System.out.println("----------------------");
		}
	}
