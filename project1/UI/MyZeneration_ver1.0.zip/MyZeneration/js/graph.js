// const graphsName = new Array("workTotal", "spareTime", "lifeTotal", "wage", "fullTime", "workingHour", "firmSize", "marriage");

const sat_order = new Array("workTotal", "spareTime", "lifeTotal"); // 템플릿 리터럴에 사용할 배열.

const aboutWork = new Array("wage", "workingHour"); // 템플릿 리터럴에 사용할 배열.
const aboutWork_kor = new Array("월급여 (단위:만원)", " 주 근로 시간 (단위:시간)");

const lifeStable = new Array("fullTime", "marriage"); // 템플릿 리터럴에 사용할 배열.
const lifeStable_kor = [["정규직", "비정규직"], ["미혼", "결혼-유배우자", "결혼-무배우자"]];

// function resizing() {
//   var widths;
//   if(document.body.offsetWidth <=1200){
//     widths = 280;
//   } else widths = 180;
//   var graphs = document.querySelectorAll(".graphTotal");
//   for(let i=0; i<graphsName.length; i++){
//     graphs[i].innerHTML =  `<p class="rounded-condition">"단수 선택 조건"</p> <canvas id="${graphsName[i]}Chart" alt="복수 선택 조건 그래프" class="graph" height="${widths}">`
//   }
//   makeGraph();
// }
// window.onload = resizing();
// window.onresize = resizing();

// 그래프 만드는 함수
function makeGraph() {
  // !important! ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
  // check 요소 확인하는 임시 설정!! 추후 제대로 변경할 것!!
  // sex = 1 age = 2 edu = 3 region = 4 marriage = 5
  // firmSize = 6 firmType = 7 정규직/비정규직 여부 = 8

  // 카테고리 배열 생성 (size:2)
  // 이후 .checked로 체크 요소 확인(class별)하여 ${각 배열}에 넣고, True 존재시 category 배열에 넣기
  // categooy ==2인 경우 -> true >=2 인 category가 mainCategory, 나머진 subCategory
  // category ==1인 경우 => 그 하나뿐인 카테고리가 main
  // sortedData에 .filter(function(d) {return d.xxx='1'}) 식으로 분류 가능
  // 은 하나 생각해보니, 이건 DB 연동 후 SQL문으로 긁어오면 되는 거였음 ㅡㅡ

  // 아래도 DB 연동으로 해결하면 될 듯? 아님 말고

  if (false) {
    var category = 1;
  } else if (false) {
    var category = 2;
  } else if (false) {
    var category = 3;
  } else if (true) {
    var category = 4;
  } else if (false) {
    var category = 5;
  } else if (true) {
    var category = 6;
  } else if (false) {
    var category = 7;
  } else if (false) {
    var category = 8;
  }

  // 각 요소 별 세부 체크 요소도 확인할 것.
  // 세부 체크 요소가 2개 이상인 카테고리를 main으로,
  // 하나인 카테고리를 sub로.
  // 아래 OOO if문에 넣어주어야 함.

  // !important! ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲

  // !important! ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼

  d3.csv("./treatedData_total_last.csv") // CSV 파일 로드. 추후 DB에서 끌어오기로 변경 요망!!
    .then(function (data) {
      var sortedData = data.filter(function (d) { // 특정 데이터만 분류
        return (d.age == '3') && (d.region == '1' || d.region == '2' || d.region == '3'); // 분류 조건 설정!!
      });
      sortedData.sort(function (a, b) { // 이후 오름차순 정렬 必
        return a.region - b.region; // 정렬 설정 건드리기 必!! 勿忘
      });
      if (category == 2) { // if문 따라 요소 별 그룹화. 추후 수정!! 아마 SQL문 사용할 것으로 추정.
        var sortData = d3.group(sortedData, d => d.age);
      } else if (category == 3) {
        var sortData = d3.group(sortedData, d => d.edu);
      } else if (category == 4) {
        var sortData = d3.group(sortedData, d => d.region);
      } else if (category == 5) {
        var sortData = d3.group(dsortedData, d => d.marriage);
      }

      // !important! ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲

      // !important! ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼

      // 카테고리 변경(라벨 생성)하는 if문. 마찬가지로 추후 수정.
      // 하단에서 for문 + push문을 통해 라벨에 직접 입력.
      // sex = 1 age = 2 edu = 3 region = 4 marriage = 5
      // firmSize = 6 firmType = 7 정규직/비정규직 여부 = 8
      // 템플릿 리터럴 사용해서 체크된 값과 같은 값만 뽑아서 넣기.
      // 뭐 아무튼 어떻게 건드려야 함.
      // x축 최소 갯수 몇 개로 할지는 상의.
      if (category == 2) {
        var sortLabels = ['20대 초', '20대 중', '20대 후', '30대 초', '30대 중', '30대 후']; // 데이터 입력.
      } else if (category == 3) {
        var sortLabels = ['중졸 이하', '고졸', '대학재학/중퇴', '전문대졸', '대졸이상']; // 데이터 입력.
      } else if (category == 4) {
        var sortLabels = ['수도권', '강원', '충청', '호남', '영남', '제주']; // 데이터 입력.
      } else if (category == 5) {
        var sortLabels = [''];
      }

      // !important! ▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲

      // ★★★★★만족도 그래프 코드 시작!★★★★★



      for (let i = 0; i < sat_order.length; i++) { // 세 개 생성.
        var chartData = {
          labels: [], // x축 레이블. 아래서 push를 통해 받을 것.
          datasets: [{ // 데이터 외형 설정
            label: `매우 불만족`, // 그래프 이름
            data: [3,5,8], // 아래의 push를 통해 데이터 받음.
            backgroundColor: 'rgba(255, 99, 132, 0.2)', // 막대 바 색상. 각기 다르게 설정하려면 배열로 만들 것.
            borderColor: 'rgba(255, 99, 132, 1)', // 막대 테두리 색상.
            borderWidth: 1 // 테두리 두께
          },
          { // 데이터 외형 설정
            label: `불만족`, // 그래프 이름
            data: [6], // 아래의 push를 통해 데이터 받음.
            backgroundColor: 'rgba(255, 159, 64, 0.2)',
            borderColor: 'rgba(255, 159, 64, 1)',
            borderWidth: 1 // 테두리 두께
          },
          { // 데이터 외형 설정
            label: `보통`, // 그래프 이름
            data: [9], // 아래의 push를 통해 데이터 받음.
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1 // 테두리 두께
          },
          { // 데이터 외형 설정
            label: `만족`, // 그래프 이름
            data: [12], // 아래의 push를 통해 데이터 받음.
            backgroundColor: 'rgba(54, 162, 235, 0.2)', // 막대바 색상  
            borderColor: 'rgba(54, 162, 235, 1)', // 막대 테두리 색상              
            borderWidth: 1 // 테두리 두께
          },
          { // 데이터 외형 설정
            label: `매우 만족`, // 그래프 이름
            data: [15], // 아래의 push를 통해 데이터 받음.
            backgroundColor: 'rgba(153, 102, 255, 0.2)',
            borderColor: 'rgba(153, 102, 255, 1)',
            borderWidth: 1 // 테두리 두께
          }]
        };

        var ctx = document.querySelector(`#${sat_order[i]}Chart`).getContext('2d');

        for (let a = 0; a < sortLabels.length; a++) {
          chartData.labels.push(sortLabels[a]); // 만들어놓은 라벨 추가.
        }

        // 그래프 생성
        new Chart(ctx, { 
          type: 'bar',
          data: chartData,
          options: {
            responsive: true, // 반응형 해제
            legend: {
              display: true, // 범례 표시 ON. 반응형으로 일정 크기 이하에서 false 할 것.
              position: `top`, // 범례 우측에 배치
              reverse: true, // 역순
              labels: {
                boxWidth: 15 // 범례박스 크기
              }
            },
            scales: { // x, y축 관련 설정
              xAxes: [{
                // stacked: true, // 누적
              }],
              yAxes: [{
                // stacked: true, // 누적
                afterTickToLabelConversion : function(q){
                  for(var tick in q.ticks){
                      q.ticks[tick] += '%';
                  }
              },
                ticks: {
                  max: 100 // y축 최대값
                }
              }]
            }
          }
        });
      } // Sat_for문 종료.

      // 만족도 그래프 코드 끝!

      // ★★★★★노동 관련 그래프 코드 시작!★★★★★

      for (let i = 0; i < aboutWork.length; i++) { // work 그래프 두 개 생성.
        var chartData = {
          labels: [], // x축 레이블. 아래서 push를 통해 받을 것.
          datasets: [{ // 데이터 외형 설정
            label: `평균 ${aboutWork_kor[i]}`, // 그래프 이름
            data: [], // 아래의 push를 통해 데이터 받음.
            backgroundColor: [ // 막대바 색상       
              'rgba(255, 99, 132, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(255, 206, 86, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(153, 102, 255, 0.2)',
              'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [ // 막대 테두리 색상              
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(153, 102, 255, 1)',
              'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1 // 테두리 두께
          }]
        };

        var ctx = document.querySelector(`#${aboutWork[i]}Chart`).getContext('2d');

        sortData.forEach(function (values) {
          var total = 0;
          values.forEach(function (d) {
            if (i == 0) { // 여기만은 템플릿 리터럴로 처리할 수 없어 if문 처리.
              total += +d.wage;
            } else if (i == 1) {
              total += +d.workingHour;
            }
          });
          var average = total / values.length;
          chartData.datasets[0].data.push(Math.round(average * 100) / 100); // 그래프의 y축
        });

        for (let a = 0; a < sortLabels.length; a++) {
          chartData.labels.push(sortLabels[a]); // 만들어놓은 라벨 추가.
        }

        // 그래프 생성
        new Chart(ctx, { 
          type: 'bar',
          data: chartData,
          options: {
            responsive: true, // 반응형 해제
            legend: {
              display: true, // 범례 표시 ON. 반응형으로 일정 크기 이하에서 OFF 할 것.
              position: `chartArea`, // 범례 상단에 배치
              labels: {
                boxWidth: 0 // 범례박스 크기
              }
            },
            scales: { // x, y축 관련 설정
              yAxes: [{
                afterDataLimits(scale) {
                  scale.max += scale.max * 0.025; // 최대치는 그래프 최대값의 1.025배
                }
              }]
            }
          }
        });
      } // work_for문 종료

      // 노동 관련 그래프 코드 끝!

      // ★★★★★삶 안정도 관련 그래프 코드 시작!★★★★★

      for (let i = 0; i < lifeStable.length; i++) { // 세 개 생성.
        var chartData = {
          labels: [], // x축 레이블. 아래서 push를 통해 받을 것.
          datasets: [{ // 데이터 외형 설정
            label: `${lifeStable_kor[i][0]}`, // 그래프 이름
            data: [], // 아래의 push를 통해 데이터 받음.
            backgroundColor: 'rgba(255, 99, 132, 0.2)', // 막대 바 색상. 각기 다르게 설정하려면 배열로 만들 것.
            borderColor: 'rgba(255, 99, 132, 1)', // 막대 테두리 색상.
            borderWidth: 1 // 테두리 두께
          },
          { // 데이터 외형 설정
            label: `${lifeStable_kor[i][1]}`, // 그래프 이름
            data: [], // 아래의 push를 통해 데이터 받음.
            backgroundColor: 'rgba(255, 159, 64, 0.2)',
            borderColor: 'rgba(255, 159, 64, 1)',
            borderWidth: 1 // 테두리 두께
          },
          { // 데이터 외형 설정
            label: `${lifeStable_kor[i][2]}`, // 그래프 이름
            data: [], // 아래의 push를 통해 데이터 받음.
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1 // 테두리 두께
          }]
        };

        var ctx = document.querySelector(`#${lifeStable[i]}Chart`).getContext('2d');

        sortData.forEach(function (values) {
          let count = new Array(0, 0, 0);
          values.forEach(function (d) {
            if (i == 0) { // 여기만은 템플릿 리터럴로 처리할 수 없어 if문 처리.
              for (let b = 0; b < count.length; b++) {
                if (d.fullTime == b + 1) {
                  count[b]++
                }
              }
            } else if (i == 1) {
              for (let b = 0; b < count.length; b++) {
                if (d.marriage == b + 1) {
                  count[b]++
                }
              }
            }
          });
          let sum = 0;
          for (let b = 0; b < count.length; b++) {
            sum += count[b];
          }
          for (let b = 0; b < count.length; b++) {
            chartData.datasets[b].data.push(Math.round(count[b] / sum * 10000) / 100); // 데이터 입력.
          }
        });

        if (i == 0) { // 고용 형태 차트바 하나 제거.
          chartData.datasets.pop();
        }

        for (let a = 0; a < sortLabels.length; a++) {
          chartData.labels.push(sortLabels[a]); // 만들어놓은 라벨 추가.
        }

        // 그래프 생성
        new Chart(ctx, { 
          type: 'bar',
          data: chartData,
          options: {
            responsive: true, // 반응형 해제
            legend: {
              display: true, // 범례 표시 ON. 반응형으로 일정 크기 이하에서 false 할 것.
              position: `top`, // 범례 우측에 배치
              labels: {
                boxWidth: 15 // 범례박스 크기
              }
            },
            scales: {
              yAxes: [{
                afterTickToLabelConversion : function(q){
                  for(var tick in q.ticks){
                      q.ticks[tick] += '%';
                  }
              },
              }] // x, y축 관련 설정
            }
          }
        });
      } // Sable_for문 종료.

      // 삶 안정도 관련 그래프 코드 끝!

      // ★★★★★기업 규모 관련 그래프 코드 시작!★★★★★
      // 단일 그래프이므로 for문 X. for문 사용 위해 필요했던 템플릿 리터럴용 배열 X.

      var chartData = {
        labels: [], // x축 레이블. 아래서 push를 통해 받을 것.
        datasets: [{ // 데이터 외형 설정
          label: `10명 미만`, // 그래프 이름
          data: [], // 아래의 push를 통해 데이터 받음.
          backgroundColor: 'rgba(255, 99, 132, 0.2)', // 막대 바 색상. 각기 다르게 설정하려면 배열로 만들 것.
          borderColor: 'rgba(255, 99, 132, 1)', // 막대 테두리 색상.
          borderWidth: 1 // 테두리 두께
        },
        { // 데이터 외형 설정
          label: `10명~29명`, // 그래프 이름
          data: [], // 아래의 push를 통해 데이터 받음.
          backgroundColor: 'rgba(255, 159, 64, 0.2)',
          borderColor: 'rgba(255, 159, 64, 1)',
          borderWidth: 1 // 테두리 두께
        },
        { // 데이터 외형 설정
          label: `30명~99명`, // 그래프 이름
          data: [], // 아래의 push를 통해 데이터 받음.
          backgroundColor: 'rgba(255, 206, 16, 0.2)',
          borderColor: 'rgba(255, 206, 16, 1)',
          borderWidth: 1 // 테두리 두께
        },
        { // 데이터 외형 설정
          label: `100명~299명`, // 그래프 이름
          data: [], // 아래의 push를 통해 데이터 받음.
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1 // 테두리 두께
        },
        { // 데이터 외형 설정
          label: `300명~499명`, // 그래프 이름
          data: [], // 아래의 push를 통해 데이터 받음.
          backgroundColor: 'rgba(54, 162, 235, 0.2)', // 막대바 색상  
          borderColor: 'rgba(54, 162, 235, 1)', // 막대 테두리 색상   
          borderWidth: 1 // 테두리 두께
        },
        { // 데이터 외형 설정
          label: `500명 이상`, // 그래프 이름
          data: [], // 아래의 push를 통해 데이터 받음.
          backgroundColor: 'rgba(153, 102, 255, 0.2)',
          borderColor: 'rgba(153, 102, 255, 1)',
          borderWidth: 1 // 테두리 두께
        }]
      };

      var ctx = document.querySelector(`#firmSizeChart`).getContext('2d');

      sortData.forEach(function (values) {
        let count = new Array(0, 0, 0, 0, 0, 0);
        values.forEach(function (d) {
          for (let b = 0; b < count.length; b++) {
            if (d.firmSize == b + 1) {
              count[b]++
            }
          }
        });
        let sum = 0;
        for (let b = 0; b < count.length; b++) {
          sum += count[b];
        }
        for (let b = 0; b < count.length; b++) {
          chartData.datasets[b].data.push(Math.round(count[b] / sum * 10000) / 100); // 데이터 입력.
        }
      });

      for (let a = 0; a < sortLabels.length; a++) {
        chartData.labels.push(sortLabels[a]); // 만들어놓은 라벨 추가.
      }

      // 그래프 생성
      new Chart(ctx, { 
        type: 'bar',
        data: chartData,
        options: {
          responsive: true, // 반응형
          legend: {
            display: true, // 범례 표시 ON. 반응형으로 일정 크기 이하에서 false 할 것.
            position: `top`, // 범례 우측에 배치
            labels: {
              boxWidth: 10, // 범례박스 크기
              fontSize: 10
            }
          },
          scales: { // x, y축 관련 설정
            xAxes: [{
              stacked: true, // 누적
            }],
            yAxes: [{
              stacked: true, // 누적
              afterTickToLabelConversion : function(q){
                for(var tick in q.ticks){
                    q.ticks[tick] += '%';
                }
            },
              ticks: {
                max: 100 // y축 최대값
              }
            }]
          }
        }
      });

      // 기업 규모 관련 그래프 코드 끝!

    })
    .catch(function (error) {
      // 파일 로드 오류 처리
      console.log("파일 로드 오류:", error);
    });
}

makeGraph();