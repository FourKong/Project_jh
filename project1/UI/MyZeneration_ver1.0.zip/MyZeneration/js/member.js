window.onresize = function () {
    if (document.body.offsetWidth <= 500) {
        let width = document.querySelector(".site-width");
        width.classList.remove(`col-xs-offset-2`);
        width.classList.remove(`col-xs-8`);
        width.classList.add(`col-xs-12`);
    } else if (document.body.offsetWidth > 500) {
        let width = document.querySelector(".site-width");
        width.classList.remove(`col-xs-12`);
        width.classList.add(`col-xs-offset-2`);
        width.classList.add(`col-xs-8`);
    }
}
window.onload = function () {
    if (document.body.offsetWidth <= 500) {
        let width = document.querySelector(".site-width");
        width.classList.remove(`col-xs-offset-2`);
        width.classList.remove(`col-xs-8`);
        width.classList.add(`col-xs-12`);
    }
}