function makePage(req, info, coef, name) {
	const which = new Array("me", "other");
	const sat_type = new Array("전체", "생활수준", "건강", "대인관계")
	const sat_me = new Array("all", "living", "health", "human"); // 템플릿 리터럴에 사용할 배열.
	const sat_color = new Array('rgba(60,179,113,0.8)', 'rgba(0,191,255, 0.8)', 'rgba(250,128,114,0.8)');
	for(let i = 0; i <2; i++) {
	  for (let j = 0; j < sat_me.length; j++) {
  
	  // 도넛 그래프 생성
	  var ctx = document.querySelector(`#sat_${sat_me[j]}_${which[i]}`).getContext('2d');
	  
	  let color;
	  if (i==0) {
		  if (req[i][j] == req[i+1][j]) {
			  color = sat_color[0];
		  } else if (req[i][j] > req[i+1][j]) {
			  color = sat_color[1];
		  } else if (req[i][j] < req[i+1][j]) {
			  color = sat_color[2];
		  }
	  } else color = 'rgba(128,128,128,0.8)';
	  let score = req[i][j];
  
  let titleSize =$(`#sat_${sat_me[j]}_${which[i]}`).width()*0.087;
  
	  // 그래프 생성
	  var myChart = new Chart(ctx, { // 그래프 생성용 변수라 원래 안 쓰이는 게 맞음.
		type: 'doughnut',
		  data: {
			labels: [], // x축 레이블
			datasets: [{ // 데이터 외형 설정
			  data: [score, 10-score], // 아래의 push를 통해 데이터 받음.
			  backgroundColor: [ // 막대바 색상       
			  color,
			  'rgb(255,255,255)'
			  ],
			  borderColor: [ // 막대 테두리 색상              
			  color,
			  color
			  ],
			  borderWidth: 2 // 테두리 두께
			}]
		  },
		  options: {
			tooltips: {enabled: false},
			hover: {mode: null},
			elements: {
			  center: {
				text: `${score}점`,
				title: `${sat_type[j]} 만족도`,
				titleSize: titleSize,
				color: color, // Default is #000000
				fontStyle: 'GmarketSansMedium', // Default is Arial
				sidePadding: 20, // Default is 20 (as a percentage)
				minFontSize: 10, // Default is 20 (in px), set to false and text will not wrap.
				lineHeight: 25 // Default is 25 (in px), used for when text wraps
			  },
			},
			responsive: false,
			cutoutPercentage: 90, // 중앙 구멍 크기
			legend: {
			  display: false
			},
			layout: {
			  padding: 0
			}
		  }
		});
	  }
	}
	// --------- 이하 나의 정보 관련 ----------
	let sex = info[0];let age = info[1];let about_marriage = info[2];let marriage = info[3];
	let car = info[4];let house = info[5];let parents = info[6];let live_alone = info[7];
	let house_form = info[8];let house_rental = info[9];let health = info[10];let body = info[11];
	let exercise = info[12];let work_life = info[13];let real_dream = info[14];let result_procedure = info[15];
	let individual_group = info[16];let me_other = info[17];let for_happinese = info[16];let edu = info[17];
  
	let age_info = document.querySelectorAll(".my_age")
	let sex_info = document.querySelectorAll(".my_sex")
	let edu_info = document.querySelectorAll(".my_edu")
	let marriage_info = document.querySelectorAll(".my_marriage")
	let house_info = document.querySelectorAll(".my_house")
	let car_info = document.querySelectorAll(".my_car")
	if(age==1) {
		  for(let i =0; i<2; i++) {age_info[i].innerHTML="10대 후반";}
	} else if(age==2) {
	   for(let i =0; i<2; i++) {age_info[i].innerHTML="20대 초반";}
	} else if(age==3) {
	   for(let i =0; i<2; i++) {age_info[i].innerHTML="20대 후반";}
	} else if(age==4) {
	   for(let i =0; i<2; i++) {age_info[i].innerHTML="30대 초반";}
	}
	if(sex==1) {
	   for(let i =0; i<2; i++) {sex_info[i].innerHTML = "남성";}
	} else if(sex==2) {
	   for(let i =0; i<2; i++) {sex_info[i].innerHTML = "여성";}
	}
	if(edu==1) {
	   for(let i =0; i<2; i++) {edu_info[i].innerHTML = "중졸 이하";}
	} else if(edu==2) {
	   for(let i =0; i<2; i++) {edu_info[i].innerHTML = "고졸";}
	} else if(edu==3) {
	   for(let i =0; i<2; i++) {edu_info[i].innerHTML = "전문대졸";}
	} else if(edu==4) {
	   for(let i =0; i<2; i++) {edu_info[i].innerHTML = "4년제졸";}
	} else if(edu==5) {
	   for(let i =0; i<2; i++) {edu_info[i].innerHTML = "석·박사";}
	}
	if(marriage==1) {
	   for(let i =0; i<2; i++) {marriage_info[i].innerHTML = "기혼";}
	} else if(marriage==2) {
	   for(let i =0; i<2; i++) {marriage_info[i].innerHTML = "미혼";}
	}
	if(car==1) {
	   for(let i =0; i<2; i++) {car_info[i].innerHTML = "보유";}
	} else if(car==2) {
	   for(let i =0; i<2; i++) {car_info[i].innerHTML = "미보유";}
	}
	if(house==1) {
	   for(let i =0; i<2; i++) {house_info[i].innerHTML = "보유";}
	} else if(house==2) {
	   for(let i =0; i<2; i++) {house_info[i].innerHTML = "미보유";}
	}
	let life_value = [work_life, real_dream,result_procedure, individual_group, me_other];
	for(let i = 0; i<life_value.length; i++) {
		var value_a = document.querySelectorAll(`.v-${i+1}-a`);
		var value_b = document.querySelectorAll(`.v-${i+1}-b`);
		if(life_value[i]==4) {
			for(let j=0; j<2; j++) {
				value_a[j].style.color='green';
				value_a[j].style.fontSize='115%';
			  value_a[j].style.fontWeight='bold';
				value_b[j].style.color='green';
				value_b[j].style.fontSize='115%';
			  value_b[j].style.fontWeight='bold';
			}
		}else if(life_value[i]>4) {
			for(let j=0; j<2; j++) {
				value_a[j].style.color='gray';
				value_a[j].style.fontSize='85%';
				value_b[j].style.color='darkblue';
				value_b[j].style.fontSize='115%';
			  value_b[j].style.fontWeight='bold';
			}
		}else if(life_value[i]<4) { 
			for(let j=0; j<2; j++) {
				value_b[j].style.color='gray';
				value_b[j].style.fontSize='85%';
				value_a[j].style.color='darkblue';
				value_a[j].style.fontSize='115%';
			  value_a[j].style.fontWeight='bold';
			}
		}
	}
	// --------- 이하 추천 사항 관련 ----------
	for(let i=0; i<coef.length; i++){
		const coef_set = []
		for (const key in coef[i]) {
			const value = coef[i][key];
			if (Math.abs(value)>0.25) {
				coef_set.push({ [key]: value });
			}
		}
		coef_set.sort(compareValuesDescending);
		console.log(coef_set)
		for(let j=0; j<3; j++) { // 상위 세 개만 표시.
		}
	}
	const text_box = document.querySelectorAll(".rmd-updown");
	`${name}님의 전체 만족도는 `
	//about_marriage, marriage, car, house, parents, live_alone, house_form, house_rental,
  // health, body, exercise, work_life, real_dream, result_procedure, individual_group, me_other, for_happinese, edu
  } // --------------------------- makePage 종료.
  
  function compareValuesDescending(a, b) {
		return Math.abs(b[Object.keys(b)[0]]) - Math.abs(a[Object.keys(a)[0]]);
	  }
  
  $(window).on('load resize',function(){
		let leng = $(window).width()+17;
		if(leng>1200) {
			var graph = document.querySelectorAll('.graph-mini');
			graph.forEach(mini => {
				mini.style.width = '27.33333333%';
				mini.style.margin = '3%';
			});
			var graphs = document.querySelectorAll('.graph');
			graphs.forEach(mini => {
				mini.style.width = '37%';
				mini.style.margin = '0 auto';
			});
	  } else if(leng<=1200) {
		var graph = document.querySelectorAll('.graph-mini');
			graph.forEach(mini => {
				mini.style.width = '60%';
				mini.style.margin = '15px 20% 0 20%';
			});
			var graphs = document.querySelectorAll('.graph');
			graphs.forEach(mini => {
				mini.style.width = '60%';
				mini.style.margin = '15px 20% 0 20%';
			});
	  } 
	  });
  
  
  
  Chart.plugins.register({
	beforeDraw: function (chart) {
		if (chart.config.options.elements.center) {
			//Get ctx from string
			var ctx = chart.chart.ctx;
  
			//Get options from the center object in options
			var centerConfig = chart.config.options.elements.center;
			var fontSize = centerConfig.fontSize || '50';
			var fontStyle = centerConfig.fontStyle || 'Arial';
			var txt = centerConfig.text;
		  var title = centerConfig.title;
			var color = centerConfig.color || '#000';
			var sidePadding = centerConfig.sidePadding || 20;
			var sidePaddingCalculated = (sidePadding/100) * (chart.innerRadius * 2)
			//Start with a base font of 30px
			ctx.font = fontSize + "px " + fontStyle;
  
			//Get the width of the string and also the width of the element minus 10 to give it 5px side padding
			var stringWidth = ctx.measureText(txt).width;
			var elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;
  
			// Find out how much the font can grow in width.
			var widthRatio = elementWidth / stringWidth;
			var newFontSize = Math.floor(30 * widthRatio);
			var elementHeight = (chart.innerRadius * 0.7);
  
			// Pick a new font size so it will not be larger than the height of label.
			var fontSizeToUse = Math.min(newFontSize, elementHeight);
  
			//Set font settings to draw it correctly.
			ctx.textAlign = 'center';
			ctx.textBaseline = 'middle';
			var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
			var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
  
			ctx.font = fontSizeToUse+"px " + fontStyle;
			ctx.fillStyle = color;
  
			//Draw text in center
			ctx.fillText(txt, centerX, centerY*(1.23));
		  fontSize = centerConfig.titleSize*1.2;
		  fontStyle = 'GmarketSansMedium';
		  ctx.font = fontSize + "px " + fontStyle;
		  ctx.fillText(title, centerX, centerY*(0.75));
		  }
	}
  });