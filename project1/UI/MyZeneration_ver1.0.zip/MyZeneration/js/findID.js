var posts = [
    {pk: 1, uid:"Dreamcatcher", uname:"지유", umail:"abc@naver.com"},
    {pk: 2, uid:"ChaseMe", uname:"유현", umail:"def@gmail.com"},
    {pk: 3, uid:"Lullaby", uname:"한동", umail:"xyz@daum.net"},
    {pk: 4, uid:"Dejavu", uname:"입력받은정보", umail:"입력받은정보"},
    {pk: 5, uid:"Payphone", uname:"가현", umail:"wave@microsoft.com"}]

window.onload = function() {
    for(let i=0; i<posts.length; i++) {
        if("입력받은정보"==posts[i].uname && "입력받은정보"==posts[i].umail){
            console.log(1)
            // querySelector로 posts[i].uid 올려주기
            document.querySelector(".findBox").innerHTML = `ID  &nbsp; &nbsp; | &nbsp; &nbsp; ${posts[i].uid}`;
        }
    }
}