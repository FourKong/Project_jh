
public class LinkedList {
	
	private ListNode head;

	public LinkedList() {
		head = null;
	}
	
	//메소드
	
	public void insertMiddleNode(ListNode pre, String data) {
		ListNode newNode = new ListNode(data, pre.link);
		pre.link = newNode;
	} // O
	
	public void insertLastNode(String data) {
		ListNode newNode = new ListNode(data);
		if (head==null) {
			head = newNode;
		}
		else {
			ListNode temp = head;
//			while (true) {
//				if (temp.link==null) {
//					ListNode newNode = new ListNode(data);
//					temp.link = newNode;
//					return;
//				} else temp.link = newNode;
			while (temp.link!=null)
				temp = temp.link;
			temp.link = newNode;
		}
	} // O
	
	public void deleteLastNode() {
		ListNode temp = head;
//		while (true) {
//			if (temp.link.link==null) {
//				temp.link = null;
//				return;
//			}
//			temp = temp.link;
//		}
		if (temp == null)
			return;
		if (temp.link == null) {
			head = null;
			return;
		} else {
			while (temp.link.link!=null)
				temp = temp.link;
			temp.link = null;
		}
	}
	
	public ListNode searchNode(String data) {
		ListNode temp = head;
		while (true) {
			if(temp.getData() == data) {
				return temp;
			} else
				temp = temp.link;
	}	
	}
	
	public void reverseList() {
		ListNode temp = null;
		while(true) {
			ListNode newNode = new ListNode(head.getData(),temp);
			temp = newNode;
			if (head.link==null) {
				head.link = newNode.link;
				break;
				} else head = head.link;
		}
	}
	
	public void printList() {
		ListNode temp = head;
		System.out.printf("L : ");
		while (temp!=null) {
				System.out.print(temp.getData());
		        temp = temp.link;
		        if (temp!=null)
					System.out.print(", ");
		}
		System.out.println();
	}
}
