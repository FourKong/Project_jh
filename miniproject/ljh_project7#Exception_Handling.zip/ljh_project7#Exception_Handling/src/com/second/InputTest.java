package com.second;
import java.util.*;

public class InputTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner in = new Scanner(System.in);
		
		System.out.println("이름을 입력하세요.");
		
		try {
			method(in.nextLine());
		} catch (InputException e) {
			System.out.println(e.getMessage());
		}	
		
		in.close();
	}
	
	public static void method(String id) throws InputException {
		if (id == null|id.equals(""))
		throw new InputException("잘못된 이름을 입력하셨습니다.");
		else System.out.println(id);
	}
}