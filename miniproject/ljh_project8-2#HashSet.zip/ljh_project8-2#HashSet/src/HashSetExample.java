import java.util.*;

public class HashSetExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		HashSetAddr hashSet = new HashSetAddr();
		
		for(int i=0; i<2; i++) {
			System.out.println("(" + (i+1) + ")-------------");
			boolean j = hashSet.addAddr(hashSet.inputAddr());
			if(j)
				System.out.println("저장 완료.");
		}
		
		while(true) {
			
			System.out.println("주소 관리 메뉴------------");
			System.out.println(">> 1. 연락처 등록");
			System.out.println(">> 2. 모든 연락처 출력");
			System.out.println(">> 3. 연락처 검색");
			System.out.println(">> 4. 연락처 삭제");
			System.out.println(">> 5. 연락처 수정");
			System.out.println(">> 6. 프로그램 종료");
			System.out.println("----------------------");
			String select = scan.nextLine();
			
			if(select.equals("1")) {
				hashSet.addAddr(hashSet.inputAddr());
			} else if (select.equals("2")) {
			    hashSet.printAll();
			} else if (select.equals("3")) {
				System.out.println("검색할 이름을 입력해주세요.");
				String tempName = scan.nextLine();
				if (hashSet.searchAddr(tempName)==null)
					System.out.println("이름을 찾을 수 없습니다.");
				else hashSet.printAddr(hashSet.searchAddr(tempName));
			} else if(select.equals("4")) {
				System.out.println("삭제할 이름을 입력해주세요.");
				String tempName = scan.nextLine();
				if (hashSet.searchAddr(tempName)==null)
					System.out.println("이름을 찾을 수 없습니다.");
				else hashSet.removeAddr(tempName);
			} else if(select.equals("5")) {
				System.out.println("수정할 이름을 입력해주세요.");
				String tempName = scan.nextLine();
				if (hashSet.searchAddr(tempName)==null)
					System.out.println("이름을 찾을 수 없습니다.");
				else hashSet.fixAddr(tempName);
			} else if(select.equals("6")) {
				System.out.print("프로그램이 종료되었습니다.");
				scan.close();
				break;
			}			
		}	
	}

}
