package com.first;
import java.util.*;

public class NumberTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner in = new Scanner(System.in);
		
		System.out.println("출생년도를 입력하세요.");
		
		try {
			method(in.nextLine());
		} catch (InputException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}	
		
		in.close();
	}
	
	public static void method(String yearOfBirth) throws InputException {
		try {
			Integer.parseInt(yearOfBirth);
		} catch (NumberFormatException e) {
			throw new InputException("입력하신 데이터는 숫자가 아닙니다.");
		}
	}
}