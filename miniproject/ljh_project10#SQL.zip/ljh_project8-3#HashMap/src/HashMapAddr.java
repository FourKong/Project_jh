import java.util.*;

public class HashMapAddr {
	
	Map<String, Addr> list = new HashMap<>();
	Scanner scan = new Scanner(System.in);

	public Addr inputAddr() {
		System.out.print("이름 : ");
		String name = scan.nextLine();
		System.out.print("이메일 : ");
		String email = scan.nextLine();
		return new Addr(name, email);
	}
	
	public boolean addAddr(Addr addr) {
		System.out.print("전화번호 : ");
		String phoneNo = scan.nextLine();
		if (searchAddr(phoneNo)==null) {
			list.put(phoneNo, addr);
			return true;
		} else return false;

	}
	
	public void removeAddr(String phoneNo) {
		list.remove(searchAddr(phoneNo));
	}
	
	public void fixAddr(String phoneNo) {
		System.out.println("수정 정보 입력");
		String tempKey = phoneNo;
		Addr tempValue = list.get(phoneNo);
		removeAddr(phoneNo);
	    if (addAddr(inputAddr()))
	    	System.out.println("수정 완료.");
	    else {
	    	list.put(tempKey, tempValue);
	    	System.out.println("수정 실패. 이미 존재하는 번호.");
	    }
	}
	
	public void printAddr(String phoneNo) {
		Addr value = list.get(phoneNo);
		System.out.println("이름 : " + value.getName());
		System.out.println("이메일 : " + value.getEmail());
		System.out.println("전화번호 : " +  phoneNo);
	}
	
	public void printAll() {
		Set<String> keySet = list.keySet();
		Iterator<String> keyIt = keySet.iterator();
		while(keyIt.hasNext()) {
			String key = keyIt.next();
			System.out.println("---------------------");
			printAddr(key);
		}
	}
	
	public String searchAddr(String phoneNo) {
		Set<String> keySet = list.keySet();
		Iterator<String> keyIt = keySet.iterator();
		while(keyIt.hasNext()) {
			String key = keyIt.next();
			if(key.equals(phoneNo))
				return key;
		} return null;
	}

}
