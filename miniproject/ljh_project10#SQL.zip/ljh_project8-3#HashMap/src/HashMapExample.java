import java.util.*;

public class HashMapExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		HashMapAddr hashMap = new HashMapAddr();
		
		for(int i=0; i<2; i++) {
			System.out.println("----------------");
			if (hashMap.addAddr(hashMap.inputAddr()))
				System.out.println("저장 완료.");
			else System.out.println("저장 실패.");
		}
		
		while(true) {
			
			System.out.println("주소 관리 메뉴------------");
			System.out.println(">> 1. 연락처 등록");
			System.out.println(">> 2. 모든 연락처 출력");
			System.out.println(">> 3. 연락처 검색");
			System.out.println(">> 4. 연락처 삭제");
			System.out.println(">> 5. 연락처 수정");
			System.out.println(">> 6. 프로그램 종료");
			System.out.println("----------------------");
			String select = scan.nextLine();
			
			if(select.equals("1")) {
				if (hashMap.addAddr(hashMap.inputAddr()))
					System.out.println("저장 완료.");
				else System.out.println("저장 실패.");
			} else if (select.equals("2")) {
			    hashMap.printAll();
			} else if (select.equals("3")) {
				System.out.println("검색할 번호를 입력해주세요.");
				String tempNo = scan.nextLine();
				if (hashMap.searchAddr(tempNo)==null)
					System.out.println("번호를 찾을 수 없습니다.");
				else hashMap.printAddr(hashMap.searchAddr(tempNo));
			} else if(select.equals("4")) {
				System.out.println("삭제할 번호를 입력해주세요.");
				String tempNo = scan.nextLine();
				if (hashMap.searchAddr(tempNo)==null)
					System.out.println("번호를 찾을 수 없습니다.");
				else hashMap.removeAddr(tempNo);
			} else if(select.equals("5")) {
				System.out.println("수정할 번호를 입력해주세요.");
				String tempNo = scan.nextLine();
				if (hashMap.searchAddr(tempNo)==null)
					System.out.println("번호를 찾을 수 없습니다.");
				else hashMap.fixAddr(tempNo);
			} else if(select.equals("6")) {
				System.out.print("프로그램이 종료되었습니다.");
				scan.close();
				break;
			}			
		}	
	}

}
