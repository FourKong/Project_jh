package ljh_project6;

public interface IFunction {
	
	//통신 속도에 관한 상수
	String FIFTHGEN = "5G";
	String FOURTHGEN = "4G";
	String THIRDGEN = "3G";
	
	//전화 가능 여부에 관한 상수
	String CALLABLE = "가능";
	String CALLDISABLE = "불가능";
	
	//리모컨 기능 탑재 여부에 관한 상수
	String REMOTEABLE = "탑재";
	String REMOTEDISABLE = "미탑재";

	void phoneCallFunction();
	void connectionSpeed();
	void remoteControlFunction();
	
}
