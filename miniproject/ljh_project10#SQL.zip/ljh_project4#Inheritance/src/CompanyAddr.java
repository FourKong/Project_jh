
public class CompanyAddr extends Addr {

	private String company;
	private String depart;
	private String rank;
	
	CompanyAddr() {}
	CompanyAddr(Addr addr, String company, String depart, String rank) {
		setName(addr.getName());
		setNumber(addr.getNumber());
		setMail(addr.getMail());
		setHome(addr.getHome());
		setBirth(addr.getBirth());
		setGroup(addr.getGroup());
		this.company = company;
		this.depart = depart;
		this.rank = rank;
	}
	
	@Override
	void printInfo() {
		super.printInfo();
		System.out.printf("회사이름 : %s\n부서 : %s\n직급 : %s\n",
				company, depart, rank);	
	}
	
	
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getDepart() {
		return depart;
	}
	public void setDepart(String depart) {
		this.depart = depart;
	}
	public String getRank() {
		return rank;
	}
	public void setRank(String rank) {
		this.rank = rank;
	}


}
