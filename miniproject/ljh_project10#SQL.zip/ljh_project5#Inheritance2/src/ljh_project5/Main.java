package ljh_project5;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SonataHighGrade highSpecCar = new SonataHighGrade(CarSpecs.COLORRED, CarSpecs.TIREWIDE, CarSpecs.HIGHDISPLACEMENT, CarSpecs.HANDLENORMAL);
		SonataLowGrade lowSpecCar = new SonataLowGrade(CarSpecs.COLORBLUE, CarSpecs.TIRENORMAL, CarSpecs.LOWDISPLACEMENT, CarSpecs.HANDLEPOWER);
		
		highSpecCar.getSpec();
		lowSpecCar.getSpec();
		
	}

}
