package ljh_project5;

public class SonataLowGrade extends Sonata {
	
	public SonataLowGrade(String color, String tire, int displacement, String handle) {
		super(color, tire, displacement, handle);
	}
	
	int tax = 1000;


//	@Override
	public void getSpec() {
		System.out.println("*********************");
		System.out.println("색상 : " + color);
		System.out.println("타이어 : " + tire);
		if (displacement > 2000) {
			tax = 1500; }
		System.out.println("배기량 : " + displacement);
		System.out.println("핸들 : " + handle);
		System.out.println("세금 : " + tax);
	}

}