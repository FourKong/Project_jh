package com.MyProject.Command;

import javax.servlet.http.*;
import com.MyProject.Model.*;

public class BDeleteCommand implements BCommand{
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		String bId = request.getParameter("bId");
		BDao dao = new BDao();
		dao.delete(bId);
	}
}
