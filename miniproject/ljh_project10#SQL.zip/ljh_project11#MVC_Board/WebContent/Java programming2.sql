create table mvc_board(
bId NUMBER(4) Primary Key,
bName VARCHAR(20),
bTitle VARCHAR(100),
bContent VARCHAR(300),
bDate Date default SYSDATE,
bHit NUMBER(4) default 0,
bGroup NUMBER(4),
bStep NUMBER(4),
bIndent NUMBER(4)
);
create sequence mvc_board_seq;

select * from MVC_BOARD;