import java.util.*;

public class HashSetAddr {
	
	Set<Addr> list = new HashSet<>();
	Iterator<Addr> iterator = list.iterator();
	Scanner scan = new Scanner(System.in);
	
	public Addr inputAddr() {
		System.out.print("이름 : ");
		String name = scan.nextLine();
		System.out.print("전화번호 : ");
		String phoneNo = scan.nextLine();
		System.out.print("이메일 : ");
		String email = scan.nextLine();
		return new Addr(name, phoneNo, email);
		
	}
	
	public boolean addAddr(Addr addr) {
		return list.add(addr);
		
	}
	
	public void removeAddr(String name) {
		list.remove(searchAddr(name));
	}
	
	public void fixAddr(String name) { // search 넣기
		removeAddr(name);
		System.out.println("수정 정보 입력");
		addAddr(inputAddr());
	}
	
	public void printAddr(Addr addr) {
		System.out.println("이름 : " + addr.getName());
		System.out.println("전화번호 : " + addr.getPhoneNo());
		System.out.println("이메일 : " + addr.getEmail());
	}
	
	public void printAll() {
		while (iterator.hasNext()) {
			Addr addr = iterator.next();
			System.out.println(addr.getName());
			printAddr(addr);
		}
	}
	
	public Addr searchAddr(String name) {
		for (Addr addr : list) {
			if (name.equals(addr.getName()))
				return addr;
		} return null;
	}

}
