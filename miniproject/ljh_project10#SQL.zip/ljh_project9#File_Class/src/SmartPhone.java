import java.io.*;
import java.util.*;

public class SmartPhone {
	
	List<Addr> list = new ArrayList<>();
	Scanner scan = new Scanner(System.in);
	File dir = new File("C:/temp/Addr"); // 디렉토리 생성을 위한 파일 클래스
	File file = new File("C:/temp/Addr/saveFile.txt"); // txt 파일 생성을 위한 파일 클래스

	
	public void saveAddr() {	
		try {
			if(!dir.exists()) { dir.mkdirs(); } // 경로 없을 경우 생성
			if(!file.exists()) { file.createNewFile(); } // 파일 없을 경우 생성
			OutputStream os = new FileOutputStream("C:/temp/Addr/saveFile.txt");
			ObjectOutputStream oos = new ObjectOutputStream(os);
			oos.writeObject(list);
			oos.flush();
			oos.close();
		} catch(Exception e) {System.out.println("저장 실패!");}
	}
	
	@SuppressWarnings("unchecked") // 29열의 type safety 경고를 무시하겠다는 어노테이션.
	public void loadAddr() {
		try { 
			InputStream is = new FileInputStream("C:/temp/Addr/saveFile.txt");
			ObjectInputStream ois = new ObjectInputStream(is);
			List<Addr> list = (List<Addr>) ois.readObject();
			/* 우리는 list에 Addr 타입만 넣을 것이므로 경고 무시 没问题
			 * 파일에 문제가 생긴다 해도 예외 처리로 넘어가므로 상관 X. */
			ois.close();
//			this.list.clear(); // 만일 불러오기가 기존 연락처를 덮어쓸 경우 사용.
			for (Addr addr : list)
				this.list.add(addr);
		} catch (Exception e) {System.out.println("불러오기 실패!");}
	}
	
	
	//---------------------이하 기존 메소드---------------------
	
	
	public Addr inputAddr() {
		System.out.print("이름 : ");
		String name = scan.nextLine();
		System.out.print("전화번호 : ");
		String phoneNo = scan.nextLine();
		System.out.print("이메일 : ");
		String email = scan.nextLine();
		return new Addr(name, phoneNo, email);
		
	}
	
	public void addAddr(Addr addr) {
		list.add(addr);
	}
	
	public void removeAddr(String name) {
		list.remove(searchAddr(name));
	}
	
	public void fixAddr(String name) { // search 넣기
		System.out.println("수정 정보 입력");
		list.set(searchAddr(name), inputAddr());
	}
	
	public void printAddr(Addr addr) {
		System.out.println("이름 : " + addr.getName());
		System.out.println("전화번호 : " + addr.getPhoneNo());
		System.out.println("이메일 : " + addr.getEmail());
	}
	
	public void printAll() {
		int i = 0;
		for (Addr addr : list) {
			System.out.println("----------(" + ++i + ")----------");
			printAddr(addr);
		}
	}
	
	public int searchAddr(String name) {
		int i = 0;
		for (Addr addr : list) {
			if (name.equals(addr.getName()))
				return i;
			i++;
		} return -1;
	}

}
