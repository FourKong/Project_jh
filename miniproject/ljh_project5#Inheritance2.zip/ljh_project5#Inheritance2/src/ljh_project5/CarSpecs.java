package ljh_project5;

public class CarSpecs {
	
	static final String COLORRED = "빨강";
	static final String COLORBLUE = "파랑";
	static final String TIRENORMAL = "일반 타이어";
	static final String TIREWIDE = "광폭 타이어";
	static final String HANDLENORMAL = "일반 핸들";
	static final String HANDLEPOWER = "파워 핸들";
	static final int LOWDISPLACEMENT = 2000;
	static final int HIGHDISPLACEMENT = 2500;

}
