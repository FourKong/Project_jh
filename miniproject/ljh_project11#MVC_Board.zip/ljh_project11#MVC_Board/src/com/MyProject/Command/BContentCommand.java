package com.MyProject.Command;

import javax.servlet.http.*;
import com.MyProject.Model.*;

public class BContentCommand implements BCommand{
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		String bId = request.getParameter("bId");
		BDao dao = new BDao();
		BDto dto = dao.contentView(bId); // 해당 bId를 가진 튜플을 dto에 담아서
		
		request.setAttribute("content_view", dto); // content_view라는 이름으로 request 패킷에 넣기.
	}
}
