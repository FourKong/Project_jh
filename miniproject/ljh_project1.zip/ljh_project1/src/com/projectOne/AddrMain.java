package com.projectOne;

public class AddrMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Addr method = new Addr("김신랑","010-1112-2233","abc@daum.net","서울","친구");
		method.printInfo();
		method.changeInfo("가족");
		method.printInfo();
	}

}
