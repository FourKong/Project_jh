package ljh_project6;

public class BPhone implements IFunction {
	
	String callAble = IFunction.CALLABLE;
	String telecomGen = IFunction.FIFTHGEN;
	String remoteAble = IFunction.REMOTEABLE;
	
	@Override
	public void phoneCallFunction() {
		System.out.println("B Phone");
		System.out.println("전화 " + callAble + "합니다. ");
	}
	
	@Override
	public void connectionSpeed() {
		System.out.println("가능합니다. " + telecomGen + "입니다.");
		
	}
	@Override
	public void remoteControlFunction() {
		System.out.println("가능합니다. " + remoteAble + "되었습니다.");
		System.out.println("-----------------------");	
	}


}