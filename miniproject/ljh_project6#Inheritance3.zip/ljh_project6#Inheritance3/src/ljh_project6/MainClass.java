package ljh_project6;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		IFunction function;
		
		function = new APhone();
		function.phoneCallFunction();
		function.connectionSpeed();
		function.remoteControlFunction();
		
		function = new BPhone();
		function.phoneCallFunction();
		function.connectionSpeed();
		function.remoteControlFunction();
		
		function = new CPhone();
		function.phoneCallFunction();
		function.connectionSpeed();
		function.remoteControlFunction();
	}
}
