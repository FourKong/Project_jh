import java.util.*;

public class ArrayListAddr {
	
	List<Addr> list = new ArrayList<>();
	Scanner scan = new Scanner(System.in);
	
	public Addr inputAddr() {
		System.out.print("이름 : ");
		String name = scan.nextLine();
		System.out.print("전화번호 : ");
		String phoneNo = scan.nextLine();
		System.out.print("이메일 : ");
		String email = scan.nextLine();
		return new Addr(name, phoneNo, email);
		
	}
	
	public void addAddr(Addr addr) {
		list.add(addr);
	}
	
	public void removeAddr(String name) {
		list.remove(searchAddr(name));
	}
	
	public void fixAddr(String name) { // search 넣기
		System.out.println("수정 정보 입력");
		list.set(searchAddr(name), inputAddr());
	}
	
	public void printAddr(Addr addr) {
		System.out.println("이름 : " + addr.getName());
		System.out.println("전화번호 : " + addr.getPhoneNo());
		System.out.println("이메일 : " + addr.getEmail());
	}
	
	public void printAll() {
		int i = 0;
		for (Addr addr : list) {
			System.out.println("----------(" + ++i + ")----------");
			printAddr(addr);
		}
	}
	
	public int searchAddr(String name) {
		int i = 0;
		for (Addr addr : list) {
			if (name.equals(addr.getName()))
				return i;
			i++;
		} return -1;
	}

}
